#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
cd /candidate
go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -run '^Test(Checkpoint|Diagnostic.*Checkpoint|EmptyCheckpoint|PrivateCheckpoint|ScannerElection)' -count=1 -v -timeout=8m > /evidence/pages-core-shadow.log 2>&1
bash /evidence/focused.sh
