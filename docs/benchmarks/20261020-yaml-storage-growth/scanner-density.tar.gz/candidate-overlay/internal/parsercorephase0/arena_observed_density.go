package parsercorephase0

// GrowRecordArenasFromObservedDensity projects the live record counts at the
// first staged reserve. Unlike a fixed source density, this keeps the observed
// mixture of graph and syntax records. It changes capacity only. The complete
// existing five-arena capacity and every proposed increase fit maxBytes when
// that ceiling is armed; no live records or limits change.
func (c *Core) GrowRecordArenasFromObservedDensity(sourceBytes int, progress uint32, maxBytes uint64) bool {
	if c == nil || sourceBytes <= 1 || uint64(sourceBytes) > uint64(^uint32(0)) || progress == 0 || uint64(progress) >= uint64(sourceBytes) || uint64(progress) < uint64(sourceBytes/16) {
		return false
	}
	project := func(count int, limit uint32) int {
		value := (uint64(min(count, 1<<31-1))*uint64(sourceBytes) + uint64(progress) - 1) / uint64(progress)
		value = (value*17 + 15) / 16
		return int(min(value, uint64(limit), uint64(1<<31-1)))
	}
	nodes := project(len(c.nodes), c.limits.MaxNodes)
	links := project(len(c.links), c.limits.MaxLinks)
	subtrees := project(len(c.subtrees), c.limits.MaxSubtrees)
	children := project(len(c.children), c.limits.MaxChildren)
	dn := max(nodes-cap(c.nodes), 0)
	dl := max(nodes-cap(c.nodeLineages), 0)
	de := max(links-cap(c.links), 0)
	ds := max(subtrees-cap(c.subtrees), 0)
	dc := max(children-cap(c.children), 0)
	additional := uint64(dn)*coreNodeRecordBytes + uint64(dl)*coreNodeLineageRecordBytes + uint64(de)*coreLinkRecordBytes + uint64(ds)*coreSubtreeRecordBytes + uint64(dc)*coreChildRecordBytes
	if additional == 0 {
		return false
	}
	if maxBytes > 0 {
		current := uint64(cap(c.nodes))*coreNodeRecordBytes + uint64(cap(c.nodeLineages))*coreNodeLineageRecordBytes + uint64(cap(c.links))*coreLinkRecordBytes + uint64(cap(c.subtrees))*coreSubtreeRecordBytes + uint64(cap(c.children))*coreChildRecordBytes
		if current >= maxBytes {
			return false
		}
		allowed := maxBytes - current
		if additional > allowed {
			dn = scaleReserveCount(dn, allowed, additional)
			dl = scaleReserveCount(dl, allowed, additional)
			de = scaleReserveCount(de, allowed, additional)
			ds = scaleReserveCount(ds, allowed, additional)
			dc = scaleReserveCount(dc, allowed, additional)
			if dn|dl|de|ds|dc == 0 {
				return false
			}
		}
	}
	c.nodes = growArena(c.nodes, cap(c.nodes)+dn)
	c.nodeLineages = growArena(c.nodeLineages, cap(c.nodeLineages)+dl)
	c.links = growArena(c.links, cap(c.links)+de)
	c.subtrees = growArena(c.subtrees, cap(c.subtrees)+ds)
	c.children = growArena(c.children, cap(c.children)+dc)
	return true
}
