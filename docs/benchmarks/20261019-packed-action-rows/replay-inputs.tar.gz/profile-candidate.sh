#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/perf/complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/candidate-profile-overlay.json'
cd /candidate
go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkStreamedPrefixGo/query_compile$' -benchtime=8s -count=1 -cpuprofile=/evidence/candidate-query.pprof -o /evidence/candidate-profile.test > /evidence/candidate-profile.log 2>&1
go tool pprof -top -nodecount=18 /evidence/candidate-profile.test /evidence/candidate-query.pprof > /evidence/candidate-profile-flat.txt
go tool pprof -top -cum -nodecount=18 /evidence/candidate-profile.test /evidence/candidate-query.pprof > /evidence/candidate-profile-cum.txt
printf 'complete\n' > /evidence/candidate-profile-complete.txt
