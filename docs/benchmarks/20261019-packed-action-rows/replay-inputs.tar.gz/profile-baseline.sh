#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/profile-overlay.json'
cd /reference
go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkStreamedPrefixGo/query_compile$' -benchtime=8s -count=1 -cpuprofile=/evidence/baseline-query.pprof -o /evidence/baseline-profile.test > /evidence/baseline-profile.log 2>&1
go tool pprof -top -nodecount=18 /evidence/baseline-profile.test /evidence/baseline-query.pprof > /evidence/baseline-profile-flat.txt
go tool pprof -top -cum -nodecount=18 /evidence/baseline-profile.test /evidence/baseline-query.pprof > /evidence/baseline-profile-cum.txt
printf 'complete\n' > /evidence/baseline-profile-complete.txt
