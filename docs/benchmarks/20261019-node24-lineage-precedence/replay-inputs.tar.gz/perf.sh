#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/full-counter-gate.json
test -f /evidence/rss/complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/timing-overlay.json'
mkdir -p /evidence/perf
cd /candidate
bash scripts/run_randomized_benchmarks.sh --output /evidence/perf/yaml-after.txt --baseline-root /reference --baseline-output /evidence/perf/yaml-before.txt --bench-regex '^BenchmarkStreamedPrefixYAML$' --require-benchmarks BenchmarkStreamedPrefixYAML/r4_legacy,BenchmarkStreamedPrefixYAML/eof8k_legacy,BenchmarkStreamedPrefixYAML/r4_ordinary,BenchmarkStreamedPrefixYAML/eof8k_ordinary,BenchmarkStreamedPrefixYAML/r4_owned,BenchmarkStreamedPrefixYAML/eof8k_owned --runs 20 --seed-start 36801 --benchtime 750ms > /evidence/perf/yaml-runner.log 2>&1
bash scripts/run_randomized_benchmarks.sh --output /evidence/perf/go-after.txt --baseline-root /reference --baseline-output /evidence/perf/go-before.txt --bench-regex '^Benchmark(StreamedPrefixGo|GoParseFullDFA|GoParseIncrementalSingleByteEditDFA|GoParseIncrementalNoEditDFA|GoParseCompactFreshOneMiB)$' --require-benchmarks BenchmarkStreamedPrefixGo/query_compile,BenchmarkStreamedPrefixGo/grammargen_lr,BenchmarkGoParseFullDFA,BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGoParseIncrementalNoEditDFA,BenchmarkGoParseCompactFreshOneMiB --runs 20 --seed-start 36901 --benchtime 750ms > /evidence/perf/go-runner.log 2>&1
printf 'complete\n' > /evidence/perf/complete.txt
