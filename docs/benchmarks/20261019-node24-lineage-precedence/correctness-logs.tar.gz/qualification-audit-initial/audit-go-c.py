from pathlib import Path
import json,re
p=Path('/evidence/out')
results={}
for role in ['baseline','candidate']:
 text=(p/f'{role}-expanded-go-c.log').read_text()
 rows={name:status for status,name in re.findall(r'--- (PASS|FAIL): ((?:TestGoTokenTurnExpandedLockedCProbe|TestGoGenericCallFrontierLockedCProbe)/[^\s]+)',text)}
 assert len(rows)==306,(role,len(rows))
 assert text.count('EXPANDED_ROUTE compact=1 fallback=0')==300,role
 results[role]=rows
assert results['baseline']==results['candidate'],'expanded C behavior changed'
expanded=[v for k,v in results['candidate'].items() if k.startswith('TestGoTokenTurnExpandedLockedCProbe/')]
assert expanded.count('PASS')==261 and expanded.count('FAIL')==39
report=dict(total_cases=306,expanded_pass=261,expanded_known_fail=39,all_306_statuses_equal=True,new_failures=0,targeted_cases=6,baseline=results['baseline'],candidate=results['candidate'])
(p/'expanded-go-c-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['baseline','candidate']}))
