#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -run '^Test(BorrowedReductionPlan.*|IdentityReduction.*|Reduce.*|.*ReductionPlan.*)$' -count=1 -v > /evidence/core-focused.log 2>&1
go test ./internal/parsercorephase0 -count=1 -timeout=8m > /evidence/core-all.log 2>&1
go test ./internal/parsercorephase0 -tags gts_parsercorephase0a -count=1 -timeout=8m > /evidence/core-phase0a.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(DiagnosticParserCoreClassifiedBoundaryAndReductionPlanShape|CanonicalMaskCensus|ParserCore.*Reduction.*|CompactAcceptanceCachedPublicationStopControl)$' -count=1 -v -timeout=8m > /evidence/root-focused.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^TestBorrowedReductionPlan.*$' -count=1 -v > /evidence/core-386.log 2>&1
go test ./internal/parsercorephase0 -race -run '^TestBorrowedReductionPlan.*$' -count=1 -v > /evidence/core-race.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
