package parsercorephase0

import (
	"errors"
	"reflect"
	"testing"
)

type borrowedPlanTestProvider struct {
	fakeTable
	plan    ReductionPlan
	err     error
	nilPlan bool
	calls   int
}

func (p *borrowedPlanTestProvider) ReductionPlan(uint16, int) (ReductionPlan, error) {
	return p.plan, p.err
}
func (p *borrowedPlanTestProvider) BorrowedReductionPlan(uint16, int) (*ReductionPlan, error) {
	p.calls++
	if p.nilPlan {
		return nil, p.err
	}
	return &p.plan, p.err
}

type valuePlanTestProvider struct {
	fakeTable
	plan  ReductionPlan
	calls int
}

func (p *valuePlanTestProvider) ReductionPlan(uint16, int) (ReductionPlan, error) {
	p.calls++
	return p.plan, nil
}

func TestBorrowedReductionPlanPreservesIdentityAndProviderCalls(t *testing.T) {
	plan, err := NewReductionPlan(7, 2, []FieldMapEntry{{FieldID: 3, ChildIndex: 1}}, []Symbol{4, 5})
	if err != nil {
		t.Fatal(err)
	}
	p := &borrowedPlanTestProvider{plan: plan}
	c := &Core{plans: p}
	var fallback ReductionPlan
	for i := 0; i < 2; i++ {
		got, err := c.borrowReductionPlan(7, 2, &fallback)
		if err != nil || got != &p.plan || !reflect.DeepEqual(*got, plan) {
			t.Fatalf("got %v error %v", got, err)
		}
	}
	if p.calls != 2 {
		t.Fatal("provider callback was cached")
	}
	if _, err := c.borrowReductionPlan(7, 1, &fallback); err == nil {
		t.Fatal("wrong pair accepted")
	}
	p.nilPlan = true
	if _, err := c.borrowReductionPlan(7, 2, &fallback); err == nil {
		t.Fatal("nil plan accepted")
	}
	p.nilPlan = false
	p.err = errors.New("provider error")
	if _, err := c.borrowReductionPlan(7, 2, &fallback); !errors.Is(err, p.err) {
		t.Fatal("provider error lost")
	}
}
func TestBorrowedReductionPlanKeepsValueProviderAndWarmAllocations(t *testing.T) {
	plan, err := NewReductionPlan(8, 1, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	value := &valuePlanTestProvider{plan: plan}
	borrowed := &borrowedPlanTestProvider{plan: plan}
	for _, provider := range []ReductionPlanProvider{value, borrowed} {
		c := &Core{plans: provider}
		var fallback ReductionPlan
		if got := testing.AllocsPerRun(100, func() {
			p, err := c.borrowReductionPlan(8, 1, &fallback)
			if err != nil || p == nil || p.productionID != 8 {
				panic("invalid plan")
			}
		}); got != 0 {
			t.Fatalf("lookup allocated %g times", got)
		}
	}
	if value.calls == 0 || borrowed.calls == 0 {
		t.Fatal("provider was bypassed")
	}
}
