package parsercorephase0

import "errors"

// BorrowedReductionPlanProvider exposes immutable metadata without copying the
// plan on every reduction. The plan and its sidecars must remain immutable
// through the reduction. Providers still run for each request; this is not a
// cache of user callbacks or their effects. Value-only providers remain valid.
type BorrowedReductionPlanProvider interface {
	BorrowedReductionPlan(productionID uint16, childCount int) (*ReductionPlan, error)
}

func (c *Core) borrowReductionPlan(productionID uint16, childCount int, fallback *ReductionPlan) (*ReductionPlan, error) {
	if provider, ok := c.plans.(BorrowedReductionPlanProvider); ok {
		plan, err := provider.BorrowedReductionPlan(productionID, childCount)
		if err != nil {
			return nil, err
		}
		if plan == nil {
			return nil, errors.New("parser-core phase zero: borrowed reduction plan is nil")
		}
		if plan.productionID != productionID || int(plan.childCount) != childCount {
			return nil, errors.New("parser-core phase zero: reduction plan pair identity mismatch")
		}
		return plan, nil
	}
	plan, err := c.reductionPlanForPair(productionID, childCount)
	if err != nil {
		return nil, err
	}
	*fallback = plan
	return fallback, nil
}
