from pathlib import Path
import argparse,hashlib,json,tarfile
lab=Path(__file__).resolve().parent
args=argparse.ArgumentParser();args.add_argument("output",type=Path);opt=args.parse_args()
out=opt.output;out.mkdir(parents=True,exist_ok=True)
assert (lab/"perf/complete.txt").read_text().strip()=="complete"
perf=json.loads((lab/"perf-summary.json").read_text())
assert perf["benchmark_rows"]==480
rss=json.loads((lab/"rss/rss-matched/audit.json").read_text())
assert rss["candidate_safety_pass"]
assert json.loads((lab/"full-counter-gate.json").read_text())["work_direction_passed"]
ref=Path(json.loads((lab/"source-reference.json").read_text())["baseline_source"])
before={str(p.relative_to(ref)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ref.rglob("*.go")}
after=json.loads((lab/"candidate-source-pins.json").read_text())
assert len(before)==3524 and len(after)==3526
changed=sorted(f for f,h in after.items() if before.get(f)!=h);assert len(changed)==5
(lab/"reference-source-pins.json").write_text(json.dumps(before,indent=2)+"\n")
manifest={}
def pack(name,entries):
    members={}
    with tarfile.open(out/name,"w:gz") as tar:
        for arc,path in sorted(entries.items()):
            assert path.is_file(),path
            members[arc]={"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"bytes":path.stat().st_size}
            tar.add(path,arcname=arc,recursive=False)
    manifest[name]={"sha256":hashlib.sha256((out/name).read_bytes()).hexdigest(),"bytes":(out/name).stat().st_size,"members":members}
def logs(root,prefix):
    return {prefix+str(p.relative_to(root)):p for p in root.rglob("*") if p.is_file() and p.suffix in [".log",".json",".rss"] and p.name!="inspect.json"}
protocol={p.name:p for p in lab.iterdir() if p.is_file() and (p.suffix in [".sh",".py"] or p.name.endswith(".go.txt") or p.name in ["source-reference.json","baseline-reuse.json","candidate-source-pins.json","reference-source-pins.json","languages.txt","qualification-overlay.json","large-overlay.json","pre-main-strict-census.json"])}
for f in changed:protocol["candidate-files/"+f]=lab/"candidate-source"/f
for name in ["run.sh","selectors.sh","overlay.json","repeat_rss.py"]:protocol["rss/"+name]=lab/"rss"/name
# Host launchers name historical absolute paths; use README's fresh mounts instead.
protocol={k:v for k,v in protocol.items() if k not in ["run-rss-host.sh","run-perf-host.sh","run-qualification.sh"]}
pack("source-and-protocol.tar.gz",protocol)
qualification=logs(lab/"out","observed/out/")
for p in lab.iterdir():
    if p.is_file() and (p.suffix==".log" or p.name in ["full-counter-gate.json","reference-ledger.json","reference-owned-yaml-ledger.json","reference-canonical-work.json","canonical-work.json","production-strict-census.json","baseline-main-audit.json"]):qualification["observed/"+p.name]=p
pack("qualification.tar.gz",qualification)
pack("rss.tar.gz",logs(lab/"rss","observed/rss/"))
pack("matched-performance.tar.gz",{**{ "observed/perf/"+p.name:p for p in (lab/"perf").iterdir() if p.is_file() and p.suffix in [".txt",".log"] and p.name!="complete.txt"},"observed/perf-summary.json":lab/"perf-summary.json"})
proto=lab.parent/"20261020-borrowed-reduction-plans";proto_pins=json.loads((proto/"candidate-source-pins.json").read_text())
proto_changed=[f for f,h in proto_pins.items() if before.get(f)!=h];assert len(proto_changed)==4
entries={"candidate-files/"+f:proto/"candidate-source"/f for f in proto_changed}
for name in ["screen-status.json","source-reference.json","candidate-source-pins.json","focused.sh","guards.sh","core-screen.sh","focused-runner.log","qualification-runner.log","layout.log","core-all.log","core-normal.log","core-phase0a-complete.log","core-onepass.log","core-focused.log","root-focused.log","core-386.log","core-race.log"]:entries["observed/borrowed-prototype/"+name]=proto/name
pack("rejected-borrowed-prototype.tar.gz",entries)
(out/"archive-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({name:{k:v for k,v in value.items() if k!="members"} for name,value in manifest.items()},indent=2))
