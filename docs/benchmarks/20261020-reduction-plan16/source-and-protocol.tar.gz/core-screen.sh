#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/focused-complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
cp /evidence/core-all.log /evidence/core-normal.log
cp /evidence/core-phase0a.log /evidence/core-phase0a-complete.log
go test ./internal/parsercorephase0 -tags gts_parsercorephase0_selectedstore_onepass -count=1 -timeout=8m > /evidence/core-onepass.log 2>&1
printf 'complete\n' > /evidence/core-complete.txt
