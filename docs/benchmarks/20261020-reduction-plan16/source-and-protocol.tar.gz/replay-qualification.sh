#!/usr/bin/env bash
set -euo pipefail
# Fresh observations: archives of past results are kept separate from /evidence.
bash /evidence/focused.sh
bash /evidence/baseline.sh
bash /evidence/core-screen.sh
bash /evidence/qualify.sh
bash /evidence/large-c.sh
python3 /evidence/audit-full.py
