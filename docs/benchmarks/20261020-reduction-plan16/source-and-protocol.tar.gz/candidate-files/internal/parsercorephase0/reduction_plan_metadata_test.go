package parsercorephase0

import (
	"reflect"
	"testing"
	"unsafe"
)

func TestReductionPlanMetadataKeepsCopiesImmutableAndCompact(t *testing.T) {
	want := uintptr(16)
	if unsafe.Sizeof(uintptr(0)) == 4 {
		want = 8
	}
	if got := unsafe.Sizeof(ReductionPlan{}); got != want {
		t.Fatalf("plan size %d want %d", got, want)
	}
	fields := []FieldMapEntry{{FieldID: 65535, ChildIndex: 254, Inherited: true}}
	aliases := make([]Symbol, 255)
	aliases[254] = 65535
	plan, err := NewReductionPlan(65535, 255, fields, aliases)
	if err != nil {
		t.Fatal(err)
	}
	copied := plan
	fields[0].FieldID = 1
	aliases[254] = 1
	if plan.productionID != 65535 || plan.childCount != 255 || plan.fields()[0].FieldID != 65535 || plan.aliases()[254] != 65535 {
		t.Fatal("identity or owned metadata changed")
	}
	if plan.metadata != copied.metadata || !reflect.DeepEqual(plan.fields(), copied.fields()) || !reflect.DeepEqual(plan.aliases(), copied.aliases()) {
		t.Fatal("value copy lost immutable metadata")
	}
	empty, err := NewReductionPlan(0, 0, nil, nil)
	if err != nil || empty.metadata != nil || empty.fields() != nil || empty.aliases() != nil {
		t.Fatal("empty metadata allocated or changed")
	}
	if n := testing.AllocsPerRun(100, func() {
		p, err := NewReductionPlan(7, 2, nil, nil)
		if err != nil || p.metadata != nil {
			panic("bad empty plan")
		}
	}); n != 0 {
		t.Fatalf("empty plan allocated %g", n)
	}
}
