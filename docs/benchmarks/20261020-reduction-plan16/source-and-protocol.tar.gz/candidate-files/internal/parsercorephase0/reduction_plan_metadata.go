package parsercorephase0

// reductionPlanMetadata owns the uncommon sidecars of an immutable plan.
// Empty metadata stays implicit, so copying or returning a plan moves only
// one pointer and its full-width production/count identity.
type reductionPlanMetadata struct {
	fields  []FieldMapEntry
	aliases []Symbol
}

func (p ReductionPlan) fields() []FieldMapEntry {
	if p.metadata == nil {
		return nil
	}
	return p.metadata.fields
}
func (p ReductionPlan) aliases() []Symbol {
	if p.metadata == nil {
		return nil
	}
	return p.metadata.aliases
}
