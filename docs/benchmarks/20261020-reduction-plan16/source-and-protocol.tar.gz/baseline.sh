#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/qualification-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
mkdir -p /evidence/out/baseline
cd /reference
go build -tags gts_parsercorephase0 -o /evidence/out/baseline/counter ./cmd/perfcounterledger > /evidence/out/baseline/counter-build.log 2>&1
/evidence/out/baseline/counter --write --output /evidence/out/baseline/ledger.json > /evidence/out/baseline/ledger.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/out/baseline/counter --langs yaml > /evidence/out/baseline/owned-yaml-ledger.json 2> /evidence/out/baseline/owned-yaml-ledger.log
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v -timeout=8m > /evidence/out/baseline/canonical-work.log 2>&1
cd /reference/cgo_harness
go test -c -tags gts_parsercorephase0,treesitter_c_parity -o /evidence/out/baseline/cgo.test . > /evidence/out/baseline/cgo-build.log 2>&1
python3 /evidence/strict-baseline.py baseline > /evidence/out/baseline/strict.log 2>&1
python3 - <<'AUDIT'
from pathlib import Path
import json,shutil
p=Path('/evidence');out=p/'out/baseline'
for a,b in [('ledger.json','reference-ledger.json'),('owned-yaml-ledger.json','reference-owned-yaml-ledger.json')]:
 shutil.copy2(out/a,p/b)
rows={}
for line in (out/'canonical-work.log').read_text().splitlines():
 if 'CANONICAL_WORK_CENSUS ' in line:
  row=json.loads(line.split('CANONICAL_WORK_CENSUS ',1)[1]);rows[row['Fixture']]=row
assert len(rows)==4
(p/'reference-canonical-work.json').write_text(json.dumps({'candidate':rows},indent=2)+'\n')
shutil.copy2(out/'strict-census.json',p/'production-strict-census.json')
(p/'baseline-main-audit.json').write_text(json.dumps({'ledger_rows_exact':414,'canonical_rows':4,'strict_rows':204,'strict_changes_from_pre_main':json.loads((out/'strict-differences.json').read_text())},indent=2)+'\n')
AUDIT
printf 'complete\n' > /evidence/baseline-complete.txt
