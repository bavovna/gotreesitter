#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/build.log 2>&1
GTS_STORAGE_CASE=go /evidence/root.test -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=8m > /evidence/go.log 2>&1
printf 'complete\n' > /evidence/complete.txt
