#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
test -f /evidence/perf/complete.txt
cd /candidate
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_parsercorephase0a,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-phase0a.log 2>&1
go test ./internal/parsercorephase0 -tags gts_parsercorephase0_selectedstore_onepass,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-onepass.log 2>&1
printf 'complete\n' > /evidence/extra-core-modes-complete.txt
