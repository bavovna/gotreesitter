#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-full-shadow.log 2>&1
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-full.log 2>&1
printf 'complete\n' > /evidence/core-full-complete.txt
