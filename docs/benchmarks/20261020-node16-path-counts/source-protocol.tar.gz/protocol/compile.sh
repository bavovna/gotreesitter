#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -gcflags=-e -tags gts_eof_recovery_shadow -run '^Test(NodePathCount|NodeLineage|Sole|DiagnosticEOFRecoveryClonePlan)' -count=1 -v -timeout=8m > /evidence/compile-attempt3.log 2>&1
printf 'complete\n' > /evidence/compile-complete.txt
