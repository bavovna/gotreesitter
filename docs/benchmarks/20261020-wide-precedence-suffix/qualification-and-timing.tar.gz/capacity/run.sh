#!/usr/bin/env bash
set -euo pipefail
test -f /lab/full-counter-gate.json
python3 -c 'import json; assert json.load(open("/lab/full-counter-gate.json"))["passed"]'
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/root-wide.test . > /evidence/build-wide.log 2>&1
GTS_STORAGE_CASE=go /evidence/root-wide.test -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=8m > /evidence/go-wide.log 2>&1
printf 'complete\n' > /evidence/wide-complete.txt
