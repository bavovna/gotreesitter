from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
read=lambda n:json.loads((p/n).read_text())
assert (p/'qualify-complete.txt').read_text().strip()=='complete'
assert (p/'large-go-verified-complete.txt').read_text().strip()=='complete'
out=p/'out/candidate'
for pattern in ['invariant-*.log','c-*.log']:
 files=list(out.glob(pattern));assert len(files)==206
 for f in files:
  s=f.read_text();assert 'PASS' in s and '--- FAIL:' not in s and '--- SKIP:' not in s,f.name
  if pattern=='c-*.log':
   language=f.stem[2:]
   for test in ['TestParityFreshParse','TestParityIncrementalParse','TestParityHasNoErrors']:assert '=== RUN   '+test+'/'+language+'\n' in s,(f.name,test)
  if pattern.startswith('invariant'):assert 'session_steps=72' in s and 'no_edit_allocs=0' in s,f.name
assert sum(len(re.findall(r'^--- PASS:',f.read_text(),re.M)) for f in out.glob('c-*.log'))==618
for a,b in [('reference-ledger.json','out/candidate/ledger.json'),('reference-owned-yaml-ledger.json','out/candidate/owned-yaml-ledger.json')]:assert read(a)==read(b),(a,b)
rows={}
for line in (out/'canonical-work.log').read_text().splitlines():
 if 'CANONICAL_WORK_CENSUS ' in line:
  row=json.loads(line.split('CANONICAL_WORK_CENSUS ',1)[1]);rows[row['Fixture']]=row
assert rows==read('reference-canonical-work.json')['candidate'] and len(rows)==4
assert read('out/candidate/strict-differences.json')==[]
go=read('out/expanded-go-c-audit.json');assert go['all_306_statuses_equal'] and go['new_failures']==0 and go['expanded_routes_exact']==300
for name in ['core-shadow','root-default','memory-pooling','root-race','core-race','root-386','yaml-large-c','large-go-c','owned-yaml-invariant']:
 s=((p/'large-go-c-verified.log') if name=='large-go-c' else out/(name+'.log')).read_text();assert 'no tests to run' not in s and '=== RUN' in s and 'PASS' in s and '--- FAIL:' not in s and '--- SKIP:' not in s,name
pins=read('candidate-source-pins.json');assert len(pins)==3525
for rel,want in pins.items():assert hashlib.sha256((p/'candidate-source'/rel).read_bytes()).hexdigest()==want,rel
report=dict(passed=True,ledger_complete_rows_exact=414,canonical_Go_vectors_and_trees_exact=4,invariant_languages=206,steps_per_session=72,C_fixture_checks=618,strict_rows_exact=204,expanded_Go_C_statuses_exact=306,expanded_Go_routes_exact=300,expanded_Go_known_failures_unchanged=39,source_pin_count=len(pins),held_Go_repair_included=False,runtime_promoted=False)
(p/'full-counter-gate.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
