#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/qualification-overlay.json'
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-focused.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^Test(NodePrecedence|PrecedenceMaximum)' -count=1 -v -timeout=8m > /evidence/core-focused-386.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(DiagnosticParserCoreElectionSummaryMatchesFullReceipt|DiagnosticParserCoreVersionLexerElectionReusesCheckpointSerialization|DiagnosticParserCoreVersionLexer.*|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle)$' -count=1 -v -timeout=8m > /evidence/focused.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
bash /evidence/qualify.sh
