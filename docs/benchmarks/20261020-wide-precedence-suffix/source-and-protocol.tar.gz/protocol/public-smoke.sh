#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_eof_recovery_shadow -run '^Test(NodePrecedence|PrecedenceMaximum)' -count=1 -v -timeout=8m > /evidence/public-core.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^Test(NodePrecedence|PrecedenceMaximum)' -count=1 -v -timeout=8m > /evidence/public-core-386.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(G18RefSetSchedulerRecordSizeRatchets|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle)$' -count=1 -v -timeout=8m > /evidence/public-root.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^TestG18RefSetSchedulerRecordSizeRatchets$' -count=1 -v -timeout=8m > /evidence/public-root-386.log 2>&1
go run ./cmd/v1layout > /evidence/public-layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/public-v1guard.log 2>&1
printf 'complete\n' > /evidence/public-smoke-complete.txt
