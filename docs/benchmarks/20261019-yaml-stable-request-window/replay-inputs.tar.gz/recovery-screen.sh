#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/full-counter-gate.json
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/recovery-overlay.json'
cd /candidate
go test . -tags gts_parsercorephase0 -run '^TestStableRequestWindowRecovery' -count=1 -v > /evidence/recovery-window.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test . -tags gts_parsercorephase0 -run '^TestStableRequestWindowRecovery' -count=1 -v > /evidence/recovery-window-386.log 2>&1
go test . -tags gts_parsercorephase0 -race -run '^Test(StableRequestWindowRecoveryPrunesWithinOffset|DiagnosticParserCoreOwnedLexerStableRequestWindow)$' -count=1 -v > /evidence/recovery-window-race.log 2>&1
grep -q -- '--- PASS: TestStableRequestWindowRecoveryPrunesWithinOffset' /evidence/recovery-window-race.log
printf 'complete\n' > /evidence/recovery-complete.txt
printf 'complete\n' > /evidence/recovery-extra-complete.txt
