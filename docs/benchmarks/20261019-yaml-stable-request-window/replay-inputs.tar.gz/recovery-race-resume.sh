#!/usr/bin/env bash
set -euo pipefail
grep -q -- '--- PASS: TestStableRequestWindowRecoveryPrunesWithinOffset' /evidence/recovery-window.log
grep -q -- '--- PASS: TestStableRequestWindowRecoveryPrunesWithinOffset' /evidence/recovery-window-386.log
grep -q -- '--- PASS: TestDiagnosticParserCoreOwnedLexerStableRequestWindow' /evidence/recovery-window-race.log
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/recovery-overlay.json'
cd /candidate
go test . -tags gts_parsercorephase0 -race -run '^Test(StableRequestWindowRecoveryPrunesWithinOffset|DiagnosticParserCoreOwnedLexerStableRequestWindow)$' -count=1 -v > /evidence/recovery-window-race-extra.log 2>&1
grep -q -- '--- PASS: TestStableRequestWindowRecoveryPrunesWithinOffset' /evidence/recovery-window-race-extra.log
grep -q -- '--- PASS: TestDiagnosticParserCoreOwnedLexerStableRequestWindow' /evidence/recovery-window-race-extra.log
printf 'complete\n' > /evidence/recovery-extra-complete.txt
