#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
selector='^TestVersionLexer(InterningPreservesClosedAcceptanceGroup|OwnershipPreservesEffectiveAcceptanceGroup)$'
cd /reference
set +e
go test . -tags gts_parsercorephase0 -overlay=/evidence/baseline-witness-overlay.json -run "$selector" -count=1 -v -timeout=8m > /evidence/witness-baseline.log 2>&1
baseline_status=$?
set -e
test "$baseline_status" -eq 1
python3 - <<'CHECK'
from pathlib import Path
s=Path('/evidence/witness-baseline.log').read_text()
assert '--- FAIL: TestVersionLexerInterningPreservesClosedAcceptanceGroup' in s
assert '--- FAIL: TestVersionLexerOwnershipPreservesEffectiveAcceptanceGroup' in s
assert 'interning changed closed acceptance group' in s
assert 'distinct closed recovery elections became one lexer owner' in s
assert '[build failed]' not in s
CHECK
cd /candidate
go test . -tags gts_parsercorephase0 -run "$selector" -count=1 -v -timeout=8m > /evidence/witness-candidate.log 2>&1
go test . -race -tags gts_parsercorephase0 -run "$selector" -count=1 -v -timeout=8m > /evidence/witness-race.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test . -tags gts_parsercorephase0 -run "$selector" -count=1 -v -timeout=8m > /evidence/witness-386.log 2>&1
python3 - <<'CHECK'
from pathlib import Path
for name in ['witness-candidate.log','witness-race.log','witness-386.log']:
 s=(Path('/evidence')/name).read_text()
 assert '--- PASS: TestVersionLexerInterningPreservesClosedAcceptanceGroup' in s,name
 assert '--- PASS: TestVersionLexerOwnershipPreservesEffectiveAcceptanceGroup' in s,name
 assert '--- FAIL:' not in s,name
CHECK
printf 'complete\n' > /evidence/witness-complete.txt
