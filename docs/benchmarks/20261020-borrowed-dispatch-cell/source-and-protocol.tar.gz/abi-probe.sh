#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/layout-probe-overlay.json'
cd /reference
status=0
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^TestG18RefSetSchedulerRecordSizeRatchets$' -count=1 -v > /evidence/reference-386-layout.log 2>&1 || status=$?
printf '%s\n' "$status" > /evidence/reference-386-layout-status.txt
test "$status" -eq 1
