#!/usr/bin/env bash
set -euo pipefail
bash /evidence/core-screen.sh
bash /evidence/qualify.sh
bash /evidence/large-c.sh
python3 /evidence/audit-full.py
