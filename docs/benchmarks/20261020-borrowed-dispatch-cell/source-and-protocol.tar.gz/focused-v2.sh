#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
for role in reference candidate; do
 cd /$role
 go test . -tags gts_parsercorephase0 -run "^Test(DiagnosticParserCore.*Reduction.*|DiagnosticParserCoreClassifiedBoundaryAndReductionPlanShape|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|G18(RefSet.*|AuthenticGenericReductionEstablishesProducerCohort|GenericReductionLeavesDropCohortsInertByDefault|FrontierHeaderReplacementAndRollbackPropagation)|CompactAcceptanceCachedPublicationStopControl)$" -count=1 -v -timeout=8m > "/evidence/$role-root-focused.log" 2>&1
 go build -tags gts_parsercorephase0 -gcflags='github.com/odvcencio/gotreesitter=-m=2' . > "/evidence/$role-escape-analysis.log" 2>&1
done
cd /candidate
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run "^Test(DiagnosticParserCore.*Reduction.*|DiagnosticParserCoreClassifiedBoundaryAndReductionPlanShape|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|G18(RefSet.*|AuthenticGenericReductionEstablishesProducerCohort|GenericReductionLeavesDropCohortsInertByDefault|FrontierHeaderReplacementAndRollbackPropagation)|CompactAcceptanceCachedPublicationStopControl)$" -count=1 -v -timeout=8m > /evidence/root-386.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
