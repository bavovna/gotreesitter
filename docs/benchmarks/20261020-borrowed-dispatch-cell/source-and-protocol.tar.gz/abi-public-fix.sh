#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /public
go test . -tags gts_parsercorephase0 -run '^TestG18RefSetSchedulerRecordSizeRatchets$' -count=1 -v -timeout=5m > /evidence/abi-public-amd64.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^TestG18RefSetSchedulerRecordSizeRatchets$' -count=1 -v -timeout=5m > /evidence/abi-public-386.log 2>&1
go run ./cmd/v1layout > /evidence/abi-public-layout.log 2>&1
go run ./cmd/v1guard -root /public > /evidence/abi-public-v1guard.log 2>&1
printf 'complete\n' > /evidence/abi-public-complete.txt
