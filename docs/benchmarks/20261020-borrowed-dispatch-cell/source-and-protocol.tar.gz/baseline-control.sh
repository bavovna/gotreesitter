#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
for role in reference candidate; do
 cd /$role
 for label in foreign telemetry_go_query; do
  if [[ "$label" = foreign ]]; then pattern='^TestG18DropPathRejectsForeignInlineRED$'; else pattern='^TestG18D6aProducerTelemetry$/^go$/^query_compile$'; fi
  status=0
  go test . -tags gts_parsercorephase0 -run "$pattern" -count=1 -v -timeout=5m > "/evidence/$role-$label.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "/evidence/$role-$label-status.txt"
  if (( status > 1 )); then exit "$status"; fi
 done
done
