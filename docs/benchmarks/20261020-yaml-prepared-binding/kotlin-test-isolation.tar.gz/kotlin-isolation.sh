#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=2 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/kotlin-isolation-overlay.json'
for role in reference64 reference candidate; do
 cd /$role
 go test . -run 'Kotlin' -count=5 -v -timeout=8m > "/evidence/kotlin-isolated-$role.log" 2>&1
done
cd /candidate
go test . -race -run '^TestKotlinCompactCertification' -count=3 -v -timeout=8m > /evidence/kotlin-isolated-race.log 2>&1
go test . -run '^TestKotlinCompactCertification' -shuffle=41801 -count=5 -v -timeout=8m > /evidence/kotlin-isolated-shuffle.log 2>&1
printf 'complete\n' > /evidence/kotlin-isolation-complete.txt
