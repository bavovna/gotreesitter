#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
for role in reference64 reference candidate; do
 cd /$role
 status=0
 go test . -run '^TestKotlinCompactCertificationObjectDeclarationAcceptsProductionTreeWhenSplitDropsForced$' -count=1 -v -timeout=5m > "/evidence/kotlin-$role.log" 2>&1 || status=$?
 printf '%s\n' "$status" > "/evidence/kotlin-$role-status.txt"
 if (( status > 1 )); then exit "$status"; fi
done
