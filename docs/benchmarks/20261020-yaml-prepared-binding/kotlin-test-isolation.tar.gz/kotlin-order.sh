#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=2 GOFLAGS='-p=1 -buildvcs=false'
for role in reference64 reference candidate; do
 cd /$role
 set +e
 go test . -run 'Kotlin' -count=5 -v -timeout=10m > "/evidence/kotlin-order-$role.log" 2>&1
 status=$?
 set -e
 printf '%s\n' "$status" > "/evidence/kotlin-order-$role-status.txt"
 test "$status" -le 1
done
