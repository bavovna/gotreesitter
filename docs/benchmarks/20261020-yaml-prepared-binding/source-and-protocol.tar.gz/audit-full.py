from pathlib import Path
import json,hashlib,re
p=Path('/evidence');out=p/'out/candidate'
for n in ['yaml-unit.log','yaml-race.log','yaml-386.log']:
 s=(p/n).read_text();assert '\nPASS\n' in s and '--- FAIL' not in s and '--- SKIP' not in s,n
assert '756/756 root Go files, 12 API tag sets' in (p/'layout.log').read_text()
assert '454 language-name uses and 101 environment reads' in (p/'v1guard.log').read_text()
for n in ['memory-pooling.log','invariant-yaml.log','owned-yaml-invariant.log','c-yaml.log','strict-yaml.log','yaml-large-c.log','yaml-parse-race.log']:
 s=(out/n).read_text();assert '\nPASS\n' in s and '--- FAIL' not in s and '--- SKIP' not in s,n
for n in ['invariant-yaml.log','owned-yaml-invariant.log','yaml-parse-race.log']:assert 'session_steps=72 no_edit_allocs=0' in (out/n).read_text(),n
assert 'owned initial compact=1 fallback=0' in (out/'owned-yaml-invariant.log').read_text()
rows=0
for a,b in [('reference-ledger.json','ledger.json'),('reference-owned-yaml-ledger.json','owned-yaml-ledger.json')]:
 before=json.loads((p/a).read_text());after=json.loads((out/b).read_text());assert before==after,(a,b);rows+=len(after['rows'])
assert rows==414
before=json.loads((p/'reference-canonical-work.json').read_text())['candidate'];after={}
for line in (out/'canonical-work.log').read_text().splitlines():
 if 'CANONICAL_WORK_CENSUS ' in line:
  r=json.loads(line.split('CANONICAL_WORK_CENSUS ',1)[1]);after[r['Fixture']]=r
assert before==after and len(after)==4
errors=json.loads((p/'yaml-errors/audit.json').read_text());assert errors['cases']==723 and errors['reference_passes']==errors['candidate_passes']==417
assert not errors['new_failures'] and not errors['improved'] and not errors['changed_public_vectors']
pins=json.loads((p/'candidate-source-pins.json').read_text());assert len(pins)==3524
for f,h in pins.items():assert hashlib.sha256((Path('/candidate')/f).read_bytes()).hexdigest()==h,f
report=dict(baseline_runtime='f28a3c1cfca394fa378bf5994fead01c3886e73b',candidate_go_files=3524,measured_go_files=3,scope='YAML prepared immutable scanner binding and identity validity masks; no root/core engine changes',scanner_value_bytes_amd64=8,scanner_value_bytes_386=4,ledger_complete_rows_exact=414,canonical_complete_vectors_and_trees_exact=4,affected_languages=['yaml'],ordinary_and_owned_sessions=2,steps_per_session=72,no_edit_allocations=0,locked_c_fixture_checks=3,strict_yaml_c_exact=True,large_yaml_c_witnesses_pass=True,supplemental_yaml_c_cases=723,supplemental_passes=417,known_supplemental_failures=306,all_supplemental_public_vectors_exact=True,root_yaml_parse_race_pass=True,scanner_unit_race_386_pass=True,memory_and_pooling_pass=True,api_layout_r6_pass=True,work_direction_passed=True,held_plan_and_go_correctness_changes_included=False)
(p/'full-counter-gate.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
