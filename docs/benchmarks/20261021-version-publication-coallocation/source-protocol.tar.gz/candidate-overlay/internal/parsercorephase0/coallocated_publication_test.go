package parsercorephase0

import "testing"

func TestCoallocatedPublicationExactImmutableValue(t *testing.T) {
	type value struct {
		owner             *int
		request, baseline uint32
		set               bool
	}
	owner := new(int)
	want := value{owner: owner, request: ^uint32(0), baseline: ^uint32(0), set: true}
	publication := NewCoallocatedPublication(want)
	published := publication.Match(want)
	if published == nil || !publication.Owns(published) {
		t.Fatal("exact publication was not embedded")
	}
	for _, other := range []value{{owner: owner, request: 1, baseline: want.baseline, set: true}, {owner: owner, request: want.request, baseline: 1, set: true}, {owner: owner, request: want.request, baseline: want.baseline}, {owner: new(int), request: want.request, baseline: want.baseline, set: true}} {
		if publication.Match(other) != nil {
			t.Fatal("distinct ownership/value matched")
		}
	}
	copy := publication
	if copy.Owns(published) || copy.Match(want) == published || *published != want {
		t.Fatal("copied owner aliased original storage")
	}
	if n := testing.AllocsPerRun(100, func() {
		if publication.Match(want) != published {
			panic("unstable publication")
		}
	}); n != 0 {
		t.Fatalf("matching allocated %v", n)
	}
}
