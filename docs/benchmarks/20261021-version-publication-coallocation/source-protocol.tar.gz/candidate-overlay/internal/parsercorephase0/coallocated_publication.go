package parsercorephase0

// CoallocatedPublication keeps one immutable publication inside its owner's
// existing stable storage. Construct the value before the owner escapes; never
// replace it while any publication pointer can remain live. The zero value has
// no special lifecycle meaning and matches only the exact zero value.
type CoallocatedPublication[T comparable] struct{ value T }

func NewCoallocatedPublication[T comparable](value T) CoallocatedPublication[T] {
	return CoallocatedPublication[T]{value: value}
}

// Match returns the embedded immutable value only for exact value equality.
func (p *CoallocatedPublication[T]) Match(value T) *T {
	if p == nil || p.value != value {
		return nil
	}
	return &p.value
}

// Owns identifies a publication whose bytes are already included in this owner.
func (p *CoallocatedPublication[T]) Owns(value *T) bool {
	return p != nil && value == &p.value
}
