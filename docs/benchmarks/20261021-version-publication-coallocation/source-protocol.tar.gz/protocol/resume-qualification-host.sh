#!/usr/bin/env bash
set -euo pipefail
gts_lab=/home/draco/.local/state/gotreesitter-evidence/20261021-version-publication-coallocation
gts_runner=/home/draco/.local/state/gotreesitter-evidence/20261018-go-legacy-candidates/offline-runner/cgo_harness/docker/run_parity_in_docker.sh
gts_args=(--repo-root /home/draco/work/gotreesitter --no-build --image sha256:187907888b4bdc6f326c87b045718339e5f665baceb27db6b74633ca41e996df --memory 6g --cpus 1 --cpuset-cpus 6 --gomemlimit 5GiB --mount /home/draco/.local/state/gotreesitter-evidence/20261020-public-subtree-blocks-64k/candidate-source:/baseline:ro --mount /home/draco/.local/state/gotreesitter-evidence/20261021-native-node-slab-tail/candidate-source:/reference:ro --mount "$gts_lab/candidate-source:/candidate:ro" --mount /home/draco/.local/state/nightwatch/gts-docker.lock:/gts-locks/nightwatch.lock --mount /tmp/gts-docker.lock:/gts-locks/common.lock)
bash "$gts_runner" "${gts_args[@]}" --label publication-coallocation-qualify --mount "$gts_lab:/evidence" -- flock /gts-locks/nightwatch.lock flock /gts-locks/common.lock bash /evidence/resume-qualification-tail.sh > "$gts_lab/qualification-runner.log" 2>&1
