#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/qualification-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
test -f /evidence/core-first-complete.txt
cd /candidate
go test . -tags gts_parsercorephase0 -run '^Test(StreamedPrefixWorkspaceLifecycleAndAccounting|StreamedPrefixPublicationMetadata|SinglePrefixRejectsHistoricalOpaqueBindingSwap|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|DiagnosticParserCoreVersionLexer.*|FreshSnapshotPages.*|SnapshotPairFootprint.*|PackedSnapshotTrial.*)$' -count=1 -v -timeout=8m > /evidence/metadata-go.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=go go test . -tags gts_parsercorephase0 -run '^TestV1InvariantGateR4EditSession$' -count=1 -v -timeout=8m > /evidence/go-invariant.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=yaml go test . -tags gts_parsercorephase0 -run '^TestV1InvariantGateR4EditSession$' -count=1 -v -timeout=8m > /evidence/yaml-ordinary.log 2>&1
GTS_ADMISSION_CANDIDATE=1 go test . -tags gts_parsercorephase0 -run '^TestProgressArenaOwnedYAMLInvariant$' -count=1 -v -timeout=8m > /evidence/yaml-owned.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/yaml-c.test . > /evidence/cgo-build.log 2>&1
GTS_YAML_LARGE_PROBE=1 /evidence/yaml-c.test -test.run '^TestCompact(YAMLDocumentStreamLockedC|YAMLVersionOwnershipCOracle)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-c.log 2>&1
/evidence/yaml-c.test -test.run '^TestCompactLineageLargeGoLockedC$' -test.count=1 -test.v -test.timeout=8m > /evidence/go-large-c.log 2>&1
cd /candidate
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v -timeout=8m > /evidence/canonical-work.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/counter ./cmd/perfcounterledger > /evidence/counter-build.log 2>&1
/evidence/counter --write --output /evidence/ledger.json > /evidence/ledger.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/counter --langs yaml > /evidence/owned-yaml-ledger.json 2> /evidence/owned-yaml-ledger.log
python3 - <<'COUNTERS'
from pathlib import Path
import json
p=Path('/evidence')
for a,b in [('reference-ledger.json','ledger.json'),('reference-owned-yaml-ledger.json','owned-yaml-ledger.json')]:assert json.loads((p/a).read_text())==json.loads((p/b).read_text()),(a,b)
rows={}
for line in (p/'canonical-work.log').read_text().splitlines():
 if 'CANONICAL_WORK_CENSUS ' in line:
  r=json.loads(line.split('CANONICAL_WORK_CENSUS ',1)[1]);rows[r['Fixture']]=r
assert rows==json.loads((p/'reference-canonical-work.json').read_text())['candidate']
(p/'early-counter-gate.json').write_text(json.dumps(dict(passed=True,ledger_rows_exact=414,canonical_Go_vectors_exact=4))+'\n')
COUNTERS
printf 'complete\n' > /evidence/focused-complete.txt
