#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/qualification-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /candidate
python3 /evidence/audit-go-c.py
bash /evidence/verify-large-go.sh
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^Test(VersionPublicationCoallocation.*|DiagnosticParserCoreElectionSummaryMatchesFullReceipt|DiagnosticParserCoreVersionLexerElectionReusesCheckpointSerialization)$' -count=1 -v -timeout=8m > /evidence/out/candidate/root-386.log 2>&1
go test ./internal/parsercorephase0 -race -tags gts_eof_recovery_shadow -run '^TestDiagnostic(EOFRecoveryPathCount|NodeBlocks|SubtreeBlocks|LinkMetadata)' -count=1 -v -timeout=8m > /evidence/out/candidate/path-count-shadow-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -run '^TestDiagnostic(EOFRecoveryPathCount|NodeBlocks|SubtreeBlocks|LinkMetadata)' -count=1 -v -timeout=8m > /evidence/out/candidate/path-count-shadow-386.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -run '^Test(NodeRecordBlocks|SubtreeRecordBlocks|CompactLink|DiagnosticNodeBlocks|DiagnosticSubtreeBlocks|DiagnosticLinkMetadata)' -count=1 -v -timeout=8m > /evidence/out/candidate/node-blocks-386.log 2>&1
printf 'complete\n' > /evidence/qualify-complete.txt

bash /evidence/extra-core-modes.sh
python3 /evidence/audit-full.py > /evidence/full-audit.log 2>&1
