from pathlib import Path
import collections,hashlib,json,re
p=Path('/evidence');out=p/'out/candidate'
assert (p/'qualify-complete.txt').read_text().strip()=='complete'
assert (p/'final-core-modes-complete.txt').read_text().strip()=='complete'
assert json.loads((p/'rss/matched/audit.json').read_text())['candidate_safety_pass']
for a,b in [('reference-ledger.json','out/candidate/ledger.json'),('reference-owned-yaml-ledger.json','out/candidate/owned-yaml-ledger.json')]:assert json.loads((p/a).read_text())==json.loads((p/b).read_text())
languages=(p/'languages.txt').read_text().splitlines();assert len(languages)==206
for language in languages:
 text=(out/f'invariant-{language}.log').read_text();assert '--- PASS: TestV1InvariantGateR4EditSession' in text and 'session_steps=72' in text and 'no_edit_allocs=0' in text and '--- SKIP:' not in text
 text=(out/f'c-{language}.log').read_text();assert '--- SKIP' not in text and '--- FAIL' not in text
 for name in ['TestParityFreshParse','TestParityIncrementalParse','TestParityHasNoErrors']:assert f'--- PASS: {name}/{language} ' in text
strict=json.loads((out/'strict-census.json').read_text());baseline=json.loads((p/'production-strict-census.json').read_text());assert len(strict)==len(baseline)==204
assert {r['language']:r['status'] for r in strict}=={r['language']:r['status'] for r in baseline}
differences=json.loads((out/'strict-differences.json').read_text());assert all(r['language']=='yaml' and r['candidate']['status']=='PASS' and r['candidate']['compact']==1 for r in differences),differences
expanded=json.loads((p/'out/expanded-go-c-audit.json').read_text());assert expanded['all_306_statuses_equal'] and expanded['expanded_routes_exact']==300
modes={}
for name in ['core-default.log','core-shadow.log','core-phase0-shadow.log','core-phase0a-shadow.log','core-onepass-shadow.log']:
 text=(p/name).read_text();assert '--- FAIL' not in text and 'PASS' in text;modes[name]=len(re.findall(r'^--- PASS: \w+',text,re.M))
for name in ['root-default.log','memory-pooling.log','root-race.log','core-race.log','root-386.log','path-count-shadow-race.log','path-count-shadow-386.log','node-blocks-386.log','owned-yaml-invariant.log']:
 text=(out/name).read_text();assert '--- FAIL' not in text and '--- SKIP' not in text and 'PASS' in text,name
for name in ['go-large-c.log','yaml-c.log','large-go-c-verified.log']:
 text=(p/name).read_text();assert '--- FAIL' not in text and '--- SKIP' not in text and 'PASS' in text,name
pins=json.loads((p/'candidate-source-pins.json').read_text())
for rel,h in pins.items():assert hashlib.sha256((Path('/candidate')/rel).read_bytes()).hexdigest()==h,rel
report=dict(passed=True,ledger_rows_exact=414,canonical_Go_vectors_exact=4,invariant_languages=206,steps_per_session=72,C_fixture_checks=618,strict_rows_exact=204,strict_statuses=dict(collections.Counter(r['status'] for r in strict)),strict_route_changes=differences,expanded_Go_C_statuses_exact=306,expanded_Go_routes_exact=300,full_Core_suite_passes=modes,RSS_processes=189,source_pins_exact=len(pins),held_Go_repair_included=False,runtime_promoted=False)
(p/'full-counter-gate.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
