#!/usr/bin/env bash
set -euo pipefail
bash /evidence/qualify.sh
bash /evidence/extra-core-modes.sh
python3 /evidence/audit-full.py > /evidence/full-audit.log 2>&1
