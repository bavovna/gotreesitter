//go:build gts_parsercorephase0

package gotreesitter

import (
	"testing"
	"unsafe"

	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
)

func TestVersionPublicationCoallocationPreservesConflictAliasesAndRollback(t *testing.T) {
	_, before := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	_, after := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	header := diagnosticParserCoreHeader{}
	header.publishRecoveryCondenseState(0, 0, ^uint32(0), true)
	if !initializeFirstVersionPublication(before, header, ^uint32(0)) || !initializeFirstVersionPublication(after, header, 0) {
		t.Fatal("fresh publication was not initialized")
	}
	header.publishVersionState(nil, before, ^uint32(0), 0, 0, ^uint32(0), true)
	original := header.versionState
	if !diagnosticParserCoreVersionStateIsCoallocated(original) {
		t.Fatal("request publication allocated a separate wrapper")
	}
	sibling := header
	var scratch diagnosticParserCoreHeaderRollbackScratch
	headers := []diagnosticParserCoreHeader{header}
	if err := scratch.begin(headers); err != nil {
		t.Fatal(err)
	}
	headers[0].publishVersionState(nil, after, 0, 0, 0, ^uint32(0), true)
	if !diagnosticParserCoreVersionStateIsCoallocated(headers[0].versionState) || headers[0].versionState == original {
		t.Fatal("shift publication did not use its independent immutable value")
	}
	if sibling.versionState != original || sibling.versionLexerRequestReference() != ^uint32(0) || sibling.versionLexerSnapshot() != before {
		t.Fatal("shift changed a conflict sibling")
	}
	scratch.finish(&headers, true)
	if headers[0].versionState != original {
		t.Fatal("rollback did not restore the original owner")
	}
	if initializeFirstVersionPublication(before, header, 7) {
		t.Fatal("published cache was initialized twice")
	}
	if original.lexerRequest != ^uint32(0) {
		t.Fatal("initialization rewrote a published request")
	}
	if n := testing.AllocsPerRun(100, func() { header.publishVersionState(nil, before, ^uint32(0), 0, 0, ^uint32(0), true) }); n != 0 {
		t.Fatalf("exact publication allocated %v", n)
	}
}

func TestVersionPublicationCoallocationRebaseUsesFreshImmutableValue(t *testing.T) {
	_, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	header := diagnosticParserCoreHeader{}
	if !initializeFirstVersionPublication(snapshot, header, ^uint32(0)) {
		t.Fatal("initialization failed")
	}
	header.publishVersionState(nil, snapshot, ^uint32(0), 0, 0, 0, false)
	prior := header
	// beginNextVersionLexerElection rebases references through this publication.
	header.publishVersionState(nil, snapshot, 1, 0, 0, 0, false)
	if header.versionState == prior.versionState || diagnosticParserCoreVersionStateIsCoallocated(header.versionState) || header.versionLexerRequestReference() != 1 || prior.versionLexerRequestReference() != ^uint32(0) {
		t.Fatal("request rebasing overwrote or reused an unequal immutable value")
	}
	for _, args := range []struct {
		baseline uint32
		set      bool
	}{{^uint32(0), false}, {0, true}} {
		header.publishVersionState(nil, snapshot, ^uint32(0), 0, 0, args.baseline, args.set)
		if diagnosticParserCoreVersionStateIsCoallocated(header.versionState) {
			t.Fatal("baseline value/set mismatch reused a publication")
		}
	}
}

func TestVersionPublicationCoallocationRejectsRecoveryAndClosedAcceptanceGroups(t *testing.T) {
	for _, recovery := range []diagnosticParserCoreVersionRecoveryState{
		{Region: &diagnosticParserCoreS3Region{}}, {RecoveryGroup: ^uint64(0)}, {MissingGroup: ^uint64(0)}, {AcceptanceGroup: recoveredRootGroup{recovery: ^uint64(0), missing: ^uint64(0) - 1}},
	} {
		_, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
		clean := diagnosticParserCoreHeader{}
		if !initializeFirstVersionPublication(snapshot, clean, 7) {
			t.Fatal("clean initialization failed")
		}
		header := diagnosticParserCoreHeader{versionState: &diagnosticParserCoreVersionState{recovery: core.ReuseVersionRecoveryState(nil, recovery)}}
		if initializeFirstVersionPublication(&diagnosticParserCoreVersionLexerSnapshot{}, header, 7) {
			t.Fatal("recovery-bearing initial publication accepted")
		}
		old := header
		header.publishVersionState(recovery.Region, snapshot, 7, recovery.RecoveryGroup, recovery.MissingGroup, 0, false)
		if diagnosticParserCoreVersionStateIsCoallocated(header.versionState) || header.versionState == old.versionState {
			t.Fatal("recovery publication bypassed immutable allocation fallback")
		}
		if header.recoveryRegion() != recovery.Region || old.versionState.recovery.Value() != recovery {
			t.Fatal("recovery publication changed ownership")
		}
		want := recovery.AcceptanceGroup
		if recovery.RecoveryGroup != 0 || recovery.MissingGroup != 0 {
			want = recoveredRootGroup{recovery: recovery.RecoveryGroup, missing: recovery.MissingGroup}
		}
		if recoveredRootGroupOf(header) != want {
			t.Fatal("effective acceptance identity changed")
		}
	}
}

func TestVersionPublicationCoallocationCloneClearsSelfReferencingCache(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	header := diagnosticParserCoreHeader{}
	if !initializeFirstVersionPublication(snapshot, header, 0) {
		t.Fatal("initialization failed")
	}
	header.publishVersionState(nil, snapshot, 0, 0, 0, 0, false)
	original := header.versionState
	clone := snapshot.clone()
	if !diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) {
		t.Fatal("publication cache changed logical snapshot equality")
	}
	header.publishVersionState(nil, clone, 0, 0, 0, 0, false)
	if diagnosticParserCoreVersionStateIsCoallocated(header.versionState) || header.versionLexerSnapshot() != clone || original.relexSnapshot != snapshot {
		t.Fatal("clone retained the source cache or changed its published owner")
	}
	// Existing destination validation must run before any cache can be installed.
	bad := snapshot.clone()
	if !initializeFirstVersionPublication(bad, diagnosticParserCoreHeader{}, 0) {
		t.Fatal("clone initialization failed")
	}
	bad.coreGeneration++
	prior := header.versionState
	if err := header.publishOwnedVersionLexerSnapshot(compact, snapshot.language, bad); err == nil || header.versionState != prior {
		t.Fatal("invalid cached snapshot bypassed destination validation")
	}
}

func TestVersionPublicationCoallocationChargesRecordAndPageStorageOnce(t *testing.T) {
	var pages core.ScannerSnapshotPages[diagnosticParserCoreVersionLexerSnapshot]
	record, payload, start, end, storage := pages.NewPacked([]byte{1}, nil, nil)
	record.storage = storage
	record.dfa.externalPayload, record.dfa.externalTokenStart, record.dfa.externalTokenEnd = payload, start, end
	header := diagnosticParserCoreHeader{}
	if !initializeFirstVersionPublication(record, header, 0) {
		t.Fatal("initialization failed")
	}
	header.publishVersionState(nil, record, 0, 0, 0, 0, false)
	state := header.versionState
	if got, want := diagnosticParserCoreVersionStateFootprintBytes(state), diagnosticParserCoreVersionLexerSnapshotFootprintBytes(record); got != want {
		t.Fatalf("embedded wrapper charged twice: %d want %d", got, want)
	}
	scheduler := &diagnosticParserCoreGenericScheduler{headers: []diagnosticParserCoreHeader{header, header}, versionLexerSnapshotPages: pages, footprintRefs: make([]diagnosticParserCoreFootprintRef, 0, 32)}
	base := &diagnosticParserCoreGenericScheduler{versionLexerSnapshotPages: pages, footprintRefs: make([]diagnosticParserCoreFootprintRef, 0, 32)}
	got := diagnosticParserCoreSchedulerFootprintBytes(scheduler) - diagnosticParserCoreSchedulerFootprintBytes(base)
	want := 2 * uint64(unsafe.Sizeof(diagnosticParserCoreHeader{}))
	if got != want {
		t.Fatalf("page/embedded state was not charged exactly once: delta=%d want=%d", got, want)
	}
	external := *state
	scheduler.headers[0].versionState, scheduler.headers[1].versionState = &external, &external
	separate := diagnosticParserCoreSchedulerFootprintBytes(scheduler) - diagnosticParserCoreSchedulerFootprintBytes(base)
	if separate-got != uint64(unsafe.Sizeof(external)) {
		t.Fatalf("separate wrapper charge=%d want %d", separate-got, unsafe.Sizeof(external))
	}
	if n := testing.AllocsPerRun(100, func() { diagnosticParserCoreSchedulerFootprintBytes(scheduler) }); n != 0 {
		t.Fatalf("steady footprint allocated %v", n)
	}
	pages.Reset()
	if !diagnosticParserCoreVersionStateIsCoallocated(state) || state.relexSnapshot != record || state.lexerRequest != 0 {
		t.Fatal("page reset changed a live immutable publication")
	}
}

func TestVersionPublicationCoallocationChargesUnreferencedCurrentPageShapes(t *testing.T) {
	var pages core.ScannerSnapshotPages[diagnosticParserCoreVersionLexerSnapshot]
	_, _, _, _, _, small := pages.New([]byte{1}, nil, nil, make([]bool, 113))
	_, _, _, _, packed := pages.NewPacked([]byte{1}, nil, nil)
	scheduler := &diagnosticParserCoreGenericScheduler{versionLexerSnapshotPages: pages}
	empty := &diagnosticParserCoreGenericScheduler{}
	got := diagnosticParserCoreSchedulerFootprintBytes(scheduler) - diagnosticParserCoreSchedulerFootprintBytes(empty)
	if want := small.FootprintBytes() + packed.FootprintBytes(); got != want {
		t.Fatalf("unreferenced current pages charge=%d want=%d", got, want)
	}
	if n := testing.AllocsPerRun(100, func() { diagnosticParserCoreSchedulerFootprintBytes(scheduler) }); n != 0 {
		t.Fatalf("steady current-page footprint allocated %v", n)
	}
}
