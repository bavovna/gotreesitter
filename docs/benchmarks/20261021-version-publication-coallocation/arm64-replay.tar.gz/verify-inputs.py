#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
assert len(sys.argv)==3,'usage: verify-inputs.py BASELINE_ROOT CANDIDATE_ROOT'
protocol=Path(__file__).resolve().parent
for role,root in zip(('baseline','candidate'),map(Path,sys.argv[1:])):
 manifest=json.loads((protocol/(role+'-manifest.json')).read_text())
 actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
 assert actual==set(manifest),(role,'restore only files listed in the manifest')
 for name,want in manifest.items():
  p=root/name;assert not p.is_symlink() and p.stat().st_size==want['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==want['sha256'],str(p)
print('authenticated approved inputs')
