#!/usr/bin/env bash
set -euo pipefail
test -f /approval/qualification-approved.json
test "$(go env GOVERSION)" = go1.25.14
test "$(go env GOARCH)" = arm64
test "$(go env GOOS)" = linux
export GOWORK=off GOTOOLCHAIN=local GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env -json GOOS GOARCH GOVERSION GOTOOLCHAIN GOMODCACHE GOCACHE > /evidence/go-environment.json
cd /candidate
bash /protocol/run_randomized_benchmarks.sh --lock-path /tmp/gotreesitter-mac-randomized.lock --output /evidence/go-after.txt --baseline-root /reference --baseline-output /evidence/go-before.txt --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr,BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib --runs 20 --seed-start 48301 --benchtime 750ms > /evidence/go-runner.log 2>&1
bash /protocol/run_randomized_benchmarks.sh --lock-path /tmp/gotreesitter-mac-randomized.lock --output /evidence/yaml-after.txt --baseline-root /reference --baseline-output /evidence/yaml-before.txt --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned --runs 20 --seed-start 48201 --benchtime 750ms > /evidence/yaml-runner.log 2>&1
printf 'complete\n' > /evidence/complete.txt
