from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent
repo=Path('/home/draco/.codex/worktrees/public-subtree-block-storage-64k/gotreesitter')
out=repo/'docs/benchmarks/20261020-public-subtree-blocks-64k'
read=lambda n:json.loads((p/n).read_text())
assert read('full-counter-gate.json')['passed'] and read('final-core-mode-audit.json')['passed']
assert read('rss/rss-matched/audit.json')['candidate_safety_pass']
assert (p/'perf/complete.txt').read_text().strip()=='complete'
perf=read('perf-summary.json');assert perf['benchmark_rows']==480
bp,cp=read('reference-source-pins.json'),read('candidate-source-pins.json')
assert len(bp)==3535 and len(cp)==3541
reference=p.parent/'20261020-go-gss-block-cached-safe/candidate-source'
for root,pins in [(reference,bp),(p/'candidate-source',cp)]:
 for rel,h in pins.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==h,rel
out.mkdir(parents=True,exist_ok=True)
protocol={};qualification={};measurements={}
def add(d,rel,f):d[rel]=f.read_bytes()
for rel,h in cp.items():
 if bp.get(rel)!=h:add(protocol,'candidate-overlay/'+rel,p/'candidate-source'/rel)
for f in p.iterdir():
 if not f.is_file():continue
 if f.suffix in ['.py','.sh'] or f.name.endswith('.go.txt') or f.name=='rewrite-subtree-store.go' or f.name in ['source-provenance.json','reference-source-pins.json','candidate-source-pins.json','reference-ledger.json','reference-owned-yaml-ledger.json','reference-canonical-work.json','production-strict-census.json','languages.txt','qualification-overlay.json','large-overlay.json','first-build-source-pins.json','second-build-source-pins.json','third-build-source-pins.json']:
  add(protocol,'protocol/'+f.name,f)
 if f.suffix=='.log' and not f.name.startswith('buckley') or f.name.endswith('complete.txt') or f.name in ['full-counter-gate.json','final-core-mode-audit.json']:
  add(qualification,f.name,f)
 if f.name in ['perf-summary.json','go-benchstat.txt','yaml-benchstat.txt','post-perf-pins.json','qualification-summary.json']:add(measurements,f.name,f)
for folder in ['first-build-overlay','second-build-overlay','third-build-overlay']:
 for f in (p/folder).rglob('*'):
  if f.is_file():add(protocol,'attempt-overlays/'+str(f.relative_to(p)),f)
for f in (p/'out').rglob('*'):
 if f.is_file() and f.suffix in ['.log','.txt','.json']:add(qualification,str(f.relative_to(p)),f)
for folder in ['rss','capacity']:
 for f in (p/folder).iterdir():
  if f.is_file() and (f.suffix in ['.sh','.py','.json'] or f.name.endswith('.go.txt') or f.name=='go-source.txt'):add(protocol,'protocol/'+str(f.relative_to(p)),f)
for folder in ['rss','capacity','perf']:
 for f in (p/folder).rglob('*'):
  if f.is_file() and f.suffix in ['.log','.rss','.txt','.json'] and not f.name.endswith('.go.txt') and f.name not in ['go-source.txt','overlay.json']:add(measurements,str(f.relative_to(p)),f)
manifest={};archives=[]
for name,files in [('source-protocol.tar.gz',protocol),('qualification.tar.gz',qualification),('measurements.tar.gz',measurements)]:
 rows={rel:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for rel,data in sorted(files.items())}
 with (out/name).open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as z:
   with tarfile.open(fileobj=z,mode='w') as t:
    for rel,data in sorted(files.items()):
     info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
 with tarfile.open(out/name) as t:
  assert len(t.getmembers())==len(rows)
  for m in t:
   data=t.extractfile(m).read();assert len(data)==rows[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==rows[m.name]['sha256'],m.name
 manifest[name]=rows;data=(out/name).read_bytes();archives.append(dict(name=name,bytes=len(data),members=len(rows),sha256=hashlib.sha256(data).hexdigest()))
(out/'archive-members.json').write_text(json.dumps(manifest,indent=2)+'\n')
r=dict(archives=archives,reference_code_commit='647ea982cdf2f6accedce5cda0705949f957acb8',reference_PR_head='98747629037d6934b9dcf6dfbb41db6d082a3078',reference_go_files=3535,candidate_go_files=3541,candidate_overlay_files=sum(bp.get(rel)!=h for rel,h in cp.items()),performance_ratchet_failures=perf['median_10_percent_failures'],promotion_eligible=not perf['median_10_percent_failures'],runtime_promoted=False)
(out/'archives.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
