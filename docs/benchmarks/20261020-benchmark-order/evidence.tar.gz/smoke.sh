#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false'
cd /reference
go test ./internal/benchorder -count=1 -v > /evidence/helper-normal.log 2>&1
go test ./internal/benchorder -race -count=1 -v > /evidence/helper-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/benchorder -count=1 -v > /evidence/helper-386.log 2>&1
for role in reference candidate; do
 cd "/$role"
 for seed in 39101 39104; do
  GTS_BENCHMARK_SEED="$seed" go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkCompactThroughputGo$' -benchtime=1x -benchmem -count=1 -shuffle="$seed" -timeout=5m > "/evidence/$role-go-$seed-smoke.log" 2>&1
  GTS_BENCHMARK_SEED="$seed" go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkCompactThroughputYAML$' -benchtime=1x -benchmem -count=1 -shuffle="$seed" -timeout=5m > "/evidence/$role-yaml-$seed-smoke.log" 2>&1
 done
done
printf 'complete\n' > /evidence/smoke-complete.txt
