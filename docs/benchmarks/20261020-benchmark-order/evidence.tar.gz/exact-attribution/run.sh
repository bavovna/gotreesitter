#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
for role in reference candidate; do
 cd "/$role"
 for seed in 39101 39102 39104; do
  go test . -tags gts_parsercorephase0 -run '^$' -bench '^Benchmark(StreamedPrefixGo|GoParseFullDFA|GoParseIncrementalSingleByteEditDFA|GoParseIncrementalNoEditDFA|GoParseCompactFreshOneMiB)$' -benchtime=750ms -benchmem -count=1 -shuffle="$seed" -timeout=5m > "/evidence/$role-$seed.log" 2>&1
 done
done
printf 'complete\n' > /evidence/complete.txt
