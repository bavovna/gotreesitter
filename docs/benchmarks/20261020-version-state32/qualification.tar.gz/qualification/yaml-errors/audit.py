from pathlib import Path
import json,re
p=Path('/evidence');roles={}
for role in ['reference','candidate']:
 rows={};metrics={}
 for line in (p/(role+'.jsonl')).read_text().splitlines():
  row=json.loads(line);name=row.get('Test','')
  if re.fullmatch(r'TestYAMLRecoveryGroupErrorCorpus/c[0-9]+_(legacy|ordinary|owned)',name):
   if row['Action'] in ['pass','fail','skip']:assert row['Action']!='skip';rows[name]=row['Action']
   output=row.get('Output','')
   if 'YAML_ERROR_CASE ' in output:
    text=output.split('YAML_ERROR_CASE ',1)[1]
    match=re.search(r'sha256=(\w+) bytes=(\d+) compact=(\d+) fallback=(\d+) nodes=(\d+) tokens=(\d+) max_versions=(\d+)',text)
    assert match,name
    metrics[name]=dict(zip(['sha256','bytes','compact','fallback','nodes','tokens','max_versions'],[match[1]]+[int(match[i]) for i in range(2,8)]))
 assert len(rows)==len(metrics)==723,(role,len(rows),len(metrics))
 for mode in ['legacy','ordinary','owned']:assert sum(k.endswith('_'+mode) for k in rows)==241,(role,mode)
 roles[role]=dict(status=rows,metrics=metrics)
a,b=roles['reference'],roles['candidate'];assert a['status'].keys()==b['status'].keys()
for name in a['metrics']:
 assert a['metrics'][name]['sha256']==b['metrics'][name]['sha256'] and a['metrics'][name]['bytes']==b['metrics'][name]['bytes'],name
new_failures=[k for k in a['status'] if a['status'][k]=='pass' and b['status'][k]!='pass']
improved=[k for k in a['status'] if a['status'][k]=='fail' and b['status'][k]=='pass']
changed_metrics={k:dict(before=a['metrics'][k],after=b['metrics'][k]) for k in a['metrics'] if a['metrics'][k]!=b['metrics'][k]}
report=dict(cases=len(a['status']),reference_passes=sum(v=='pass' for v in a['status'].values()),candidate_passes=sum(v=='pass' for v in b['status'].values()),new_failures=new_failures,improved=improved,changed_public_vectors=changed_metrics,roles=roles)
(p/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='roles'},indent=2))
assert not new_failures,new_failures
(p/'complete.txt').write_text('complete\n')
