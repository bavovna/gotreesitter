#!/usr/bin/env bash
set -euo pipefail
lab=/home/draco/.local/state/gotreesitter-evidence/20261019-version-state-cold-recovery-main
wait_deadline=$((SECONDS+7200))
while [[ ! -f "$lab/focused-complete.txt" ]]; do
 if (( SECONDS >= wait_deadline )); then echo 'Focused prerequisite still incomplete; qualification not started'; exit 1; fi
 if [[ -f "$lab/focused-runner.log" ]] && rg -q '^exit_code: [1-9]|^oom_killed: true|^wall_timed_out: true' "$lab/focused-runner.log"; then echo 'Focused prerequisite failed; qualification not started'; exit 1; fi
 sleep 2
done
python3 "$lab/verify-source.py"
bash /home/draco/.local/state/gotreesitter-evidence/20261018-go-legacy-candidates/offline-runner/cgo_harness/docker/run_parity_in_docker.sh --repo-root /home/draco/work/gotreesitter --image sha256:187907888b4bdc6f326c87b045718339e5f665baceb27db6b74633ca41e996df --no-build --memory 6g --cpus 1 --cpuset-cpus 6 --gomemlimit 5GiB --label version-state-cold-recovery-control-qualification --mount /home/draco/.local/state/gotreesitter-evidence/20261019-main-integration/candidate-source:/reference:ro --mount "$lab/candidate-source:/candidate:ro" --mount "$lab:/evidence" --mount /home/draco/.local/state/nightwatch/gts-docker.lock:/gts-locks/nightwatch.lock --mount /tmp/gts-docker.lock:/gts-locks/common.lock -- 'export PATH=/usr/local/go/bin:$PATH; flock /gts-locks/nightwatch.lock flock /gts-locks/common.lock bash -c "bash /evidence/baseline.sh && bash /evidence/core-screen.sh && bash /evidence/guards.sh && bash /evidence/qualify.sh && bash /evidence/large-c.sh && python3 /evidence/audit-full.py"' > "$lab/qualification-runner.log" 2>&1
