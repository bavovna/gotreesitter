#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/focused-complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
cp /evidence/core.log /evidence/core-normal.log
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_parsercorephase0a -count=1 -timeout=8m > /evidence/core-phase0a.log 2>&1
go test ./internal/parsercorephase0 -tags gts_parsercorephase0_selectedstore_onepass -count=1 -timeout=8m > /evidence/core-onepass.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test ./internal/parsercorephase0 -run '^TestVersionRecoveryState' -count=1 -v -timeout=8m > /evidence/core-386.log 2>&1
go test . -tags gts_parsercorephase0 -run '^TestDiagnosticParserCorePerVersionState(KeepsHeaderSize|CloseDoesNotMutateSnapshot|RollbackRestoresCopy|SetNilCloses)$' -count=1 -v -timeout=8m > /evidence/root-recovery-lifecycle.log 2>&1
printf 'complete\n' > /evidence/core-complete.txt
