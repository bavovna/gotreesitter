#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
test -s /evidence/core.log # Byte-identical Core inputs already passed the full normal suite.
go test . -tags gts_parsercorephase0 -run '^(TestVersionStateStorage.*|TestVersionLexer(InterningPreservesClosedAcceptanceGroup|OwnershipPreservesEffectiveAcceptanceGroup)|TestDiagnosticParserCore(SchedulerFootprintCountsWideSharedVersionStates|CanonicalKeyAndGroupSnapshotsAreAccounted|PerVersionStatePublishesImmutableCopies))$' -count=1 -v -timeout=8m > /evidence/root.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test . -tags gts_parsercorephase0 -run '^TestVersionStateStorage.*$' -count=1 -v -timeout=8m > /evidence/386.log 2>&1
go test . -race -tags gts_parsercorephase0 -run '^TestVersionStateStorage.*$' -count=1 -v -timeout=8m > /evidence/race.log 2>&1
go test ./internal/parsercorephase0 -race -run '^TestVersionRecoveryState' -count=1 -v -timeout=8m > /evidence/core-race.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
