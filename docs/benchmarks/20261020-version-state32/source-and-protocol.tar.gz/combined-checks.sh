#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
mkdir -p /evidence/combined-checks-v4
cd /reference
if CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^TestDiagnosticParserCorePerVersionStateKeepsHeaderSize$' -count=1 -v > /evidence/combined-checks-v4/baseline-386-header.log 2>&1; then
 echo 'baseline architecture mismatch did not reproduce';exit 1
fi
python3 - <<'CHECK'
from pathlib import Path
assert 'header is 76 bytes, want 80' in Path('/evidence/combined-checks-v4/baseline-386-header.log').read_text()
CHECK
cd /public-combined
go test ./internal/benchorder -count=1 -v > /evidence/combined-checks-v4/helper.log 2>&1
go test ./internal/parsercorephase0 -run '^TestVersionRecoveryStatePreservesFullIdentity$' -count=1 -v > /evidence/combined-checks-v4/core.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(VersionStateStorage.*|DiagnosticParserCorePerVersionStateKeepsHeaderSize|DiagnosticParserCoreCheckpointCompactLayoutsAMD64)$' -count=1 -v -timeout=5m > /evidence/combined-checks-v4/root.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^Test(VersionStateStorage.*|DiagnosticParserCorePerVersionStateKeepsHeaderSize)$' -count=1 -v -timeout=5m > /evidence/combined-checks-v4/root-386.log 2>&1
go run ./cmd/v1layout > /evidence/combined-checks-v4/layout.log 2>&1
go run ./cmd/v1guard -root /public-combined > /evidence/combined-checks-v4/v1guard.log 2>&1
printf 'complete\n' > /evidence/combined-checks-v4/complete.txt
