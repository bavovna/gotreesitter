#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false'
mkdir -p /evidence/public-checks-v3
cd /public
go test ./internal/benchorder -count=1 -v > /evidence/public-checks-v3/helper-normal.log 2>&1
go test ./internal/benchorder -race -count=1 -v > /evidence/public-checks-v3/helper-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/benchorder -count=1 -v > /evidence/public-checks-v3/helper-386.log 2>&1
GTS_BENCHMARK_SEED=39101 go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkCompactThroughputGo$' -benchtime=1x -benchmem -count=1 -shuffle=39101 -timeout=5m > /evidence/public-checks-v3/go-smoke.log 2>&1
GTS_BENCHMARK_SEED=39101 go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkCompactThroughputYAML$' -benchtime=1x -benchmem -count=1 -shuffle=39101 -timeout=5m > /evidence/public-checks-v3/yaml-smoke.log 2>&1
if GTS_BENCHMARK_SEED=invalid go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkCompactThroughputGo$' -benchtime=1x -count=1 > /evidence/public-checks-v3/invalid-seed.log 2>&1; then
 echo 'invalid seed unexpectedly accepted';exit 1
fi
python3 - <<'CHECK'
from pathlib import Path
s=Path('/evidence/public-checks-v3/invalid-seed.log').read_text()
assert 'GTS_BENCHMARK_SEED must contain an explicit integer seed' in s and 'FAIL' in s
for language in ('go','yaml'):
 a=Path(f'/evidence/reference-{language}-39101-smoke.log').read_text()
 b=Path(f'/evidence/public-checks-v3/{language}-smoke.log').read_text()
 rows=lambda s:[line.split() for line in s.splitlines() if line.startswith('Benchmark')]
 x,y=rows(a),rows(b)
 assert len(x)==len(y)==6 and [r[0] for r in x]==[r[0] for r in y]
 if language=='go':
  one=lambda rows:next(r for r in rows if '/fresh_one_mib' in r[0])
  x,y=one(x),one(y)
  assert x[x.index('B/op')-1]==y[y.index('B/op')-1] and x[x.index('allocs/op')-1]==y[y.index('allocs/op')-1]
CHECK
go run ./cmd/v1layout > /evidence/public-checks-v3/layout.log 2>&1
go run ./cmd/v1guard -root /public > /evidence/public-checks-v3/v1guard.log 2>&1
printf 'complete\n' > /evidence/public-checks-v3/complete.txt
