from pathlib import Path
import json
lab=Path(__file__).resolve().parent
assert (lab/'smoke-complete.txt').exists()
for language in ('go','yaml'):
 orders=[]
 for seed in (39101,39104):
  roles=[]
  for role in ('reference','candidate'):
   s=(lab/f'{role}-{language}-{seed}-smoke.log').read_text()
   assert '\nPASS\n' in s and 'FAIL' not in s
   rows=[line.split() for line in s.splitlines() if line.startswith('Benchmark')]
   assert len(rows)==6
   roles.append(rows)
  assert [r[0] for r in roles[0]]==[r[0] for r in roles[1]]
  orders.append([r[0] for r in roles[0]])
  if language=='go':
   a,b=[next(r for r in rows if '/fresh_one_mib' in r[0]) for rows in roles]
   assert a[a.index('B/op')-1]==b[b.index('B/op')-1]
   assert a[a.index('allocs/op')-1]==b[b.index('allocs/op')-1]
 assert orders[0]!=orders[1]
(lab/'smoke-audit.json').write_text(json.dumps({'matched_orders':True,'large_go_allocations_exact_per_seed':True,'rows':48,'scope':'Smoke only; not timing or ratchet evidence.'},indent=2)+'\n')
