#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
export PATH=/opt/homebrew/bin:/usr/local/bin:$PATH
[[ $# == 0 ]]
gts_protocol=$REMOTE_COMPUTE_ROOT/fused-checkpoint-screen-perf-protocol
gts_run=$REMOTE_COMPUTE_ROOT/fused-checkpoint-screen-perf-v1
gts_baseline=$REMOTE_COMPUTE_ROOT/packed64-source-v1
gts_candidate=$REMOTE_COMPUTE_ROOT/fused-checkpoint-source-v1
gts_cache=$REMOTE_CACHE_ROOT
gts_compute_lock=$REMOTE_STATE_ROOT/compute.lock
gts_image=golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437
[[ "$(uname -s)" = Darwin && "$(uname -m)" = arm64 ]]
[[ -d "$gts_cache/gomod" && -d "$gts_cache/gobuild" && -f "$gts_compute_lock" ]]
docker image inspect "$gts_image" >/dev/null
python3 "$gts_protocol/verify-inputs.py" approved
mkdir "$gts_run/perf"
python3 - "$gts_protocol" "$gts_run" <<'PY'
from pathlib import Path
import json,platform,subprocess,sys
p,r=map(Path,sys.argv[1:3]);from importlib.util import spec_from_file_location,module_from_spec
s=spec_from_file_location('verify',p/'verify-inputs.py');v=module_from_spec(s);s.loader.exec_module(v)
m=v.verify_protocol();gate=v.verify_gate(m)
result={'protocol':m,'screen_approval':gate,'host_platform':platform.platform(),'host_machine':platform.machine(),'docker_version':subprocess.check_output(['docker','version','--format','{{json .}}'],text=True),'image_inspect':json.loads(subprocess.check_output(['docker','image','inspect',m['image']],text=True)),'container':{'platform':'linux/arm64','cpuset':'2,3','cpus':2,'memory':'4g','GOMEMLIMIT':'3GiB','GOMAXPROCS':1,'GOFLAGS':'-p=1 -mod=readonly -buildvcs=false','network':'none','cache_bind':'$REMOTE_CACHE_ROOT:/cache','GOCACHE':'/cache/gobuild','GOMODCACHE':'/cache/gomod','shared_compute_lock':'$REMOTE_STATE_ROOT/compute.lock'},'cross_host_pooling_allowed':False,'preliminary_screen_only':True,'engine_PR_allowed':False,'runtime_promotion_allowed':False}
(r/'perf/execution.json').write_text(json.dumps(result,indent=2)+'\n')
PY
docker create --name gts-mac-fused-checkpoint-screen-arm64-20261021-v1 --label gotreesitter.compute=fused-checkpoint-screen-arm64 \
 --platform linux/arm64 --network none --cpus 2 --cpuset-cpus 2,3 --memory 4g --memory-swap 4g --pids-limit 256 \
 --env GOMEMLIMIT=3GiB --env GOCACHE=/cache/gobuild --env GOMODCACHE=/cache/gomod \
 --mount "type=bind,src=$gts_cache,dst=/cache" --mount "type=bind,src=$gts_compute_lock,dst=/compute.lock" \
 --mount "type=bind,src=$gts_baseline,dst=/reference,readonly" --mount "type=bind,src=$gts_candidate,dst=/candidate,readonly" \
 --mount "type=bind,src=$gts_protocol,dst=/protocol,readonly" \
 --mount "type=bind,src=$gts_run/screen-approved.json,dst=/approval/screen-approved.json,readonly" \
 --mount "type=bind,src=$gts_run/perf,dst=/evidence" --workdir /candidate "$gts_image" flock /compute.lock bash /protocol/run-in-container.sh > "$gts_run/perf/container-id.txt"
gts_container=$(cat "$gts_run/perf/container-id.txt")
docker image inspect "$gts_image" --format '{{json .RepoDigests}} {{.Os}}/{{.Architecture}}' > "$gts_run/perf/image.txt"
set +e
docker start -a "$gts_container" > "$gts_run/perf/container.log" 2>&1
gts_run_exit=$?
set -e
docker inspect "$gts_container" --format '{{json .State}}' > "$gts_run/perf/container-state.json"
printf '%s\n' "$gts_run_exit" > "$gts_run/perf/host-exit.txt"
docker rm "$gts_container" > "$gts_run/perf/container-cleanup.txt"
python3 - "$gts_run/perf/container-state.json" <<'GTS_TERMINAL_STATE'
import json,sys
state=json.load(open(sys.argv[1]));assert state['Status']=='exited' and state['ExitCode']==0 and not state['OOMKilled'],state
GTS_TERMINAL_STATE
((gts_run_exit == 0)) || exit "$gts_run_exit"
python3 "$gts_protocol/verify-inputs.py" approved > "$gts_run/perf/final-source-verification.txt"
python3 "$gts_protocol/audit-perf.py" "$gts_run"
