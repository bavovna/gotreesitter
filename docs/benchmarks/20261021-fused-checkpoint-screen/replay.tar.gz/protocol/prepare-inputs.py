#!/usr/bin/env python3
from pathlib import Path
from importlib.util import spec_from_file_location,module_from_spec
import hashlib,json,os,sys
sys.dont_write_bytecode=True
P=Path('$REMOTE_COMPUTE_ROOT/fused-checkpoint-screen-perf-protocol');spec=spec_from_file_location('verify',P/'verify-inputs.py');v=module_from_spec(spec);spec.loader.exec_module(v);meta=v.verify_protocol()
assert not v.C.exists() and not v.R.exists(),'preserve any existing or partial output; explicit review required before retry'
before=json.loads((P/'baseline-manifest.json').read_text());after=json.loads((P/'candidate-manifest.json').read_text());v.verify_source(v.B,before)
v.R.mkdir();v.C.mkdir()
try:
 for name in before:
  destination=v.C/name;destination.parent.mkdir(parents=True,exist_ok=True);os.link(v.B/name,destination)
 for row in meta['changes']:
  name=row['path'];path=P/'candidate-overlay'/name;data=path.read_bytes();assert len(data)==row['after']['bytes'] and hashlib.sha256(data).hexdigest()==row['after']['sha256'];destination=v.C/name;destination.parent.mkdir(parents=True,exist_ok=True);temp=destination.with_name(destination.name+'.fused-checkpoint-tmp');assert not temp.exists();temp.write_bytes(data);os.replace(temp,destination)
 v.verify_source(v.B,before);v.verify_source(v.C,after)
 (v.R/'input-preparation.json').write_text(json.dumps({'passed':True,'baseline_commit':meta['baseline_commit'],'candidate_commit':meta['candidate_commit'],'baseline_manifest_sha256':meta['baseline_manifest_sha256'],'candidate_manifest_sha256':meta['candidate_manifest_sha256'],'baseline_files':len(before),'candidate_files':len(after),'hardlink_clone':True,'atomic_overlay_files':4,'shared_inode_chmod':False,'original_baseline_preserved':True,'scope':meta['scope'],'timing_executed':False},indent=2)+'\n')
except BaseException as error:
 (v.R/'preparation-failure.json').write_text(json.dumps({'passed':False,'error':repr(error),'partial_outputs_preserved':True,'timing_executed':False},indent=2)+'\n');raise
print('authenticated M-to-E clone; parent focused-screen approval required')
