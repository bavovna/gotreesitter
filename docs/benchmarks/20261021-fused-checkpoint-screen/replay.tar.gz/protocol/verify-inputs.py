#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re,sys
sys.dont_write_bytecode=True
P=Path('$REMOTE_COMPUTE_ROOT/fused-checkpoint-screen-perf-protocol');R=Path('$REMOTE_COMPUTE_ROOT/fused-checkpoint-screen-perf-v1');B=Path('$REMOTE_COMPUTE_ROOT/packed64-source-v1');C=Path('$REMOTE_COMPUTE_ROOT/fused-checkpoint-source-v1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify_source(root,manifest):
 actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
 assert actual==set(manifest),{'root':str(root),'missing':sorted(set(manifest)-actual),'extra':sorted(actual-set(manifest))}
 for name,want in manifest.items():
  rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts;f=root/rel;assert f.is_file() and not f.is_symlink() and f.stat().st_size==want['bytes'] and sha(f)==want['sha256'],str(f)
def verify_protocol():
 expected=json.loads((P/'protocol-file-manifest.json').read_text());assert {str(f.relative_to(P)) for f in P.rglob('*') if f.is_file()}==set(expected)|{'protocol-file-manifest.json'}
 for name,want in expected.items():
  f=P/name;assert not f.is_symlink() and f.stat().st_size==want['bytes'] and sha(f)==want['sha256'],str(f)
 meta=json.loads((P/'protocol.json').read_text());assert meta['baseline_commit']=='73556f21928e68712de2f08452d05620334fee9e' and meta['candidate_commit']=='d342ff7afef564b0a6d1c368b50f4d86001bfece'
 for role in ['baseline','candidate']:assert sha(P/(role+'-manifest.json'))==meta[role+'_manifest_sha256']
 assert sha(P/'run_randomized_benchmarks.sh')==meta['randomized_runner_sha256']
 assert meta['scope']=='preliminary matched-pair screen only' and meta['full_engine_qualification_complete'] is False and meta['runtime_promotion_allowed'] is False and meta['engine_PR_allowed'] is False
 assert sha(P/'partial-qualification-receipt.json')==meta['partial_qualification_receipt_sha256']
 return meta
def verify_gate(meta):
 path=R/'screen-approved.json';gate=json.loads(path.read_text());assert gate.get('issued_by')=='parent' and gate.get('passed') is True
 for key in ['baseline_commit','candidate_commit','baseline_manifest_sha256','candidate_manifest_sha256']:assert gate.get(key)==meta[key],key
 assert gate.get('scope')=='preliminary matched-pair screen only'
 for key in ['full_engine_qualification_complete','full_206_invariant_gate_complete','full_618_C_gate_complete','full_RSS_gate_complete','engine_PR_allowed','runtime_promotion_allowed']:assert gate.get(key) is False,key
 for key in meta['required_parent_gates']:
  assert gate.get('gates',{}).get(key) is True,key
  assert isinstance(gate.get('evidence',{}).get(key),str) and gate['evidence'][key],key
  assert re.fullmatch('[0-9a-f]{64}',gate.get('evidence_sha256',{}).get(key,'')),key
 observed=gate.get('observed',{})
 for key,minimum in {'ledger_rows_exact':414,'canonical_Go_vectors_exact':4,'C_fixture_checks':6,'YAML_owned_and_document_stream_C_oracles':2,'native_internal_tests':16,'native_root_tests':7,'race_internal_tests':16,'race_root_tests':7,'386_internal_tests':16,'386_root_tests':6}.items():assert observed.get(key,0)>=minimum,key
 assert observed.get('edit_sessions')=={'go':72,'yaml':72,'yaml_owned':72} and observed.get('no_edit_allocations_zero') is True
 assert observed.get('focused_memory_contracts_passed') is True
 return {'path':str(path),'sha256':sha(path),'data':gate}
if __name__=='__main__':
 assert len(sys.argv)==2 and sys.argv[1] in ['candidate','all','approved'];meta=verify_protocol();verify_source(C,json.loads((P/'candidate-manifest.json').read_text()))
 if sys.argv[1] in ['all','approved']:verify_source(B,json.loads((P/'baseline-manifest.json').read_text()))
 if sys.argv[1]=='approved':verify_gate(meta)
 print('authenticated '+sys.argv[1]+' inputs')
