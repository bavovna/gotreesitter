#!/usr/bin/env python3
from pathlib import Path
from statistics import median
import hashlib,json,math,re,sys
assert len(sys.argv)==2,'usage: audit-perf.py ABSOLUTE_RUN_DIRECTORY'
run=Path(sys.argv[1]).resolve();perf=run/'perf'
assert (perf/'complete.txt').read_text().strip()=='complete'
execution=json.loads((perf/'public-execution.json').read_text());meta=execution['protocol']
assert meta['baseline_commit']=='73556f21928e68712de2f08452d05620334fee9e'
assert meta['candidate_commit']=='d342ff7afef564b0a6d1c368b50f4d86001bfece'
assert execution['host_machine']=='arm64' and meta['execution_platform']=='linux/arm64'
assert meta['image']=='golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
assert (perf/'go-version.txt').read_text().strip()=='go version go1.25.14 linux/arm64'
assert (perf/'final-source-verification.txt').read_text().strip()=='authenticated approved inputs'
gate=execution['screen_approval']['data'];assert gate['passed'] is True and gate['issued_by']=='parent'
assert gate['scope']=='preliminary matched-pair screen only'
for incomplete in ('full_engine_qualification_complete','full_206_invariant_gate_complete','full_618_C_gate_complete','full_RSS_gate_complete','engine_PR_allowed','runtime_promotion_allowed'):assert gate[incomplete] is False
state=json.loads((perf/'container-state.json').read_text());assert state['Status']=='exited' and state['ExitCode']==0 and not state['OOMKilled']
for key in ('focused_C', 'deterministic_counters', 'r4_edit_sessions', 'focused_memory', 'scoped_race_386'):assert gate['gates'][key] is True and gate['evidence'][key]
for key in ('baseline_commit','candidate_commit','baseline_manifest_sha256','candidate_manifest_sha256'):assert gate[key]==meta[key]
assert meta['baseline_manifest_sha256']=='fad01263d60a3c3af414b4dcc1897cf6da1f330c0439376261e729eef9ce0f99' and meta['candidate_manifest_sha256']=='950a42ed4cf8f47e17b2a1cfa86237111997611880d997a73c15bafbd90ed18d'
assert execution['container']['platform']=='linux/arm64' and execution['container']['cpuset']=='2,3' and execution['container']['cpus']==2
assert execution['container']['memory']=='4g' and execution['container']['GOMEMLIMIT']=='3GiB' and execution['container']['GOMAXPROCS']==1 and execution['container']['network']=='none'
starts={'go':49701,'yaml':49601}
names={'go':{'BenchmarkCompactThroughputGo/'+x for x in ('query_compile','grammargen_lr','full_dfa','single_byte_edit_dfa','no_edit_dfa','fresh_one_mib')},'yaml':{'BenchmarkCompactThroughputYAML/'+x for x in ('r4_legacy','eof8k_legacy','r4_ordinary','eof8k_ordinary','r4_owned','eof8k_owned')}}
rows=0;results={};orders={};failures=[]
for language,required in names.items():
 role_data={};role_orders={};expected_seeds=set(range(starts[language],starts[language]+20))
 for role,suffix in (('baseline','before'),('candidate','after')):
  text=(perf/(language+'-'+suffix+'.txt')).read_text();assert text.rstrip().endswith('# status: complete') and not re.search(r'^FAIL(?:\s|$)',text,re.M)
  for header in ('# protocol: paired-alternating-seeds','# GOMAXPROCS: 1','# count per process: 1','# benchtime: 750ms','# build tags: gts_parsercorephase0',f'# seeds: {starts[language]}..{starts[language]+19}'):
   assert header in text,(language,role,header)
  samples={};declared={};completed=[];seed=None
  for line in text.splitlines():
   match=re.fullmatch(r'# seed: (\d+); position: ([12])',line)
   if match:
    seed,position=map(int,match.groups());assert seed in expected_seeds and seed not in samples
    expected_position=(1 if seed%2 else 2) if role=='baseline' else (2 if seed%2 else 1)
    assert position==expected_position,(language,role,seed,position)
    samples[seed]=[]
   elif line.startswith('Benchmark'):
    assert seed is not None;f=line.split();name=re.sub(r'-\d+$','',f[0]);assert name in required and int(f[1])>0
    assert (len(f)-2)%2==0,line
    metrics={f[i+1]:float(f[i]) for i in range(2,len(f),2)}
    assert len(metrics)==(len(f)-2)//2 and {'ns/op','B/op','allocs/op'}<=metrics.keys()
    assert all(math.isfinite(v) and v>=0 for v in metrics.values()) and metrics['ns/op']>0
    samples[seed].append((name,metrics));rows+=1
   elif line.startswith('# workload order:'):
    assert seed is not None and seed not in declared;declared[seed]=line.split(': ',1)[1].split(',')
   elif line.startswith('# completed seed:'):
    completed.append(int(line.split(': ',1)[1].split(';',1)[0]))
  assert set(samples)==set(declared)==expected_seeds and completed==sorted(expected_seeds)
  for seed,measurements in samples.items():
   actual=[n for n,m in measurements];assert len(actual)==6 and set(actual)==required and actual==declared[seed]
  role_data[role]=samples;role_orders[role]=declared
 assert role_orders['baseline']==role_orders['candidate']
 distinct=len({tuple(v) for v in role_orders['baseline'].values()});assert distinct>1
 orders[language]={'matched_pairs':20,'distinct_orders':distinct,'seeds':sorted(expected_seeds),'alternating_process_positions_verified':True,'orders':role_orders['baseline']}
 results[language]={}
 for name in sorted(required):
  paired=[]
  for seed in sorted(expected_seeds):
   before=dict(role_data['baseline'][seed])[name];after=dict(role_data['candidate'][seed])[name]
   assert before.keys()==after.keys(),(name,seed,'metric-set mismatch')
   custom=set(before)-{'ns/op','B/op','allocs/op','MB/s'}
   assert all(before[u]==after[u] for u in custom),(name,seed,'counter mismatch')
   route_work={'compact-routes/op','compact-fallbacks/op','public-nodes/op','tokens/op'}
   is_routed=language=='yaml' or name.endswith('/query_compile') or name.endswith('/grammargen_lr')
   assert custom==(route_work if is_routed else set()),(name,custom)
   if is_routed:
    want_route=0 if name.endswith('_legacy') else 1
    assert before['compact-routes/op']==want_route and before['compact-fallbacks/op']==0,(name,seed,'wrong route')
   if name.endswith('/no_edit_dfa'):assert before['B/op']==before['allocs/op']==after['B/op']==after['allocs/op']==0
   paired.append((seed,before,after))
  counters={u:{'before':paired[0][1][u],'after':paired[0][2][u]} for u in custom}
  for u in custom:assert len({b[u] for s,b,a in paired})==len({a[u] for s,b,a in paired})==1,(name,u,'non-deterministic counter')
  metrics={}
  for unit in ('ns/op','B/op','allocs/op'):
   before=median(b[unit] for s,b,a in paired);after=median(a[unit] for s,b,a in paired)
   delta=100*(after/before-1) if before else (0 if after==0 else None)
   item={'before_median':before,'after_median':after,'directional_change_percent':delta,'paired_seeds':[{'seed':s,'before':b[unit],'after':a[unit]} for s,b,a in paired]}
   metrics[unit]=item
   if after>1.1*before:failures.append({'language':language,'benchmark':name,'metric':unit,'before_median':before,'after_median':after,'change_percent':delta})
  results[language][name]={'metrics':metrics,'deterministic_counters':counters}
assert rows==480
report={'preliminary_screen_only':True,'full_engine_qualification_complete':False,'engine_PR_allowed':False,'runtime_promotion_allowed':False,'full_206_invariant_gate_complete':False,'full_618_C_gate_complete':False,'full_RSS_gate_complete':False,'native_YAML_and_combined_M_prior_net_hold':True,'audit_passed':True,'performance_ratchets_passed':not failures,'benchmark_rows':rows,'processes':80,'go_pairs':20,'yaml_pairs':20,'source_baseline_commit':meta['baseline_commit'],'source_candidate_commit':meta['candidate_commit'],'execution_platform':'Mac Apple M1 Max host / Linux ARM64 Docker / Go 1.25.14','cross_host_pooling_allowed':False,'matched_workload_orders':orders,'deterministic_counters_equal':True,'no_edit_allocations_zero':True,'median_10_percent_failures':failures,'statistics':'Directional medians only; run benchstat on these ARM64 files separately before significance claims.','results':results}
report['all_directional_changes']=[{'language':language,'benchmark':name,'metric':unit,**{k:v for k,v in item.items() if k!='paired_seeds'}} for language,benches in results.items() for name,data in benches.items() for unit,item in data['metrics'].items()]
assert len(report['all_directional_changes'])==36
(perf/'arm64-perf-summary.json').write_text(json.dumps(report,indent=2)+'\n')
files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in perf.iterdir() if p.is_file() and p.name!='results-manifest.json'}
(perf/'results-manifest.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n')
print(json.dumps({'rows':rows,'processes':80,'counter_equality':True,'no_edit_zero_allocations':True,'median_10_percent_failures':failures},indent=2))
for language,benches in results.items():
 for name,data in benches.items():print(language,name,json.dumps({u:{k:v for k,v in item.items() if k!='paired_seeds'} for u,item in data['metrics'].items()}))
if failures:raise SystemExit('Measured median ratchet failed; preserve all results and hold candidate.')
