package parsercorephase0

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"testing"
)

func TestInternCheckpointWithReceiptOwnsExactStateAcrossPageGrowthAndReset(t *testing.T) {
	compact, err := New(&fakeTable{}, Limits{MaxCheckpoints: 2048, MaxCheckpointBytes: 128 * 1024})
	if err != nil {
		t.Fatal(err)
	}
	// More than a prefix and a complete overflow page proves that receipts do
	// not retain a pointer into prefix growth or a record subsequently reused.
	const count = checkpointRecordPrefix + checkpointRecordPage + 7
	known := make(map[string]CheckpointID, count)
	for pass := 0; pass < 2; pass++ {
		for index := 0; index < count; index++ {
			var state [12]byte
			binary.LittleEndian.PutUint64(state[:], uint64(index))
			state[8], state[9], state[10], state[11] = 0, 1, 0, 2
			key := string(state[:])
			want := sha256.Sum256(state[:])
			id, length, digest, err := compact.InternCheckpointWithReceipt(state[:])
			if err != nil || id == 0 || length != uint32(len(state)) || digest != want {
				t.Fatalf("pass=%d index=%d receipt=(%d,%d,%x,%v)", pass, index, id, length, digest, err)
			}
			if prior, exists := known[key]; exists {
				if prior != id {
					t.Fatalf("same bytes changed identity: %d/%d", prior, id)
				}
			} else {
				if id != CheckpointID(len(known)+1) {
					t.Fatalf("new bytes identity=%d, want %d", id, len(known)+1)
				}
				known[key] = id
			}
			state[0] ^= 0xff
			digest[0] ^= 0xff
			if retained, ok := compact.CopyCheckpointBytes(id, nil); !ok || string(retained) != key {
				t.Fatalf("caller mutation reached retained bytes: id=%d bytes=%x ok=%t", id, retained, ok)
			}
			if gotLength, gotDigest, ok := compact.CheckpointReceipt(id); !ok || gotLength != length || gotDigest != want {
				t.Fatalf("caller mutation reached retained receipt: id=%d receipt=(%d,%x,%t)", id, gotLength, gotDigest, ok)
			}
		}
	}
	if got := compact.CheckpointInternerStats(); got.Unique != count || got.SerializedBytes != 12*count {
		t.Fatalf("repeat lookups changed logical use: %+v", got)
	}
	if err := compact.Reset(); err != nil {
		t.Fatal(err)
	}
	id, length, digest, err := compact.InternCheckpointWithReceipt([]byte("new lifetime"))
	if err != nil || id != 1 || length != 12 || digest != sha256.Sum256([]byte("new lifetime")) {
		t.Fatalf("reset reused stale receipt: (%d,%d,%x,%v)", id, length, digest, err)
	}
}

func TestInternCheckpointWithReceiptRejectsTransactionsBeforeAnyLookup(t *testing.T) {
	compact, err := New(&fakeTable{}, Limits{MaxCheckpoints: 4, MaxCheckpointBytes: 16})
	if err != nil {
		t.Fatal(err)
	}
	seed := []byte{1, 2, 3}
	id := mustInternCheckpoint(t, compact, seed)
	if err := compact.SetPhaseCheckpoint(id); err != nil {
		t.Fatal(err)
	}
	before := compact.CheckpointInternerStats()
	lastBefore := compact.checkpoints.lastInterned
	sentinel := errors.New("force rollback")
	err = compact.ApplyAtomic(func() error {
		for _, state := range [][]byte{nil, seed, {4, 5}} {
			gotID, length, digest, fusedErr := compact.InternCheckpointWithReceipt(state)
			_, oldErr := compact.InternCheckpoint(state)
			if fusedErr == nil || oldErr == nil || fusedErr.Error() != oldErr.Error() ||
				gotID != 0 || length != 0 || digest != ([32]byte{}) {
				t.Fatalf("transaction returned a partial receipt: (%d,%d,%x,%v), ordinary=%v", gotID, length, digest, fusedErr, oldErr)
			}
		}
		return sentinel
	})
	if !errors.Is(err, sentinel) || compact.checkpoint != id || compact.CheckpointInternerStats() != before || compact.checkpoints.lastInterned != lastBefore {
		t.Fatalf("rejected interning changed rollback state: err=%v checkpoint=%d stats=%+v", err, compact.checkpoint, compact.CheckpointInternerStats())
	}
	var absent *Core
	_, _, _, nilErr := absent.InternCheckpointWithReceipt(nil)
	_, oldErr := absent.InternCheckpoint(nil)
	if nilErr == nil || oldErr == nil || nilErr.Error() != oldErr.Error() {
		t.Fatalf("nil-core errors differ: fused=%v ordinary=%v", nilErr, oldErr)
	}
}

func TestInternCheckpointWithReceiptCapacityFailurePublishesNothing(t *testing.T) {
	for _, test := range []struct {
		name           string
		limits         Limits
		seed, rejected []byte
	}{
		{name: "identities", limits: Limits{MaxCheckpoints: 1, MaxCheckpointBytes: 16}, seed: []byte{1}, rejected: []byte{2}},
		{name: "bytes", limits: Limits{MaxCheckpoints: 4, MaxCheckpointBytes: 2}, seed: []byte{1}, rejected: []byte{2, 3}},
	} {
		t.Run(test.name, func(t *testing.T) {
			compact, err := New(&fakeTable{}, test.limits)
			if err != nil {
				t.Fatal(err)
			}
			id := mustInternCheckpoint(t, compact, test.seed)
			before := compact.CheckpointInternerStats()
			lastBefore := compact.checkpoints.lastInterned
			gotID, length, digest, fusedErr := compact.InternCheckpointWithReceipt(test.rejected)
			_, ordinaryErr := compact.InternCheckpoint(test.rejected)
			if fusedErr == nil || ordinaryErr == nil || fusedErr.Error() != ordinaryErr.Error() ||
				gotID != 0 || length != 0 || digest != ([32]byte{}) {
				t.Fatalf("cap failure returned a partial receipt: (%d,%d,%x,%v), ordinary=%v", gotID, length, digest, fusedErr, ordinaryErr)
			}
			if compact.CheckpointInternerStats() != before || compact.checkpoints.lastInterned != lastBefore {
				t.Fatalf("cap failure mutated interner: stats=%+v last=%d", compact.CheckpointInternerStats(), compact.checkpoints.lastInterned)
			}
			gotID, length, digest, err = compact.InternCheckpointWithReceipt(test.seed)
			if err != nil || gotID != id || length != uint32(len(test.seed)) || digest != sha256.Sum256(test.seed) {
				t.Fatalf("failed insertion broke existing receipt: (%d,%d,%x,%v)", gotID, length, digest, err)
			}
		})
	}
}

func TestInternCheckpointRecordReceiptResolvesCollisionsAndRejectsCorruptChain(t *testing.T) {
	interner := newCheckpointInterner(4, 32)
	states := [][]byte{[]byte("left"), []byte("rite"), []byte("left\x00")}
	const collision = uint64(9)
	for pass := 0; pass < 2; pass++ {
		for index, state := range states {
			id, record, err := interner.internRecordHash(state, collision)
			if err != nil || id != CheckpointID(index+1) || record == nil ||
				record.length != uint32(len(state)) || record.digest != sha256.Sum256(state) {
				t.Fatalf("collision receipt pass=%d state=%x id=%d record=%+v err=%v", pass, state, id, record, err)
			}
			if got, ok := interner.copyBytes(id, nil); !ok || !bytes.Equal(got, state) {
				t.Fatalf("collision returned another state's bytes: got=%x want=%x ok=%t", got, state, ok)
			}
		}
	}
	before := interner.stats()
	interner.buckets[collision] = 99
	id, record, err := interner.internRecordHash([]byte("next"), collision)
	if err == nil || err.Error() != "parser-core phase zero: corrupt checkpoint interner chain" || id != 0 || record != nil || interner.stats() != before {
		t.Fatalf("corrupt chain published a receipt: id=%d record=%+v err=%v stats=%+v", id, record, err, interner.stats())
	}
}

func TestInternCheckpointWithReceiptRepeatedLookupAllocatesNothing(t *testing.T) {
	compact, err := New(&fakeTable{}, Limits{MaxCheckpoints: 1, MaxCheckpointBytes: 16})
	if err != nil {
		t.Fatal(err)
	}
	state := []byte{1, 2, 3}
	id := mustInternCheckpoint(t, compact, state)
	want := sha256.Sum256(state)
	if allocs := testing.AllocsPerRun(1000, func() {
		gotID, length, digest, err := compact.InternCheckpointWithReceipt(state)
		if err != nil || gotID != id || length != 3 || digest != want {
			panic("repeated receipt drift")
		}
		gotID, length, digest, err = compact.InternCheckpointWithReceipt(nil)
		if err != nil || gotID != 0 || length != 0 || digest != emptyCheckpointDigest {
			panic("empty receipt drift")
		}
	}); allocs != 0 {
		t.Fatalf("repeated receipt allocations=%v, want 0", allocs)
	}
}
