package parsercorephase0

import (
	"bytes"
	"crypto/sha256"
	"hash/maphash"
)

var emptyCheckpointDigest = sha256.Sum256(nil)

// CheckpointID is a compact, core-local identity for one exact serialized
// external-scanner state. ID zero is reserved for the empty checkpoint.
type CheckpointID uint32

// CheckpointInternerStats reports logical interner use. Both dimensions are
// independently bounded by Limits.
type CheckpointInternerStats struct {
	Unique          uint32
	SerializedBytes uint64
	// DigestCollisions counts collisions in the lookup hash, not the receipt digest.
	DigestCollisions uint64
}

type checkpointRecord struct {
	digest [32]byte
	offset uint32
	length uint32
	next   CheckpointID
}

type checkpointInterner struct {
	records    checkpointRecords
	bytes      []byte
	buckets    map[uint64]CheckpointID
	hashSeed   maphash.Seed
	maxIDs     uint32
	maxBytes   uint64
	collisions uint64
	// lastInterned is the identity intern returned most recently. Scanner
	// state rarely changes between consecutive tokens, so a byte comparison
	// against that record answers most interns without a digest.
	lastInterned CheckpointID
}

func newCheckpointInterner(maxIDs uint32, maxBytes uint64) checkpointInterner {
	return checkpointInterner{maxIDs: maxIDs, maxBytes: maxBytes}
}

func (i *checkpointInterner) intern(serialized []byte) (CheckpointID, error) {
	id, _, err := i.internRecord(serialized)
	return id, err
}

// internHash confirms the complete serialized bytes after hash bucketing.
// SHA-256 runs only for a new receipt, never for an existing checkpoint lookup.
func (i *checkpointInterner) internHash(serialized []byte, hash uint64) (CheckpointID, error) {
	id, _, err := i.internRecordHash(serialized, hash)
	return id, err
}

func (i *checkpointInterner) record(id CheckpointID) (checkpointRecord, bool) {
	record, ok := i.recordRef(id)
	if !ok {
		return checkpointRecord{}, false
	}
	return *record, true
}

func (i *checkpointInterner) receipt(id CheckpointID) (uint32, [32]byte, bool) {
	if id == 0 {
		return 0, emptyCheckpointDigest, true
	}
	record, ok := i.recordRef(id)
	if !ok {
		return 0, [32]byte{}, false
	}
	return record.length, record.digest, true
}

// matches reports whether serialized equals the retained bytes of id. It is
// the byte-exact form of comparing a receipt digest against a fresh digest of
// serialized, without computing that digest. Checkpoint zero matches only the
// empty checkpoint.
func (i *checkpointInterner) matches(id CheckpointID, serialized []byte) bool {
	if id == 0 {
		return len(serialized) == 0
	}
	record, ok := i.recordRef(id)
	if !ok {
		return false
	}
	start := uint64(record.offset)
	end := start + uint64(record.length)
	if end < start || end > uint64(len(i.bytes)) {
		return false
	}
	return bytes.Equal(i.bytes[start:end], serialized)
}

// copyBytes copies one exact serialized checkpoint into dst. It reuses dst's
// backing array when its capacity is sufficient and never exposes i.bytes.
// Checkpoint zero is the valid empty checkpoint; every other ID must resolve
// to a complete retained record.
func (i *checkpointInterner) copyBytes(id CheckpointID, dst []byte) ([]byte, bool) {
	if id == 0 {
		return dst[:0], true
	}
	record, ok := i.recordRef(id)
	if !ok {
		return nil, false
	}
	start := uint64(record.offset)
	end := start + uint64(record.length)
	if end < start || end > uint64(len(i.bytes)) {
		return nil, false
	}
	length := int(record.length)
	if cap(dst) < length {
		dst = make([]byte, length)
	} else {
		dst = dst[:length]
	}
	copy(dst, i.bytes[int(start):int(end)])
	return dst, true
}

func (i *checkpointInterner) stats() CheckpointInternerStats {
	return CheckpointInternerStats{Unique: uint32(i.records.Len()), SerializedBytes: uint64(len(i.bytes)), DigestCollisions: i.collisions}
}

func (i *checkpointInterner) reset() {
	i.records.reset()
	i.bytes = i.bytes[:0]
	i.lastInterned = 0
	clear(i.buckets)
	i.collisions = 0
}
