package parsercorephase0

import (
	"bytes"
	"crypto/sha256"
	"errors"
	"hash/maphash"
	"math"
)

// InternCheckpointWithReceipt interns one exact scanner state and returns its
// immutable receipt from the record that resolved the lookup. It preserves the
// transaction, reset, capacity, and byte-equality contract of InternCheckpoint.
// No interner storage escapes: the digest is returned by value.
func (c *Core) InternCheckpointWithReceipt(serialized []byte) (CheckpointID, uint32, [32]byte, error) {
	if c == nil {
		return 0, 0, [32]byte{}, errors.New("parser-core phase zero: intern checkpoint on nil core")
	}
	if len(c.transactions) != 0 {
		return 0, 0, [32]byte{}, errors.New("parser-core phase zero: intern checkpoint during active transaction")
	}
	id, record, err := c.checkpoints.internRecord(serialized)
	if err != nil {
		return 0, 0, [32]byte{}, err
	}
	if id == 0 {
		return 0, 0, emptyCheckpointDigest, nil
	}
	return id, record.length, record.digest, nil
}

// recordRef is private to the interner. Callers consume the fields before any
// insertion or reset can move the small prefix or reuse an existing slot.
func (i *checkpointInterner) recordRef(id CheckpointID) (*checkpointRecord, bool) {
	if id == 0 || uint64(id) > uint64(i.records.Len()) {
		return nil, false
	}
	return i.records.at(int(id) - 1), true
}

// internRecord retains the resolved record only for the current call. This
// joins exact identity lookup and receipt publication without rereading an ID
// or copying its complete record into a temporary value.
func (i *checkpointInterner) internRecord(serialized []byte) (CheckpointID, *checkpointRecord, error) {
	if len(serialized) == 0 {
		return 0, nil, nil
	}
	if id := i.lastInterned; id != 0 {
		if record, ok := i.recordRef(id); ok {
			start := uint64(record.offset)
			end := start + uint64(record.length)
			if end <= uint64(len(i.bytes)) && bytes.Equal(i.bytes[start:end], serialized) {
				return id, record, nil
			}
		}
	}
	if i.hashSeed == (maphash.Seed{}) {
		i.hashSeed = maphash.MakeSeed()
	}
	id, record, err := i.internRecordHash(serialized, maphash.Bytes(i.hashSeed, serialized))
	if err != nil {
		return 0, nil, err
	}
	i.lastInterned = id
	return id, record, nil
}

func (i *checkpointInterner) internRecordHash(serialized []byte, hash uint64) (CheckpointID, *checkpointRecord, error) {
	if len(serialized) == 0 {
		return 0, nil, nil
	}
	bucket := i.buckets[hash]
	for id := bucket; id != 0; {
		record, ok := i.recordRef(id)
		if !ok {
			return 0, nil, errors.New("parser-core phase zero: corrupt checkpoint interner chain")
		}
		start := uint64(record.offset)
		end := start + uint64(record.length)
		if end <= uint64(len(i.bytes)) && bytes.Equal(i.bytes[start:end], serialized) {
			return id, record, nil
		}
		id = record.next
	}
	if uint64(i.records.Len()) >= uint64(i.maxIDs) {
		return 0, nil, errors.New("parser-core phase zero: checkpoint identity cap")
	}
	if uint64(len(serialized)) > math.MaxUint32 {
		return 0, nil, errors.New("parser-core phase zero: checkpoint length overflow")
	}
	if uint64(len(i.bytes)) > i.maxBytes || uint64(len(serialized)) > i.maxBytes-uint64(len(i.bytes)) {
		return 0, nil, errors.New("parser-core phase zero: checkpoint byte cap")
	}
	if uint64(len(i.bytes))+uint64(len(serialized)) > uint64(^uint32(0)) {
		return 0, nil, errors.New("parser-core phase zero: checkpoint byte offset overflow")
	}
	if i.buckets == nil {
		i.buckets = make(map[uint64]CheckpointID)
	}
	id := CheckpointID(i.records.Len() + 1)
	offset := uint32(len(i.bytes))
	i.bytes = append(i.bytes, serialized...)
	i.records.append(checkpointRecord{
		digest: sha256.Sum256(serialized), offset: offset, length: uint32(len(serialized)), next: bucket,
	})
	i.buckets[hash] = id
	if bucket != 0 {
		i.collisions++
	}
	return id, i.records.at(int(id) - 1), nil
}
