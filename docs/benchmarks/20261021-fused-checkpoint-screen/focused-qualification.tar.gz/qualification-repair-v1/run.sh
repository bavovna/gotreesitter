#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false -overlay=/evidence/overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cgo.test . > /evidence/cgo-build.log 2>&1
for gts_language in yaml go; do
 GTS_ADMISSION_CANDIDATE=1 GTS_PARITY_MODE=exhaustive /evidence/cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${gts_language}$" -test.count=1 -test.v -test.timeout=4m > "/evidence/c-$gts_language.log" 2>&1
done
GTS_ADMISSION_CANDIDATE=1 /evidence/cgo.test -test.run '^(TestCompactYAMLVersionOwnershipCOracle|TestCompactYAMLDocumentStreamLockedC)$' -test.count=1 -test.v -test.timeout=4m > /evidence/owned-yaml-c.log 2>&1
cd /candidate
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v > /evidence/canonical-work.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/counter ./cmd/perfcounterledger > /evidence/counter-build.log 2>&1
/evidence/counter --write --output /evidence/ledger.json > /evidence/counter.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/counter --langs yaml > /evidence/owned-yaml-ledger.json 2> /evidence/owned-yaml-ledger.log
python3 - <<'VERIFY'
import json
from pathlib import Path
for n in ('ledger.json','owned-yaml-ledger.json'):
 assert json.loads((Path('/evidence')/n).read_text())==json.loads((Path('/reference-evidence')/n).read_text()),n
Path('/evidence/ledger-audit.json').write_text(json.dumps({'passed':True,'exact_rows':414,'baseline':'qualified M73556f2','full_qualification':False})+'\n')
VERIFY
regex='^Test(InternCheckpoint|CheckpointInterner|EmptyCheckpointReceipt|CoreCheckpointByteCopy|CheckpointPrivateCopy|CheckpointRecordPages)'
go test ./internal/parsercorephase0 -race -run "$regex" -count=1 -v > /evidence/internal-race.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test ./internal/parsercorephase0 -run "$regex" -count=1 -v > /evidence/internal-386.log 2>&1
go test . -tags gts_parsercorephase0 -race -run '^TestDiagnosticParserCore(Election|VersionLexerElection|CheckpointCompactLayouts)' -count=1 -v > /evidence/root-race.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test . -tags gts_parsercorephase0 -run '^TestDiagnosticParserCore(Election|VersionLexerElection)' -count=1 -v > /evidence/root-386.log 2>&1
printf 'complete\n' > /evidence/complete.txt
