#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -mod=readonly' GOWORK=off
cd /candidate
go version > /evidence/go-version.txt
go test ./internal/parsercorephase0 -run '^Test(InternCheckpoint|CheckpointInterner|EmptyCheckpointReceipt|CoreCheckpointByteCopy|CheckpointPrivateCopy|CheckpointRecordPages)' -count=1 -v > /evidence/internal.log 2>&1
go test . -tags gts_parsercorephase0 -run '^TestDiagnosticParserCore(Election|VersionLexerElection|CheckpointCompactLayouts)' -count=1 -v > /evidence/root.log 2>&1
printf 'complete\n' > /evidence/complete.txt
