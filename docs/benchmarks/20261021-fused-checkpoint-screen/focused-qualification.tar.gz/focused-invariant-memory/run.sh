#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false -overlay=/evidence/overlay.json'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/build.log 2>&1
for gts_language in go yaml; do
 GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE="$gts_language" /evidence/root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=4m > "/evidence/invariant-$gts_language.log" 2>&1
done
GTS_ADMISSION_CANDIDATE=1 /evidence/root.test -test.run '^TestProgressArenaOwnedYAMLInvariant$' -test.count=1 -test.v -test.timeout=4m > /evidence/invariant-yaml-owned.log 2>&1
/evidence/root.test -test.run '^Test(CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactExternalScannerCheckpointCopyMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|FreshSnapshotPages.*|SnapshotPairFootprint.*|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|CompactLegacyReadScratchPooledLargeThenSmall|ParserCoreFreshFullRunnerReusesSchedulerStorage)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory-contracts.log 2>&1
printf 'complete\n' > /evidence/complete.txt
