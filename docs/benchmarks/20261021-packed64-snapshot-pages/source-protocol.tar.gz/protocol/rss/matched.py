from pathlib import Path
from statistics import median
import hashlib,itertools,json,os,random,re,subprocess
p=Path('/evidence');probes=p/'probes';out=p/'matched';out.mkdir(exist_ok=False)
roles=['baseline','reference','candidate'];cases=['go','yaml_ordinary','yaml_owned'];rows=[]
def read(role,case,stage,log,rss,seed=None,position=None):
 text=log.read_text();assert '--- PASS:' in text and '--- SKIP:' not in text and '--- FAIL:' not in text
 size=int(re.search(r'bytes=(\d+)',text)[1]);assert size==(1048591 if case=='go' else 1049572)
 route='compact=0 fallback=1' if role=='baseline' and case=='yaml_ordinary' else 'compact=1 fallback=0';assert route in text;assert 'stopReason=accepted' in text
 if case=='go':assert 'nodes=903086/' in text and 'tokens=425742 ' in text
 peak=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',rss.read_text())[1])*1024
 return dict(role=role,case=case,stage=stage,seed=seed,position=position,input_bytes=size,peak_rss_bytes=peak,rss_bytes_per_source_byte=peak/size)
initial=[read(role,case,'initial',probes/f'{role}-initial-{case}.log',probes/f'{role}-initial-{case}.rss') for role in roles for case in cases]
pins={role:hashlib.sha256((probes/f'{role}.test').read_bytes()).hexdigest() for role in roles}
permutations=list(itertools.permutations(roles))
for seed in range(48501,48521):
 order=permutations[(seed-48501)%6];shuffled=list(cases);random.Random(seed).shuffle(shuffled)
 for case in shuffled:
  for position,role in enumerate(order,1):
   log=out/f'{seed}-{case}-{role}.log';rss=out/f'{seed}-{case}-{role}.rss'
   args=['/usr/bin/time','-v','-o',str(rss),str(probes/f'{role}.test'),'-test.run',f'^TestCompactLineageRSS$/^{case}$','-test.count=1','-test.v',f'-test.shuffle={seed}','-test.timeout=4m']
   with log.open('w') as stream:subprocess.run(args,cwd='/'+role,check=True,stdout=stream,stderr=subprocess.STDOUT)
   row=read(role,case,'matched',log,rss,seed,position);rows.append(row);(out/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');print(seed,case,role,round(row['rss_bytes_per_source_byte'],3),flush=True)
assert len(initial)==9 and len(rows)==180
assert all(hashlib.sha256((probes/f'{role}.test').read_bytes()).hexdigest()==h for role,h in pins.items())
summary={case:{role:dict(count=20,median=median(x['rss_bytes_per_source_byte'] for x in rows if x['role']==role and x['case']==case),maximum=max(x['rss_bytes_per_source_byte'] for x in rows if x['role']==role and x['case']==case)) for role in roles} for case in cases}
net={case:summary[case]['candidate']['median']/summary[case]['baseline']['median'] for case in cases};isolated={case:summary[case]['candidate']['median']/summary[case]['reference']['median'] for case in cases}
failures=[x for x in initial+rows if x['role']=='candidate' and x['rss_bytes_per_source_byte']>400]
passed=not failures and all(x<=1.10 for x in net.values()) and all(x<=1.10 for x in isolated.values())
report=dict(protocol='20 matched source triples; shuffled case order; rotating all six role permutations; one grammar/process; normal pools and budgets; safety measurements only',seeds='48501..48520',roles=dict(baseline='qualified subtree variant, ordinary YAML fallback',reference='qualified publication coallocation L',candidate='L with paired packed64 snapshot pages'),binary_sha256=pins,environment={k:os.environ.get(k) for k in ['GOMAXPROCS','GOMEMLIMIT','GOGC','GODEBUG','GOT_PARSE_NODE_LIMIT_SCALE','GOT_GLR_MAX_STACKS']},initial=initial,matched=rows,summary=summary,candidate_baseline_median_ratios=net,candidate_reference_median_ratios=isolated,candidate_ceiling_failures=failures,all_initial_probes_retained=True,candidate_safety_pass=passed)
(out/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['initial','matched']},indent=2))
if not passed:raise SystemExit('memory ceiling or median ratchet failed; retain every probe and do not promote')
