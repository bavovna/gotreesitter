#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -run '^Test(Packed64Snapshot|ScannerSnapshot|ScannerTrialMask|PackedSnapshotPages)' -count=1 -v -timeout=8m > /evidence/internal.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(Packed64Snapshot|VersionPublicationCoallocation|DiagnosticParserCoreVersionLexerSnapshot|FreshSnapshotPages|SnapshotPairFootprint|PackedSnapshotTrial)' -count=1 -v -timeout=8m > /evidence/root.log 2>&1
go test ./internal/parsercorephase0 -race -run '^TestPacked64Snapshot' -count=1 -v -timeout=8m > /evidence/internal-race.log 2>&1
go test . -race -tags gts_parsercorephase0 -run '^Test(Packed64Snapshot|VersionPublicationCoallocation)' -count=1 -v -timeout=8m > /evidence/root-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^TestPacked64Snapshot' -count=1 -v -timeout=8m > /evidence/internal-386.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^Test(Packed64Snapshot|VersionPublicationCoallocation)' -count=1 -v -timeout=8m > /evidence/root-386.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
printf 'complete\n' > /evidence/focused-screen-complete.txt
