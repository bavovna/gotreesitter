#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-default.log 2>&1
go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-shadow.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(Packed64Snapshot|VersionPublicationCoallocation)'  -count=1 -v -timeout=8m > /evidence/coallocation-root.log 2>&1
go test . -race -tags gts_parsercorephase0 -run '^Test(Packed64Snapshot|VersionPublicationCoallocation)'  -count=1 -v -timeout=8m > /evidence/coallocation-root-race.log 2>&1
go test ./internal/parsercorephase0 -race -run '^Test(Packed64Snapshot|CoallocatedPublication)'  -count=1 -v -timeout=8m > /evidence/coallocation-internal-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^Test(Packed64Snapshot|VersionPublicationCoallocation)'  -count=1 -v -timeout=8m > /evidence/coallocation-root-386.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^Test(Packed64Snapshot|CoallocatedPublication)'  -count=1 -v -timeout=8m > /evidence/coallocation-internal-386.log 2>&1
printf 'complete\n' > /evidence/core-first-complete.txt
