#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
assert len(sys.argv)==2,'usage: audit-screen.py ABSOLUTE_RUN_DIRECTORY'
r=Path(sys.argv[1]).resolve()/'results';assert (r/'complete.txt').read_text().strip()=='complete'
x=json.loads((r/'execution.json').read_text());m=x['protocol'];g=x['parent_approval']['data']
assert g['issued_by']=='parent' and g['L_qualification_passed'] is True and g['timing_idle_confirmed'] is True and g['L_qualification_evidence']
for key in ('baseline_commit','baseline_manifest_sha256','candidate_manifest_sha256'):assert g[key]==m[key]
assert m['baseline_commit']=='1f0143fdbacc1ce6c5ece8a770e86ca0cd049fb5' and m['candidate_files']==4356 and x['host_machine']=='arm64'
assert m['image']=='golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
assert (r/'go-version.txt').read_text().strip()=='go version go1.25.14 linux/arm64'
assert (r/'host-exit.txt').read_text().strip()=='0'
state=json.loads((r/'container-state.json').read_text());assert state['ExitCode']==0 and not state['OOMKilled'] and not state['Running'] and state['Status']=='exited'
assert (r/'final-source-verification.txt').read_text().strip()=='authenticated approved inputs'
counts={}
for package in ('internal','root'):
 expected=set(m['tests'][package]['expected_tests']);assert len(expected)==m['tests'][package]['count']
 for mode in ('native','race'):
  name=package+'-'+mode;events=[json.loads(line) for line in (r/(name+'.jsonl')).read_text().splitlines() if line.strip()]
  assert events and all(e.get('Action') not in ('fail','skip') for e in events),(name,'failed/skipped event')
  output=''.join(e.get('Output','') for e in events);(r/(name+'.stdout')).write_text(output)
  assert 'WARNING: DATA RACE' not in output+(r/(name+'.stderr')).read_text()
  runs=[e['Test'] for e in events if e.get('Action')=='run' and '/' not in e.get('Test','')]
  passes=[e['Test'] for e in events if e.get('Action')=='pass' and e.get('Test') and '/' not in e['Test']]
  assert set(runs)==set(passes)==expected and len(runs)==len(passes)==len(expected),(name,runs,passes)
  package_pass=[e for e in events if e.get('Action')=='pass' and 'Test' not in e];assert len(package_pass)==1
  new=[t for t in passes if t.startswith('TestPacked64Snapshot')];assert len(new)==(3 if package=='internal' else 2)
  counts[name]={'top_level_tests':len(passes),'new_packed64_tests':len(new),'skipped':0,'failed':0,'package_pass':True,'stdout':name+'.stdout'}
compiled={}
for name in ('internal','root'):
 p=r/(name+'.386.test');data=p.read_bytes();assert data[:4]==b'\x7fELF' and data[4]==1 and data[5]==1 and int.from_bytes(data[18:20],'little')==3,'expected ELF32/i386 test binary'
 compiled[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'ELF_class':32,'machine':'i386','compiled':True,'executed':False}
report={'passed':True,'baseline_commit':m['baseline_commit'],'baseline_manifest_sha256':m['baseline_manifest_sha256'],'candidate_manifest_sha256':m['candidate_manifest_sha256'],'platform':'Mac Apple M1 Max host / Linux ARM64 Docker / Go 1.25.14','test_counts':counts,'total_top_level_test_executions':sum(c['top_level_tests'] for c in counts.values()),'all_expected_tests_ran':True,'no_skips':True,'scoped_race_passed':True,'386_compile_only':compiled,'container_oom':False,'sources_authenticated_before_and_after':True,'timing_executed':False,'invariant_206_sweep':False,'C_parity_executed':False,'promotion_qualified':False}
(r/'screen-summary.json').write_text(json.dumps(report,indent=2)+'\n')
files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in r.iterdir() if p.is_file() and p.name!='results-manifest.json'}
(r/'results-manifest.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2))
