#!/usr/bin/env bash
set -euo pipefail
test -f /approval/parent-approval.json
test "$(go env GOVERSION)" = go1.25.14
test "$(go env GOOS)/$(go env GOARCH)" = linux/arm64
export GOWORK=off GOTOOLCHAIN=local GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
cd /workspace
go version > /evidence/go-version.txt
go env -json GOOS GOARCH GOVERSION GOTOOLCHAIN GOMODCACHE GOCACHE CGO_ENABLED > /evidence/go-environment.json
gts_internal='^(TestPacked64Snapshot|TestScannerSnapshot|TestScannerTrialMask|TestPackedSnapshotPages|TestCoallocatedPublication)'
gts_root='^(TestPacked64Snapshot|TestVersionPublicationCoallocation|TestDiagnosticParserCoreVersionLexerSnapshot|TestFreshSnapshotPages|TestSnapshotPairFootprint|TestPackedSnapshotTrial)'
go test ./internal/parsercorephase0 -run "$gts_internal" -count=1 -json -timeout=10m > /evidence/internal-native.jsonl 2> /evidence/internal-native.stderr
go test . -tags gts_parsercorephase0 -run "$gts_root" -count=1 -json -timeout=10m > /evidence/root-native.jsonl 2> /evidence/root-native.stderr
go test ./internal/parsercorephase0 -race -run "$gts_internal" -count=1 -json -timeout=10m > /evidence/internal-race.jsonl 2> /evidence/internal-race.stderr
go test . -race -tags gts_parsercorephase0 -run "$gts_root" -count=1 -json -timeout=10m > /evidence/root-race.jsonl 2> /evidence/root-race.stderr
GOARCH=386 CGO_ENABLED=0 go test -c ./internal/parsercorephase0 -o /evidence/internal.386.test > /evidence/internal-386-compile.stdout 2> /evidence/internal-386-compile.stderr
GOARCH=386 CGO_ENABLED=0 go test -c -tags gts_parsercorephase0 . -o /evidence/root.386.test > /evidence/root-386-compile.stdout 2> /evidence/root-386-compile.stderr
sha256sum /evidence/internal.386.test /evidence/root.386.test > /evidence/386-binary-sha256.txt
printf 'complete\n' > /evidence/complete.txt
