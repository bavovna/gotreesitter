#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/qualification-overlay.json'
mkdir -p /evidence/out/reference
cd /reference
go build -tags gts_parsercorephase0 -o /evidence/out/reference/counter ./cmd/perfcounterledger > /evidence/out/reference/counter-build.log 2>&1
/evidence/out/reference/counter --write --output /evidence/reference-ledger.json
GTS_LAYOUT_OWNED_PROBE=1 /evidence/out/reference/counter --langs yaml > /evidence/reference-owned-yaml-ledger.json
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v > /evidence/out/reference/canonical-work.log 2>&1
python3 - <<'AUDIT'
from pathlib import Path
import json
p=Path('/evidence');rows={}
for line in (p/'out/reference/canonical-work.log').read_text().splitlines():
 if 'CANONICAL_WORK_CENSUS ' in line:
  r=json.loads(line.split('CANONICAL_WORK_CENSUS ',1)[1]);rows[r['Fixture']]=r
assert len(rows)==4
(p/'reference-canonical-work.json').write_text(json.dumps({'candidate':rows},indent=2)+'\n')
AUDIT
