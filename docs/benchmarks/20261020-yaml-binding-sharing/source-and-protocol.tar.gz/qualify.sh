#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/focused-complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/qualification-overlay.json' GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
mkdir -p /evidence/out/candidate
cd /candidate
go test . -tags gts_parsercorephase0 -run '^Test(CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|FreshSnapshotPages.*|SnapshotPairFootprint.*|CompactArenaReserve.*(Budget|RetentionCap)|CompactAcceptance.*(MemoryBudget|RetentionBound)|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle)$' -count=1 -v -timeout=6m > /evidence/out/candidate/memory-pooling.log 2>&1
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v > /evidence/out/candidate/canonical-work.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/out/candidate/counter ./cmd/perfcounterledger > /evidence/out/candidate/counter-build.log 2>&1
/evidence/out/candidate/counter --write --output /evidence/out/candidate/ledger.json > /evidence/out/candidate/ledger.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/out/candidate/counter --langs yaml > /evidence/out/candidate/owned-yaml-ledger.json 2> /evidence/out/candidate/owned-yaml-ledger.log
go test -c -tags gts_parsercorephase0 -o /evidence/out/candidate/root.test . > /evidence/out/candidate/root-build.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=yaml /evidence/out/candidate/root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=4m > /evidence/out/candidate/invariant-yaml.log 2>&1
GTS_ADMISSION_CANDIDATE=1 /evidence/out/candidate/root.test -test.run '^TestProgressArenaOwnedYAMLInvariant$' -test.count=1 -test.v -test.timeout=4m > /evidence/out/candidate/owned-yaml-invariant.log 2>&1
cd /candidate/cgo_harness
go test -c -tags gts_parsercorephase0,treesitter_c_parity -o /evidence/out/candidate/cgo.test . > /evidence/out/candidate/cgo-build.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GTS_PARITY_MODE=exhaustive /evidence/out/candidate/cgo.test -test.run '^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^yaml$' -test.count=1 -test.v -test.timeout=4m > /evidence/out/candidate/c-yaml.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml /evidence/out/candidate/cgo.test -test.run '^TestCompactR4StructuralLockedC$' -test.count=1 -test.v -test.timeout=4m > /evidence/out/candidate/strict-yaml.log 2>&1
GTS_YAML_LARGE_PROBE=1 /evidence/out/candidate/cgo.test -test.run '^TestCompactYAMLDocumentStreamLockedC$' -test.count=1 -test.v -test.timeout=8m > /evidence/out/candidate/yaml-large-c.log 2>&1
cd /candidate
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=yaml go test . -tags gts_parsercorephase0 -race -run '^TestV1InvariantGateR4EditSession$' -count=1 -v -timeout=6m > /evidence/out/candidate/yaml-parse-race.log 2>&1
bash /evidence/yaml-errors/run.sh
python3 /evidence/audit-full.py
