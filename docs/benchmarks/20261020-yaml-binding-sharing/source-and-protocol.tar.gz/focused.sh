#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./grammars/runtime -run '^Test(Yaml|YAML)' -count=1 -v -timeout=6m > /evidence/yaml-unit.log 2>&1
go test ./grammars/runtime -race -run '^Test(YamlExternalScannerSpecMatchesBlob|YAMLCheckpoint.*|YAMLScannerShares.*)$' -count=1 -v -timeout=6m > /evidence/yaml-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./grammars/runtime -run '^Test(YamlExternalScannerSpecMatchesBlob|YAMLCheckpoint.*|YAMLScannerShares.*)$' -count=1 -v -timeout=6m > /evidence/yaml-386.log 2>&1
go test -c ./grammars/runtime -o /evidence/yaml-runtime.test > /evidence/yaml-build.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
