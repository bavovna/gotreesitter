//go:build !grammar_subset || grammar_subset_yaml

package grammarruntime

import (
	"bytes"
	"encoding/binary"
	"reflect"
	"testing"
	"unsafe"

	gotreesitter "github.com/odvcencio/gotreesitter"
)

func TestYAMLCheckpointRestorePreservesIndependentHistories(t *testing.T) {
	scanner := YamlExternalScanner{}
	payload := scanner.Create().(*yamlPayload)
	deep := make([]byte, 10+4*17)
	for i := 0; i < len(deep); i += 2 {
		binary.LittleEndian.PutUint16(deep[i:], uint16(300+i))
	}
	// Negative cursor coordinates and indentation lengths are valid scanner
	// state. Keep their signed representation through every restore.
	binary.LittleEndian.PutUint16(deep[4:], 0xffff)
	binary.LittleEndian.PutUint16(deep[12:], 0xfffe)
	shallow := append([]byte(nil), deep[:14]...)
	header := append([]byte(nil), deep[:10]...)
	for _, checkpoint := range [][]byte{deep, shallow, nil, header, deep, deep[:9], shallow, append(shallow, 1, 2, 3)} {
		scanner.Deserialize(payload, checkpoint)
		fresh := scanner.Create().(*yamlPayload)
		scanner.Deserialize(fresh, checkpoint)
		if !reflect.DeepEqual(payload.state, fresh.state) {
			t.Fatalf("restore after another history differs for %d-byte checkpoint: got %+v want %+v", len(checkpoint), payload.state, fresh.state)
		}
		if payload.state.indTypStk[0] != yIndRot || payload.state.indLenStk[0] != -1 {
			t.Fatal("restore lost the root indentation sentinel")
		}
	}
	checkpoint := append([]byte(nil), deep...)
	scanner.Deserialize(payload, checkpoint)
	clear(checkpoint)
	buf := make([]byte, len(deep))
	if n := scanner.Serialize(payload, buf); n != len(deep) || !bytes.Equal(buf, deep) {
		t.Fatal("restored state aliases its serialized checkpoint")
	}
}

func TestYAMLCheckpointRestoreReusesIndentStorage(t *testing.T) {
	scanner := YamlExternalScanner{}
	payload := scanner.Create()
	deep := make([]byte, 10+4*17)
	scanner.Deserialize(payload, deep)
	if got := testing.AllocsPerRun(100, func() {
		scanner.Deserialize(payload, deep[:14])
		scanner.Deserialize(payload, nil)
		scanner.Deserialize(payload, deep)
	}); got != 0 {
		t.Fatalf("warmed checkpoint restores allocate %g times, want zero", got)
	}
}

// The public value scanner must keep its interface while avoiding token-table
// copies on every interface call. Rebinding must not change an existing value.
func TestYAMLScannerSharesImmutableBindingAndKeepsPayloadsIndependent(t *testing.T) {
	var _ gotreesitter.ExternalScanner = YamlExternalScanner{}
	if got, want := unsafe.Sizeof(YamlExternalScanner{}), unsafe.Sizeof(uintptr(0)); got != want {
		t.Fatalf("scanner value is %d bytes, want one %d-byte binding pointer", got, want)
	}
	lang := Language("yaml")
	bound := YamlExternalScanner{}.ExternalScannerForLanguage(lang).(*YamlExternalScanner)
	copied := *bound
	before := *bound.symbolTable()
	if bound.binding == nil || copied.binding != bound.binding {
		t.Fatal("scanner value copy did not share its immutable binding")
	}
	const offset = 73
	renumbered := &gotreesitter.Language{
		SymbolNames:     make([]string, len(lang.SymbolNames)+offset),
		ExternalSymbols: make([]gotreesitter.Symbol, len(lang.ExternalSymbols)),
	}
	copy(renumbered.SymbolNames[offset:], lang.SymbolNames)
	for i, symbol := range lang.ExternalSymbols {
		renumbered.ExternalSymbols[i] = symbol + offset
	}
	rebound := copied.ExternalScannerForLanguage(renumbered).(*YamlExternalScanner)
	for i, symbol := range before {
		if got := rebound.symbolTable()[i]; got != symbol+offset {
			t.Fatalf("renumbered token %d: got %d want %d", i, got, symbol+offset)
		}
	}
	reboundBefore := *rebound.symbolTable()
	clear(renumbered.ExternalSymbols)
	clear(renumbered.SymbolNames)
	if *bound.symbolTable() != before || *copied.symbolTable() != before || *rebound.symbolTable() != reboundBefore || rebound.binding == bound.binding {
		t.Fatal("rebinding or input mutation changed the original immutable table")
	}
	if got := *(YamlExternalScanner{}).symbolTable(); got != yamlDefaultSymTable {
		t.Fatal("zero-value scanner lost its default symbol mapping")
	}
	a, b := bound.Create().(*yamlPayload), copied.Create().(*yamlPayload)
	checkpoint := make([]byte, 10)
	binary.LittleEndian.PutUint16(checkpoint, 513)
	bound.Deserialize(a, checkpoint)
	if a == b || reflect.DeepEqual(a.state, b.state) {
		t.Fatal("shared immutable binding also shared mutable scanner state")
	}
}
