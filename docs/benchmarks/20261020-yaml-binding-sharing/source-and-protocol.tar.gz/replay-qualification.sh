#!/usr/bin/env bash
set -euo pipefail
bash /evidence/focused.sh
bash /evidence/baseline.sh
bash /evidence/qualify.sh
