#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/yaml-errors/overlay.json' GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
for role in reference candidate; do
 cd "/$role/cgo_harness"
 set +e
 go test . -tags gts_parsercorephase0,treesitter_c_parity -run '^TestYAMLRecoveryGroupErrorCorpus$' -count=1 -json -timeout=8m > "/evidence/yaml-errors/$role.jsonl" 2> "/evidence/yaml-errors/$role-build.log"
 status=$?
 set -e
 if (( status > 1 )); then exit "$status"; fi
 printf '%s\n' "$status" > "/evidence/yaml-errors/$role-status.txt"
done
python3 /evidence/yaml-errors/audit.py
