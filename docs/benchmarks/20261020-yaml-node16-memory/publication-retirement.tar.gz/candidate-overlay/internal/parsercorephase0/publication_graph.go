package parsercorephase0

import (
	"errors"
	"math"
	"unsafe"
)

var errPublicationGraphSealed = errors.New("parser-core phase zero: graph retired for publication; reset required")
var errPublicationGraphContext = errors.New("parser-core phase zero: publication retirement requires an unchanged completed fresh graph")

type publicationGraphState struct {
	owner                    *Core
	generation, phase, epoch uint64
	available, sealed        bool
}

// RetireFreshGraphForPublication consumes GSS handles from a completed fresh
// run. Syntax, scanner checkpoints, authentication and Work remain live.
// Small graphs retain their buffers. After retirement Reset precedes mutation.
func (c *Core) RetireFreshGraphForPublication(head Head, minimumBytes uint64) (bool, error) {
	if c == nil || c.publicationGraph.sealed || c.schedulerFrame.active || len(c.transactions) != 0 ||
		!c.publicationGraph.available || c.publicationGraph.owner != c ||
		c.publicationGraph.generation != c.resetGeneration || c.publicationGraph.phase != c.classificationPhase ||
		c.publicationGraph.epoch != c.schedulerFrame.epoch || !c.metadataConstructionAuthenticated || len(c.reusedSubtrees) != 0 {
		return false, errPublicationGraphContext
	}
	if _, err := c.Stats(head); err != nil {
		return false, err
	}
	var total uint64
	for _, item := range []struct {
		capacity int
		size     uintptr
	}{
		{cap(c.nodes), unsafe.Sizeof(nodeRecord{})}, {cap(c.links), unsafe.Sizeof(linkRecord{})},
		{cap(c.nodeLineages), unsafe.Sizeof(nodeLineageHot{})}, {cap(c.nodeLineageRecovery), unsafe.Sizeof(nodeLineageRecovery{})},
		{cap(c.nodeLineageRefSets), unsafe.Sizeof(DropCohortRefSet{})}, {cap(c.nodePrecedenceWide), unsafe.Sizeof(int64(0))},
		{cap(c.nodePathCountsWide), unsafe.Sizeof(nodePathCountRecord{})},
		{cap(c.nodeCheckpoints), unsafe.Sizeof(CheckpointID(0))}, {cap(c.boundaries.slots), unsafe.Sizeof(boundarySlot{})},
	} {
		bytes := uint64(item.capacity) * uint64(item.size)
		if math.MaxUint64-total < bytes {
			return false, errors.New("parser-core phase zero: publication graph footprint overflow")
		}
		total += bytes
	}
	if total < minimumBytes {
		return false, nil
	}
	c.publicationGraph.available = false
	c.publicationGraph.sealed = true
	c.nodes = nil
	c.links = nil
	c.nodeLineages = nil
	c.nodeLineageRecovery = nil
	c.nodeLineageRefSets = nil
	c.nodePathCountsWide = nil
	c.nodePrecedenceWide = nil
	c.nodePrecedenceWideBase = 0
	c.nodeCheckpoints = nil
	c.boundaries.slots = nil
	c.boundaries.count = 0
	c.boundaryJournal = nil
	c.nodeLineageJournal = nil
	c.popScratch = popEnumerationScratch{}
	return true, nil
}
