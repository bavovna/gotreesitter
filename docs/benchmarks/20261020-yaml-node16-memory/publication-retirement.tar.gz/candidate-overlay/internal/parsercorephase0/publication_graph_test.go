package parsercorephase0

import (
	"errors"
	"testing"
)

func TestPublicationGraphRetirementPreservesSyntaxAndWork(t *testing.T) {
	c := newTinyCoreWithLimits(t, Limits{})
	head, err := c.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	payload := appendShallowPayload(t, c, shallowPayloadSpec{symbol: 20, startByte: 0, endByte: 1, childSymbols: []Symbol{30}})
	c.metadataConstructionAuthenticated = true
	if err := c.RunFreshSchedulerSession(func(SchedulerTransactionToken) error { return nil }); err != nil {
		t.Fatal(err)
	}
	// A common-count session may retain wide storage from an earlier parse.
	c.nodePathCountsWide = make([]nodePathCountRecord, 0, 16)
	work := c.Work()
	subtrees := c.SubtreeCount()
	before := c.FootprintBytes()
	if retired, err := c.RetireFreshGraphForPublication(head, 0); err != nil || !retired {
		t.Fatalf("retired=%v err=%v", retired, err)
	}
	if c.Work() != work || c.SubtreeCount() != subtrees || c.FootprintBytes() >= before || cap(c.nodePathCountsWide) != 0 {
		t.Fatal("retirement lost syntax/work or retained graph capacity")
	}
	if _, err := c.MaterializationView(payload); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Stats(head); err == nil {
		t.Fatal("retired head remained valid")
	}
	if _, err := c.Seed(1, 0); !errors.Is(err, errPublicationGraphSealed) {
		t.Fatal(err)
	}
	if err := c.ApplySchedulerAtomic(func(SchedulerTransactionToken) error { return nil }); !errors.Is(err, errPublicationGraphSealed) {
		t.Fatal(err)
	}
	if err := c.RunFreshSchedulerSession(func(SchedulerTransactionToken) error { return nil }); !errors.Is(err, errPublicationGraphSealed) {
		t.Fatal(err)
	}
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Seed(1, 0); err != nil {
		t.Fatal("reset did not unseal", err)
	}
}
func TestPublicationGraphRetirementRejectsWrongLifetime(t *testing.T) {
	c := newTinyCoreWithLimits(t, Limits{})
	head, err := c.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	c.metadataConstructionAuthenticated = true
	if _, err := c.RetireFreshGraphForPublication(head, 0); !errors.Is(err, errPublicationGraphContext) {
		t.Fatal(err)
	}
	if err := c.RunFreshSchedulerSession(func(SchedulerTransactionToken) error {
		if _, err := c.RetireFreshGraphForPublication(head, 0); !errors.Is(err, errPublicationGraphContext) {
			t.Fatal(err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	if retired, err := c.RetireFreshGraphForPublication(head, ^uint64(0)); err != nil || retired {
		t.Fatal(retired, err)
	}
	if err := c.ApplyAtomic(func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	if _, err := c.RetireFreshGraphForPublication(head, 0); !errors.Is(err, errPublicationGraphContext) {
		t.Fatal(err)
	}
}

func TestPublicationGraphRetirementRejectsDirectSeedAfterCompletion(t *testing.T) {
	c := newTinyCoreWithLimits(t, Limits{})
	head, err := c.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	c.metadataConstructionAuthenticated = true
	if err := c.RunFreshSchedulerSession(func(SchedulerTransactionToken) error { return nil }); err != nil {
		t.Fatal(err)
	}
	if _, err := c.Seed(2, 1); err != nil {
		t.Fatal(err)
	}
	if _, err := c.RetireFreshGraphForPublication(head, 0); !errors.Is(err, errPublicationGraphContext) {
		t.Fatal("direct seed did not invalidate completion", err)
	}
}
