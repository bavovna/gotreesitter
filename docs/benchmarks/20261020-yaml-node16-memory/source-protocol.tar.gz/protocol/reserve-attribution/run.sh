#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/reserve-attribution/overlay.json'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/reserve-attribution/root.test . > /evidence/reserve-attribution/build.log 2>&1
GTS_STORAGE_CASE=yaml /evidence/reserve-attribution/root.test -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=8m > /evidence/reserve-attribution/yaml.log 2>&1
printf 'complete\n' > /evidence/reserve-attribution/complete.txt
