#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=44801
cd /candidate
for case in query_compile grammargen_lr; do
 /qualified-root.test -test.run '^$' -test.bench "^BenchmarkCompactThroughputGo$/^${case}$" -test.benchtime=6s -test.benchmem -test.count=1 -test.shuffle=44801 -test.cpuprofile "/evidence/${case}.cpu" -test.timeout=4m > "/evidence/${case}.log" 2>&1
 go tool pprof -top -nodecount=35 /qualified-root.test "/evidence/${case}.cpu" > "/evidence/${case}-flat.txt" 2>&1
 go tool pprof -top -cum -nodecount=35 /qualified-root.test "/evidence/${case}.cpu" > "/evidence/${case}-cumulative.txt" 2>&1
 go tool pprof -peek 'nodeWithPathCount|nodePathCount|runtime.duffcopy' /qualified-root.test "/evidence/${case}.cpu" > "/evidence/${case}-count-and-copy.txt" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
