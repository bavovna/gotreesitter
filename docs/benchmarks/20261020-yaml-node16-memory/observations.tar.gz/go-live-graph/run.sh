#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
cd /candidate
go test . -tags gts_parsercorephase0 -run '^TestFrontierLiveGraphCensus$' -count=1 -v -timeout=8m > /evidence/census.log 2>&1
printf 'complete\n' > /evidence/complete.txt
