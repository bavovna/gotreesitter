#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_STORAGE_CASE=yaml
cd /candidate
/profile-root.test -test.run '^TestAcceptedStorageCensus$' -test.count=16 -test.v -test.timeout=8m -test.cpuprofile /evidence/yaml.cpu -test.memprofile /evidence/yaml.heap -test.memprofilerate=65536 > /evidence/yaml.log 2>&1
for sample in alloc_space inuse_space; do
 go tool pprof -top -sample_index="$sample" -nodecount=25 /profile-root.test /evidence/yaml.heap > "/evidence/$sample.txt" 2>&1
done
go tool pprof -top -nodecount=25 /profile-root.test /evidence/yaml.cpu > /evidence/cpu-flat.txt 2>&1
go tool pprof -top -cum -nodecount=25 /profile-root.test /evidence/yaml.cpu > /evidence/cpu-cumulative.txt 2>&1
printf 'complete\n' > /evidence/complete.txt
