package parsercorephase0

import (
	"reflect"
	"testing"
)

func projectionCoverDemand(c *Core) {
	c.nodes = growArena(c.nodes, 200)
	c.nodeLineages = growArena(c.nodeLineages, 200)
	c.links = growArena(c.links, 180)
	c.subtrees = growArena(c.subtrees, 160)
	c.children = growArena(c.children, 150)
}

func TestProjectRecordArenasKeepsCapacityThatCoversDemand(t *testing.T) {
	c := projectionFixture(t)
	projectionCoverDemand(c)
	before, storage, work := c.FootprintBytes(), c.StorageBytes(), c.Work()
	pointers := [5]any{&c.nodes[0], &c.nodeLineages[0], &c.links[0], &c.subtrees[0], &c.children[0]}
	if got := testing.AllocsPerRun(10, func() {
		if c.ProjectRecordArenas(10000, 5000, 0) {
			panic("copied capacity that covers demand")
		}
	}); got != 0 {
		t.Fatalf("covered projection allocated %g times", got)
	}
	if c.FootprintBytes() != before || c.StorageBytes() != storage || c.Work() != work {
		t.Fatal("covered projection changed storage or work")
	}
	after := [5]any{&c.nodes[0], &c.nodeLineages[0], &c.links[0], &c.subtrees[0], &c.children[0]}
	if pointers != after {
		t.Fatal("covered projection replaced an arena")
	}
}

func TestProjectRecordArenasGrowsOnlyUncoveredArena(t *testing.T) {
	c := projectionFixture(t)
	projectionCoverDemand(c)
	// A retained node arena and a shorter lineage arena can have different
	// capacities after release or a targeted reserve. Cover node demand, but
	// leave the lineage arena one record short of that demand.
	c.nodes = growArena(c.nodes, 210)
	c.nodeLineages = append(make([]nodeLineageHot, 0, 199), c.nodeLineages...)
	records := append([]nodeLineageHot(nil), c.nodeLineages...)
	nodes, links, subtrees, children := &c.nodes[0], &c.links[0], &c.subtrees[0], &c.children[0]
	before, storage, work := c.FootprintBytes(), c.StorageBytes(), c.Work()
	// The missing lineage reserve adds 14 slots. A smaller budget refuses
	// the complete change; the next call may then take the exact increase.
	needed := uint64(213-199) * coreNodeLineageRecordBytes
	if c.ProjectRecordArenas(10000, 5000, needed-1) || c.FootprintBytes() != before {
		t.Fatal("insufficient budget partially grew storage")
	}
	if !c.ProjectRecordArenas(10000, 5000, needed) {
		t.Fatal("uncovered lineage demand did not grow")
	}
	if c.FootprintBytes()-before != needed || cap(c.nodeLineages) != 213 {
		t.Fatal("lineage reserve exceeded its budget")
	}
	if nodes != &c.nodes[0] || links != &c.links[0] || subtrees != &c.subtrees[0] || children != &c.children[0] {
		t.Fatal("copied an independently covered arena")
	}
	if !reflect.DeepEqual(records, c.nodeLineages) || c.StorageBytes() != storage || c.Work() != work {
		t.Fatal("projection changed records or work")
	}
}
