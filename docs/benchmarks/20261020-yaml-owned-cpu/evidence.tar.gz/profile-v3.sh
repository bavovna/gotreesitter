#!/usr/bin/env bash
set -euo pipefail
test -f /previous/public-checks-v3/complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=39101 GOFLAGS='-p=1 -buildvcs=false'
cd /public
for mode in owned ordinary legacy; do
 go test . -tags gts_parsercorephase0 -run '^$' -bench "^BenchmarkCompactThroughputYAML$/^eof8k_${mode}$" -benchtime=3s -benchmem -count=1 -shuffle=39101 -timeout=5m -cpuprofile="/evidence/$mode.cpu.pprof" -o /evidence/root.test > "/evidence/$mode.log" 2>&1
 go tool pprof -top -nodecount=30 /evidence/root.test "/evidence/$mode.cpu.pprof" > "/evidence/$mode.flat.txt" 2>&1
 go tool pprof -top -cum -nodecount=30 /evidence/root.test "/evidence/$mode.cpu.pprof" > "/evidence/$mode.cum.txt" 2>&1
done
python3 - <<'CHECK'
from pathlib import Path
import json
out={}
for mode in ('owned','ordinary','legacy'):
 s=Path(f'/evidence/{mode}.log').read_text();assert '\nPASS\n' in s and 'FAIL' not in s
 rows=[line.split() for line in s.splitlines() if line.startswith('Benchmark')];assert len(rows)==1
 f=rows[0];m={f[i+1]:float(f[i]) for i in range(2,len(f),2)}
 expected={'owned':(1,0),'ordinary':(0,1),'legacy':(0,0)}[mode]
 assert (m['compact-routes/op'],m['compact-fallbacks/op'])==expected
 out[mode]={'benchmark':f[0],'metrics':m}
Path('/evidence/profile-audit.json').write_text(json.dumps({'normal_pools':True,'cpu_only':True,'routes_asserted':True,'observations':out},indent=2)+'\n')
CHECK
printf 'complete\n' > /evidence/complete.txt
