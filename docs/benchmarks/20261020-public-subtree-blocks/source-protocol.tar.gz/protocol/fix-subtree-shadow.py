from pathlib import Path
import os,subprocess,shutil,json,hashlib
p=Path(__file__).resolve().parent;root=p/'candidate-source/internal/parsercorephase0'
shutil.copy2(p/'candidate-source-pins.json',p/'second-build-source-pins.json')
for name in ['core-default.log','core-shadow.log','core-first-runner.log']:shutil.copy2(p/name,p/('second-build-'+name))
for name in ['subtree_record_blocks.go','subtree_record_block_shadow.go','eof_recovery_shadow.go','subtree_record_blocks_test.go']:
 old=p/'second-build-overlay/internal/parsercorephase0'/name;old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,old)
def put(name,s):
 f=root/name;t=f.with_name(f.name+'.shadow-tmp');t.write_bytes(subprocess.run(['gofmt'],input=s.encode(),capture_output=True,check=True).stdout);os.replace(t,f)
s=(root/'subtree_record_blocks.go').read_text();start=s.index('func (s *subtreeRecordBlocks) CloneActive()');end=s.index('func (s *subtreeRecordBlocks) Reset()',start)
s=s[:start]+'''func (s *subtreeRecordBlocks) CloneActive() subtreeRecordBlocks { return s.cloneActive(0) }

// A detached recovery clone reserves its one appended root exactly. It must
// not allocate a whole suffix block outside the diagnostic clone's budget.
func (s *subtreeRecordBlocks) cloneActive(extra int) subtreeRecordBlocks {
 if extra < 0 || extra > int(^uint(0)>>1)-s.length { panic("invalid subtree clone reserve") }
 want := s.length+extra
 firstCapacity := max(len(s.first), min(want,subtreeRecordBlockSize))
 if s.length>cap(s.first) { firstCapacity=cap(s.first) }
 clone:=subtreeRecordBlocks{length:s.length,first:make([]subtreeRecord,len(s.first),firstCapacity)}
 copy(clone.first,s.first)
 if want>firstCapacity {
  count:=(want-firstCapacity+subtreeRecordBlockSize-1)>>subtreeRecordBlockShift
  clone.blocks=make([]subtreeRecordBlock,count)
  for i:=range clone.blocks {
   goal:=min(subtreeRecordBlockSize,want-firstCapacity-i*subtreeRecordBlockSize)
   active:=min(goal,max(s.length-firstCapacity-i*subtreeRecordBlockSize,0))
   clone.blocks[i].records=make([]subtreeRecord,active,goal)
   if active>0 {copy(clone.blocks[i].records,s.blocks[i].records[:active])}
  }
 }
 clone.refreshGeometry();return clone
}

func (s *subtreeRecordBlocks) CloneActiveFootprintBytes() uint64 { return s.cloneFootprintBytes(0) }
func (s *subtreeRecordBlocks) cloneFootprintBytes(extra int) uint64 {
 if extra<0 || extra>int(^uint(0)>>1)-s.length {panic("invalid subtree clone reserve")}
 want:=s.length+extra
 firstCapacity:=max(len(s.first),min(want,subtreeRecordBlockSize))
 if s.length>cap(s.first) {firstCapacity=cap(s.first)}
 total:=uint64(want)*uint64(unsafe.Sizeof(subtreeRecord{}))
 if want>firstCapacity {
  count:=(want-firstCapacity+subtreeRecordBlockSize-1)>>subtreeRecordBlockShift
  total+=uint64(count)*uint64(unsafe.Sizeof(subtreeRecordBlock{}))
 }
 return total
}

'''+s[end:];put('subtree_record_blocks.go',s)
s=(root/'subtree_record_block_shadow.go').read_text()
s=s.replace('func equalDiagnosticSubtreeBlocks(left, right *subtreeRecordBlocks) bool {\n\tif left.Len() != right.Len() {','func equalDiagnosticSubtreeBlocks(left,right *subtreeRecordBlocks) bool {\n return left.Len()==right.Len() && equalDiagnosticSubtreePrefix(left,right)\n}\n\nfunc equalDiagnosticSubtreePrefix(left,right *subtreeRecordBlocks) bool {\n\tif left.Len() > right.Len() {')
put('subtree_record_block_shadow.go',s)
s=(root/'eof_recovery_shadow.go').read_text()
s=s.replace('shadow.subtrees = cloneDiagnosticSlice(live.subtrees, 1)','shadow.subtrees = live.subtrees.cloneActive(1)')
s=s.replace('equalDiagnosticSlice(live.subtrees, shadow.subtrees[:live.subtrees.Len()])','equalDiagnosticSubtreePrefix(&live.subtrees,&shadow.subtrees)')
needle='{1, coreSubtreeRecordBytes}';assert s.count(needle)==1
s=s.replace(needle,'{1, live.subtrees.cloneFootprintBytes(1)-live.subtrees.CloneActiveFootprintBytes()}')
put('eof_recovery_shadow.go',s)
s=(root/'subtree_record_blocks_test.go').read_text()+'''
func TestSubtreeRecordBlocksCloneAppendReserveChargesBoundaryMetadata(t *testing.T) {
 for _,length:=range []int{0,17,subtreeRecordBlockSize-1,subtreeRecordBlockSize,subtreeRecordBlockSize+1,2*subtreeRecordBlockSize} {
  var live subtreeRecordBlocks;live.Grow(length)
  for i:=0;i<length;i++ {live.Append(subtreeRecord{startByte:uint32(i)},^uint32(0))}
  shadow:=live.cloneActive(1)
  if shadow.Len()!=length || shadow.Capacity()!=length+1 || shadow.FootprintBytes()!=live.cloneFootprintBytes(1) {t.Fatalf("length %d: clone reserve was not exact and fully charged",length)}
  before:=shadow.FootprintBytes()
  if id,ok:=shadow.Append(subtreeRecord{endByte:99},^uint32(0));!ok || int(id)!=length+1 || shadow.FootprintBytes()!=before {t.Fatalf("length %d: reserved append grew backing storage",length)}
  for i:=0;i<length;i++ {if *shadow.At(i)!=*live.At(i) || shadow.At(i)==live.At(i) {t.Fatal("clone altered or borrowed a source record")}}
 }
}
''';put('subtree_record_blocks_test.go',s)
pins=json.loads((p/'candidate-source-pins.json').read_text())
for rel in pins:pins[rel]=hashlib.sha256((p/'candidate-source'/rel).read_bytes()).hexdigest()
(p/'candidate-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('Recovery root append reserve now charges exact record and block metadata bytes; original prefix comparison preserved')
