from pathlib import Path
import os,subprocess
p=Path(__file__).resolve().parent/'candidate-source/internal/parsercorephase0'
def put(name,s):
 f=p/name;t=f.with_name(f.name+'.subtrees-tmp');t.write_bytes(subprocess.run(['gofmt'],input=s.encode(),capture_output=True,check=True).stdout);os.replace(t,f)
s=(p/'core.go').read_text()
old='c.subtrees = append(c.subtrees, r)';assert s.count(old)==1
s=s.replace(old,'if _, ok := c.subtrees.Append(r,c.limits.MaxSubtrees); !ok {return 0,errors.New("parser-core phase zero: subtree arena publication failed")}')
s=s.replace('c.subtrees.Truncate(mark.subtrees)','if !c.subtrees.Truncate(mark.subtrees) {panic("parser-core phase zero: invalid subtree checkpoint")}')
put('core.go',s)
s=(p/'storage_bytes.go').read_text().replace('uint64(c.subtrees.Capacity())*coreSubtreeRecordBytes','c.subtrees.FootprintBytes()');put('storage_bytes.go',s)
s=(p/'arena_reserve.go').read_text().replace('c.subtrees = reserveArena(c.subtrees, subtrees)','c.subtrees.Grow(subtrees)').replace('c.subtrees = growArena(c.subtrees, subtrees)','c.subtrees.Grow(subtrees)')
s=s.replace('return nodeRecordBlockMetadataBytes(nodes) + uint64(nodes)*coreNodeRecordBytes +','return nodeRecordBlockMetadataBytes(nodes) + subtreeRecordBlockMetadataBytes(subtrees) + uint64(nodes)*coreNodeRecordBytes +')
s=s.replace('metadata := nodeRecordBlockMetadataBytes(nodes)','metadata := nodeRecordBlockMetadataBytes(nodes) + subtreeRecordBlockMetadataBytes(subtrees)')
s=s.replace('// Deduct the unscaled node-table cost before scaling record counts. The\n// scaled table cannot be larger, so rounding never exceeds the byte ceiling.','// Deduct unscaled block-table costs before scaling record counts. Scaled\n// tables cannot be larger, so rounding never exceeds the byte ceiling.')
put('arena_reserve.go',s)
s=(p/'arena_projection.go').read_text().replace('delta(subtrees, c.subtrees.Capacity(), coreSubtreeRecordBytes)','c.subtrees.GrowthFootprintBytes(subtrees)').replace('c.subtrees = growArena(c.subtrees, subtrees)','c.subtrees.Grow(subtrees)');put('arena_projection.go',s)
s=(p/'eof_recovery_shadow.go').read_text()
s=s.replace('{live.subtrees.Len(), coreSubtreeRecordBytes}','{1, live.subtrees.CloneActiveFootprintBytes()}')
s=s.replace('shadow.subtrees = cloneDiagnosticSlice(live.subtrees, 0)','shadow.subtrees = live.subtrees.CloneActive()')
s=s.replace('equalDiagnosticSlice(live.subtrees, shadow.subtrees)','equalDiagnosticSubtreeBlocks(&live.subtrees, &shadow.subtrees)')
s=s.replace('disjointDiagnosticSlice(live.subtrees, shadow.subtrees)','disjointDiagnosticSubtreeBlocks(&live.subtrees, &shadow.subtrees)')
put('eof_recovery_shadow.go',s)
s=(p/'node_record_block_test_helpers_test.go').read_text().replace('nodeRecordBlocks','subtreeRecordBlocks').replace('nodeBlocksFromSliceForTest','subtreeBlocksFromSliceForTest').replace('nodeRecord','subtreeRecord').replace('NodeRecordBlocks','SubtreeRecordBlocks').replace('retired node','unpublished subtree')
put('subtree_record_block_test_helpers_test.go',s)
s=(p/'node_record_block_shadow.go').read_text().replace('NodeBlocks','SubtreeBlocks').replace('nodeRecordBlocks','subtreeRecordBlocks').replace('nodeRecord','subtreeRecord').replace('nodeBlockSpan','subtreeBlockSpan').replace('nodeBlockSpans','subtreeBlockSpans')
s=s.replace(' || left.retiredThrough != right.retiredThrough','')
s=s.replace('3+len(s.blocks)+len(s.spare)','2+len(s.blocks)')
start=s.index('\tif cap(s.spare) > 0 {');end=s.index('\n\tfor _, block := range s.blocks',start);s=s[:start]+s[end:]
start=s.index('\tfor _, records := range s.spare {');end=s.index('\n\treturn spans',start);s=s[:start]+s[end:]
put('subtree_record_block_shadow.go',s)
print('Subtree append, storage accounting, reserves, rollback and detached clones adapted')
