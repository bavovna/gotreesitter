package main

import (
 "bytes"
 "fmt"
 "go/ast"
 "go/format"
 "go/parser"
 "go/token"
 "os"
 "path/filepath"
 "reflect"
 "strings"
)

var exprType=reflect.TypeOf((*ast.Expr)(nil)).Elem()
var stmtType=reflect.TypeOf((*ast.Stmt)(nil)).Elem()
var allowed=map[string]bool{"c":true,"core":true,"compact":true,"fixture.core":true,"f.core":true,"live":true,"shadow":true,"before":true,"after":true,"control":true,"tiny":true,"full":true}
func show(n ast.Node) string {var b bytes.Buffer;format.Node(&b,token.NewFileSet(),n);return b.String()}
func subtrees(e ast.Expr)bool {s,ok:=e.(*ast.SelectorExpr);return ok&&s.Sel.Name=="subtrees"&&allowed[show(s.X)]}
func call(x ast.Expr,name string,args ...ast.Expr)ast.Expr{return &ast.CallExpr{Fun:&ast.SelectorExpr{X:x,Sel:ast.NewIdent(name)},Args:args}}
func identCall(name string,args ...ast.Expr)ast.Expr{return &ast.CallExpr{Fun:ast.NewIdent(name),Args:args}}
func subtreeSlice(e ast.Expr)bool {
 switch x:=e.(type){
 case *ast.CompositeLit:return show(x.Type)=="[]subtreeRecord"
 case *ast.CallExpr:return len(x.Args)>0&&show(x.Fun)=="make"&&show(x.Args[0])=="[]subtreeRecord"
 }
 return false
}
func rewrite(e ast.Expr,test bool)ast.Expr {
 switch x:=e.(type){
 case *ast.CallExpr:
  name:=show(x.Fun)
  if (name=="len"||name=="cap")&&len(x.Args)==1&&subtrees(x.Args[0]){method:="Len";if name=="cap"{method="Capacity"};return call(x.Args[0],method)}
  if test&&name=="append"&&len(x.Args)==2&&subtrees(x.Args[1])&&x.Ellipsis!=0{return call(x.Args[1],"snapshotForTest")}
  if test&&name=="reflect.DeepEqual"{for i,arg:=range x.Args {if subtrees(arg){x.Args[i]=call(arg,"snapshotForTest")}}}
 case *ast.IndexExpr:
  if subtrees(x.X){return &ast.UnaryExpr{Op:token.MUL,X:call(x.X,"At",identCall("int",x.Index))}}
 case *ast.UnaryExpr:
  if x.Op==token.AND {if inner,ok:=x.X.(*ast.UnaryExpr);ok&&inner.Op==token.MUL{return inner.X}}
 }
 return e
}
func rewriteStmt(s ast.Stmt,test bool)ast.Stmt {
 if r,ok:=s.(*ast.RangeStmt);ok&&subtrees(r.X){if r.Value==nil{r.X=call(r.X,"Len")}else if test{r.X=call(r.X,"snapshotForTest")};return s}
 a,ok:=s.(*ast.AssignStmt);if !ok||len(a.Lhs)!=1||len(a.Rhs)!=1||!subtrees(a.Lhs[0]){return s}
 lhs,rhs:=a.Lhs[0],a.Rhs[0]
 if sl,ok:=rhs.(*ast.SliceExpr);ok&&subtrees(sl.X)&&sl.Low==nil&&sl.High!=nil{
  method:="Truncate";if show(sl.High)=="0"{method="Reset";return &ast.ExprStmt{X:call(lhs,method)}}
  return &ast.ExprStmt{X:call(lhs,method,sl.High)}
 }
 if show(rhs)=="nil"{a.Rhs[0]=&ast.CompositeLit{Type:ast.NewIdent("subtreeRecordBlocks")};return a}
 if test&&subtreeSlice(rhs){a.Rhs[0]=identCall("subtreeBlocksFromSliceForTest",rhs);return a}
 if test {if fn,ok:=rhs.(*ast.CallExpr);ok&&show(fn.Fun)=="append"&&len(fn.Args)==2&&subtrees(fn.Args[0]){
  if fn.Ellipsis!=0{return &ast.ExprStmt{X:call(lhs,"appendSliceForTest",fn.Args[1])}}
  return &ast.ExprStmt{X:call(lhs,"Append",fn.Args[1],&ast.UnaryExpr{Op:token.XOR,X:identCall("uint32",&ast.BasicLit{Kind:token.INT,Value:"0"})})}
 }}
 return s
}
func walk(v reflect.Value,test bool){
 if !v.IsValid(){return}
 switch v.Kind(){
 case reflect.Interface:
  if v.IsNil(){return};walk(v.Elem(),test)
  if v.CanSet()&&v.Type()==exprType{v.Set(reflect.ValueOf(rewrite(v.Interface().(ast.Expr),test)))}
  if v.CanSet()&&v.Type()==stmtType{v.Set(reflect.ValueOf(rewriteStmt(v.Interface().(ast.Stmt),test)))}
 case reflect.Pointer:if !v.IsNil(){walk(v.Elem(),test)}
 case reflect.Struct:for i:=0;i<v.NumField();i++{walk(v.Field(i),test)}
 case reflect.Slice:for i:=0;i<v.Len();i++{walk(v.Index(i),test)}
 }
}
func main(){
 root:=os.Args[1];entries,err:=filepath.Glob(filepath.Join(root,"internal/parsercorephase0/*.go"));if err!=nil{panic(err)}
 changed:=0
 for _,path:=range entries {
  data,err:=os.ReadFile(path);if err!=nil{panic(err)}
  if !bytes.Contains(data,[]byte(".subtrees"))&&!bytes.Contains(data,[]byte("subtrees:"))&&!bytes.Contains(data,[]byte("type Core struct")){continue}
  fs:=token.NewFileSet();file,err:=parser.ParseFile(fs,path,data,parser.ParseComments|parser.SkipObjectResolution);if err!=nil{panic(err)}
  test:=strings.HasSuffix(path,"_test.go")
  ast.Inspect(file,func(n ast.Node)bool{
   if typ,ok:=n.(*ast.TypeSpec);ok&&typ.Name.Name=="Core"{if st,ok:=typ.Type.(*ast.StructType);ok{for _,field:=range st.Fields.List{if len(field.Names)==1&&field.Names[0].Name=="subtrees"{field.Type=ast.NewIdent("subtreeRecordBlocks")}}}}
   if test {if kv,ok:=n.(*ast.KeyValueExpr);ok&&show(kv.Key)=="subtrees"&&subtreeSlice(kv.Value){kv.Value=identCall("subtreeBlocksFromSliceForTest",kv.Value)}}
   return true
  })
  walk(reflect.ValueOf(file),test)
  var out bytes.Buffer;if err:=format.Node(&out,fs,file);err!=nil{panic(err)}
  formatted,err:=format.Source(out.Bytes());if err!=nil{panic(err)}
  if !bytes.Equal(data,formatted){tmp:=path+".tmp";if err:=os.WriteFile(tmp,formatted,0644);err!=nil{panic(err)};if err:=os.Rename(tmp,path);err!=nil{panic(err)};changed++;fmt.Println(filepath.Base(path))}
 }
 fmt.Println("changed_files",changed)
}
