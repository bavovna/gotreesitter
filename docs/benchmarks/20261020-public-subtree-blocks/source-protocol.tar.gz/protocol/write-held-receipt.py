from pathlib import Path
import json,re
p=Path(__file__).resolve().parent
repo=Path('/home/draco/.codex/worktrees/public-subtree-block-storage/gotreesitter')
read=lambda n:json.loads((p/n).read_text())
r=read('perf-summary.json');rss=read('rss/rss-matched/audit.json');assert r['benchmark_rows']==480 and len(r['median_10_percent_failures'])==1
ps={}
for lang in ['go','yaml']:
 section=None
 for line in (p/(lang+'-benchstat.txt')).read_text().splitlines():
  if '│' in line:section=next((u for u in ['sec/op','B/op','allocs/op'] if u in line),None)
  m=re.match(r'CompactThroughput(?:Go|YAML)/(\S+).*\(p=([0-9.]+) n=20\)',line)
  if m and section:ps[lang,m[1],section]=float(m[2])
assert len(ps)==36
pv=lambda x:'<.001' if x==0 else f'{x:.3f}'
num=lambda x:f'{x:,.0f}' if x==int(x) else f'{x:,.1f}'
large=r['results']['go']['BenchmarkCompactThroughputGo/fresh_one_mib']['metrics']
lead=f"The 16K-record subtree arena stays **held**. Fresh one-MiB Go allocated bytes fall **{num(large['B/op']['before'])}→{num(large['B/op']['after'])} B/op ({large['B/op']['change_percent']:+.2f}%, p<.001)**, but heap objects rise **{num(large['allocs/op']['before'])}→{num(large['allocs/op']['after'])} ({large['allocs/op']['change_percent']:+.2f}%, p<.001)**. That exceeds the 10% allocation ratchet. All 480 rows were retained and audited; the byte saving does not qualify this runtime for promotion.\n\n"
body="""The reference is the qualified graph-node arena in PR #1502: code commit `647ea982cdf2f6accedce5cda0705949f957acb8`, equivalent Go source at PR head `98747629037d6934b9dcf6dfbb41db6d082a3078`. The held candidate has 3,541 Go files, with 47 internal files changed relative to the 3,535-file reference. Its private Buckley code commit is `215dfb79063df1e9211ce5962a7d4a453a08b8b3`. This receipt publishes evidence only.

The candidate stores public subtree records in a contiguous prefix and 16,384-record suffix blocks. Logical SubtreeIDs, records, limits and rollback behavior stay intact. Reset retains buffers. Capacity and footprint use cached gauges and charge full block metadata. Detached EOF clones copy active data, reserve the appended recovery root exactly and charge any additional block metadata; original-record prefix comparisons and full-capacity alias checks remain.

The paired one-MiB Go capacity probe keeps 1,032,095 graph nodes, 903,086 public constructions and 44,972,840 subtree-record capacity bytes. The new subtree table has 62 suffix entries and costs 1,488 bytes. Core backing capacity rises 119,918,852→119,920,340; its fixed header grows 4,320→4,368 bytes. The allocation-byte reduction comes from avoiding repeated whole-arena growth copies. Final record capacity is unchanged.

All 414 ledger rows and four canonical Go work/tree vectors remain exact. All 206 × 72-step invariant sessions, explicit owned YAML and 618 exact named C fixture checks pass. The 204 strict corpus outcomes retain 45 known legacy failures. All 306 expanded Go outcomes and 300 routes remain exact, retaining 39 known failures. The actual one-MiB Go C tree digest remains `1464b53d73dd7d3ad9ff2b7e064235a4a68442ec7e1379d4c2c263fc6a9eef6c`; large YAML C tests pass too.

Default, shadow, phase-zero, phase-zero-A and one-pass Core modes pass with 588 / 600 / 624 / 722 / 600 named top-level tests. Scoped race, native/386, budget/pool, layout and API gates pass. All 3,541 candidate and 3,535 reference source hashes remain exact after timing. No production block retirement is enabled.

| Counter | Before→after |
| --- | ---: |
| Complete ordinary and owned ledger rows | 414→414, exact |
| Canonical Go tree/work vectors | 4→4, exact |
| Go R4 full nodes / tokens | 1,251→1,251 / 589→589 |
| Go R4 first-edit reused bytes / splices | 1,784→1,784 / 266→266 |
| Owned YAML full / first-edit nodes | 484→484 / 484→484 |
| One-MiB Go public constructions / tokens | 903,086→903,086 / 425,742→425,742 |

Twenty alternating matched pairs per language use GOMAXPROCS=1, count 1/process, 750 ms, benchmem, normal pools, CPU 6 and serialized six-GiB Docker. Go seeds are 46301–46320; YAML seeds are 46201–46220. Actual paired workload orders, route/work metrics and all 480 rows were audited. The only median-ratchet failure is the Go one-MiB heap-object count.

"""
table='| Case | Time change | p | B/op change | Objects before→after |\n| --- | ---: | ---: | ---: | ---: |\n'
for lang,benches in r['results'].items():
 for name,row in sorted(benches.items()):
  case=name.split('/',1)[1];m=row['metrics'];table+=f"| {lang}/{case} | {m['ns/op']['change_percent']:+.3f}% | {pv(ps[lang,case,'sec/op'])} | {m['B/op']['change_percent']:+.3f}% | {num(m['allocs/op']['before'])}→{num(m['allocs/op']['after'])} |\n"
ratios=rss['candidate_baseline_median_ratios'];maximum=max(x['rss_bytes_per_source_byte'] for x in rss['initial']+rss['matched'] if x['role']=='candidate')
end=f"""
Go query-compile time falls 6.39% (p=.018); one-MiB parse timing is inconclusive (p=.841). No-edit reparses allocate zero bytes and objects. Every direction is retained in the table, including controls; the allocation failure holds the entire candidate.

All 126 RSS processes pass, retaining the six initial and 120 matched processes. Candidate/baseline median ratios are {ratios['go']:.6f} Go / {ratios['yaml_ordinary']:.6f} ordinary YAML / {ratios['yaml_owned']:.6f} owned YAML. Maximum candidate RSS is {maximum:.3f} bytes/source byte, below 400. RSS seeds are 46101–46120. These establish safety, not a causal RSS reduction.

Initial compilation caught a borrowed record-store alias, a test receiver missed by the AST migration, and two detached-snapshot slice operations. Their source hashes, overlays and failed logs remain archived. The fixes preserve remap-error assertions, compare the original record prefix after shadow appends and reserve recovery-root capacity exactly. Native, race and 386 tests cover that reserve at block boundaries and reject interior/unused-buffer aliases.

The follow-up increases blocks to 65,536 records to reduce page-buffer allocations. It requires fresh correctness, memory and timing gates. No counter exception or production pin changes were requested. Ordinary YAML routing and graduation settings remain unchanged. The [replay bundle](benchmarks/20261020-public-subtree-blocks/README.md) contains exact sources, rejected attempts, executed protocols, all raw results and hashes.
"""
(repo/'docs/compact-public-subtree-block-screen-20261020.md').write_text('# Public subtree blocks: allocation-count rejection\n\n'+lead+body+table+end)
base=repo/'docs/benchmarks/20261020-public-subtree-blocks';a=json.loads((base/'archives.json').read_text());count=sum(x['members'] for x in a['archives']);assert not a['promotion_eligible']
(base/'README.md').write_text(f"""# Held 16K-record subtree arena

The [receipt](../../compact-public-subtree-block-screen-20261020.md) records an 18.42% Go byte-allocation saving and the 21.59% heap-object increase that rejects promotion. All 480 timing rows and all 126 RSS processes are retained.

Reference code commit `647ea982cdf2f6accedce5cda0705949f957acb8` and PR #1502 head `98747629037d6934b9dcf6dfbb41db6d082a3078` have identical 3,535-file Go source. The held candidate has 3,541 Go files and a 47-file internal overlay. Its source is not promoted by this receipt.

`archives.json` pins three archive hashes, sizes and member counts. `archive-members.json` pins every member. All {count:,} members were reopened and verified by size and SHA-256; binaries and caches are excluded.

- `source-protocol.tar.gz` includes the final candidate overlay, complete source manifests, reference counters/canonical vectors, exact inputs, executed scripts and source overlays from failed compilation attempts.
- `qualification.tar.gz` includes all Core build modes, 206 edit sessions, 618 named C fixtures, strict/expanded outcomes, actual large-Go C verification, race/386/budget/API gates and failed build logs.
- `measurements.tar.gz` includes paired capacity results, six initial plus 120 matched RSS processes, all shuffled timing processes, workload-order/ratchet audits and benchstat output.

To replay, check out the reference commit, verify every reference source hash, copy the checkout and apply `candidate-overlay/`, then verify every candidate hash. Extract `protocol/` into a fresh result directory. Use the pinned Go 1.25.14 Docker image `sha256:187907888b4bdc6f326c87b045718339e5f665baceb27db6b74633ca41e996df`, locked C cache, both Docker locks, six-GiB memory, CPU 6 and GOMAXPROCS=1. Mount sources read-only at `/reference` and `/candidate`, results/protocol at `/evidence`.

Run `core-first.sh`, then `qualify-and-audit.sh`. It reuses completed default/shadow logs and runs the remaining build modes, separate one-language C/invariant processes, strict/expanded controls, the actual one-MiB C witness, race/386 and API/layout guards. Empty runs and changed source hashes are rejected.

For RSS, mount the protocol root at `/lab` and `rss/` at `/evidence`, then run `/lab/rss-after-qualification.sh`. After RSS passes, mount the protocol root at both `/lab` and `/evidence` and run `capacity-perf-after-rss.sh`. Go seeds are 46301–46320, YAML 46201–46220, RSS 46101–46120. Normal pools and memory/stack settings stay in force. Run `analyze-perf.py`, then benchstat on each complete pair and verify source hashes again. **The analyzer is expected to exit 1 because the heap-object ratchet fails.**

The original lab is `/home/draco/.local/state/gotreesitter-evidence/20261020-public-subtree-blocks`. Archived scripts retain original paths; adjust mount/output locations for replay. Failed migration helpers remain evidence of their attempts; final-source replay applies the qualified overlay directly.
""")
print('Held receipt and replay README written; no runtime promotion')
