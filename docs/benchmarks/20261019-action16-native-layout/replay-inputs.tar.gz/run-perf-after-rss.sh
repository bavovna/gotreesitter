#!/usr/bin/env bash
set -euo pipefail
lab=/home/draco/.local/state/gotreesitter-evidence/20261019-action16-native-layout
wait_deadline=$((SECONDS + 2400))
while [[ ! -f "$lab/rss/complete.txt" ]]; do
 if (( SECONDS >= wait_deadline )); then echo 'RSS prerequisite timed out; performance not started'; exit 1; fi
 if rg -q '^exit_code: [1-9]|^oom_killed: true|^wall_timed_out: true' "$lab/rss-runner.log" "$lab/qualification-runner.log"; then echo 'A prerequisite failed; performance not started'; exit 1; fi
 sleep 2
done
bash /home/draco/.local/state/gotreesitter-evidence/20261018-go-legacy-candidates/offline-runner/cgo_harness/docker/run_parity_in_docker.sh --repo-root /home/draco/work/gotreesitter --image sha256:187907888b4bdc6f326c87b045718339e5f665baceb27db6b74633ca41e996df --no-build --memory 6g --cpus 1 --cpuset-cpus 6 --gomemlimit 5GiB --label action16-native-perf --mount /home/draco/.local/state/gotreesitter-evidence/20261019-node24-inline-precedence/candidate-source:/reference:ro --mount "$lab/candidate-source:/candidate:ro" --mount "$lab:/evidence" --mount /home/draco/.local/state/nightwatch/gts-docker.lock:/gts-locks/nightwatch.lock --mount /tmp/gts-docker.lock:/gts-locks/common.lock -- 'export PATH=/usr/local/go/bin:$PATH; flock /gts-locks/nightwatch.lock flock /gts-locks/common.lock bash /evidence/perf.sh' > "$lab/perf-runner.log" 2>&1
