#!/usr/bin/env python3
from pathlib import Path
import json
lab=Path(__file__).resolve().parent
changes=[];bad=[];exact=0;total=0

def differences(a,b,path=()):
 if type(a)!=type(b):return [(path,a,b)]
 if isinstance(a,dict):
  if a.keys()!=b.keys():return [(path,a,b)]
  return [item for key in a for item in differences(a[key],b[key],path+(key,))]
 if isinstance(a,list):
  if len(a)!=len(b):return [(path,a,b)]
  return [item for i in range(len(a)) for item in differences(a[i],b[i],path+(i,))]
 return [] if a==b else [(path,a,b)]

for scope,suffix,count in [('ordinary','ledger',412),('diagnostic_owned','owned',2)]:
 roles=[json.loads((lab/f'out/{role}-{suffix}.json').read_text()) for role in ('reference','candidate')]
 rows=[{(r['language'],r['route']):r for r in data['rows']} for data in roles]
 assert rows[0].keys()==rows[1].keys() and len(rows[0])==count
 for key,a in rows[0].items():
  total+=1;diff=differences(a,rows[1][key])
  if not diff:exact+=1
  for path,before,after in diff:
   allowed=(scope=='diagnostic_owned' and key==('yaml','candidate') and path in [('full','new_nodes'),('edits',0,'counters','new_nodes')] and (before,after)==(482,484))
   item=dict(scope=scope,language=key[0],route=key[1],path=path,before=before,after=after,previous_owner_approval=allowed)
   changes.append(item)
   if not allowed:bad.append(item)
report=dict(baseline='88dc1d9c3ff15cc2b8b5c53864455fc3a24a9d34',candidate='bdc453188793e830ee45ca0bc6cb7e536c420e7c',rows=total,complete_rows_exact=exact,changes=changes,unapproved_changes=bad,passed=not bad,approval_scope='Only the two explicitly owner-approved diagnostic-owned YAML 482->484 node counters. No new exception or baseline reset.')
(lab/'counter-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
assert total==414 and not bad
