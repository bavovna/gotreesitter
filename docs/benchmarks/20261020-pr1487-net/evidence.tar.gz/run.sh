#!/usr/bin/env bash
set -euo pipefail
test -f /previous/perf/complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
mkdir -p /evidence/out /evidence/perf
for role in reference candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/out/$role-counter" ./cmd/perfcounterledger > "/evidence/out/$role-counter-build.log" 2>&1
 "/evidence/out/$role-counter" --write --output "/evidence/out/$role-ledger.json" > "/evidence/out/$role-ledger.log" 2>&1
 GTS_LAYOUT_OWNED_PROBE=1 "/evidence/out/$role-counter" --langs yaml > "/evidence/out/$role-owned.json" 2> "/evidence/out/$role-owned.log"
done
python3 /evidence/audit-counters.py
cd /candidate
bash scripts/run_randomized_benchmarks.sh --output /evidence/perf/yaml-after.txt --baseline-root /reference --baseline-output /evidence/perf/yaml-before.txt --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned --runs 20 --seed-start 40201 --benchtime 750ms > /evidence/perf/yaml-runner.log 2>&1
bash scripts/run_randomized_benchmarks.sh --output /evidence/perf/go-after.txt --baseline-root /reference --baseline-output /evidence/perf/go-before.txt --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr,BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib --runs 20 --seed-start 40301 --benchtime 750ms > /evidence/perf/go-runner.log 2>&1
printf 'complete\n' > /evidence/complete.txt
