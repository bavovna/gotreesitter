#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
from collections import defaultdict
from statistics import median
lab=Path(__file__).resolve().parent
net='pr1487' in lab.name
assert (lab/('complete.txt' if net else 'perf/complete.txt')).read_text().strip()=='complete'
if net:assert json.loads((lab/'counter-audit.json').read_text())['passed']
else:assert json.loads((lab/'prior-qualified-counter-gate.json').read_text())['work_direction_passed']
starts={'go':40301 if net else 40101,'yaml':40201 if net else 40001}
expected={'go':{'BenchmarkCompactThroughputGo/'+name for name in ['query_compile','grammargen_lr','full_dfa','single_byte_edit_dfa','no_edit_dfa','fresh_one_mib']},'yaml':{'BenchmarkCompactThroughputYAML/'+name for name in ['r4_legacy','eof8k_legacy','r4_ordinary','eof8k_ordinary','r4_owned','eof8k_owned']}}
results={};failures=[];rows=0;order_report={}
for language,names in expected.items():
 roles={};orders={}
 for role,suffix in [('baseline','before'),('candidate','after')]:
  text=(lab/f'perf/{language}-{suffix}.txt').read_text()
  assert text.rstrip().endswith('# status: complete') and 'FAIL' not in text
  assert f"# seeds: {starts[language]}..{starts[language]+19}" in text
  data=defaultdict(list);order_by_seed={};seed=None;actual=[]
  for line in text.splitlines():
   match=re.match(r'# seed: (\d+);',line)
   if match:seed=int(match.group(1));actual=[]
   if line.startswith('Benchmark'):
    f=line.split();name=re.sub(r'-[0-9]+$','',f[0]);assert name in names,name
    metrics={f[i+1]:float(f[i]) for i in range(2,len(f),2)}
    assert {'ns/op','B/op','allocs/op'}<=metrics.keys(),line
    actual.append(name);data[name].append(metrics);rows+=1
   if line.startswith('# workload order:'):
    declared=line.split(': ',1)[1].split(',');assert declared==actual
    assert len(declared)==6 and set(declared)==names
    order_by_seed[seed]=declared
  assert len(order_by_seed)==20 and set(order_by_seed)==set(range(starts[language],starts[language]+20))
  assert set(data)==names and all(len(v)==20 for v in data.values())
  roles[role]=data;orders[role]=order_by_seed
 assert orders['baseline']==orders['candidate']
 distinct=len({tuple(v) for v in orders['baseline'].values()});assert distinct>1
 order_report[language]={'matched_pairs':20,'distinct_orders':distinct,'seeds':list(range(starts[language],starts[language]+20))}
 results[language]={}
 for name in sorted(names):
  a,b=roles['baseline'][name],roles['candidate'][name]
  units=set(a[0]);assert all(set(v)==units for v in a+b)
  custom={}
  for unit in units-{'ns/op','B/op','allocs/op','MB/s'}:
   left={v[unit] for v in a};right={v[unit] for v in b};assert len(left)==len(right)==1,(name,unit)
   before,after=next(iter(left)),next(iter(right));custom[unit]=[before,after]
   # Prior owner approval covers the net PR's diagnostic-owned YAML node change.
   approved=(net and language=='yaml' and name.endswith('_owned') and unit=='public-nodes/op' and ((before,after)==(482,484) or (before,after)==(1928,1936)))
   assert before==after or approved,(name,unit,before,after)
  medians={unit:{'before':median(v[unit] for v in a),'after':median(v[unit] for v in b)} for unit in ['ns/op','B/op','allocs/op']}
  for unit,item in medians.items():
   before,after=item['before'],item['after'];item['change_percent']=100*(after/before-1) if before else (0 if after==0 else None)
   if unit in ('ns/op','allocs/op') and after>1.1*before:failures.append(dict(language=language,benchmark=name,metric=unit,**item))
  if name.endswith('/no_edit_dfa'):assert all(v['B/op']==v['allocs/op']==0 for v in a+b)
  results[language][name]={'metrics':medians,'custom':custom}
assert rows==480
report={'benchmark_rows':rows,'matched_workload_order':order_report,'no_edit_zero_allocations':True,'median_10_percent_failures':failures,'results':results}
(lab/'perf-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'rows':rows,'orders':order_report,'ratchet_failures':failures},indent=2))
for language,benches in results.items():
 for name,row in benches.items():print(language,name,json.dumps(row['metrics']))
