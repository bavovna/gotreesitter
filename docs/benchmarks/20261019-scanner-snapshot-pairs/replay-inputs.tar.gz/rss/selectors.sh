#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go run ./cmd/citestplan -stale-run-names -repo-root /candidate > /evidence/selectors.log 2>&1
bash /evidence/run.sh
