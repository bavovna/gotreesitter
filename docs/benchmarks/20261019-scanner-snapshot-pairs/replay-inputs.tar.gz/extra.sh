#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/screen-overlay.json'
cd /reference
go test . -tags gts_parsercorephase0 -run '^TestSnapshotPairFootprintMultiplePagesInPointerOrder$' -count=1 -v -timeout=5m > /evidence/multiple-pages.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test ./internal/parsercorephase0 -run '^TestScannerSnapshotPages' -count=1 -v -timeout=5m > /evidence/core-386.log 2>&1
go test ./internal/parsercorephase0 -race -run '^TestScannerSnapshotPages' -count=1 -v -timeout=5m > /evidence/core-race.log 2>&1
printf 'complete\n' > /evidence/extra-complete.txt
