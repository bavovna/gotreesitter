#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/screen-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /reference
go test ./internal/parsercorephase0 -count=1 -timeout=8m > /evidence/integrated-core-all.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(FreshSnapshotPages|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|CompactYAMLReductionSelectionPreservesSampleWork|CompactExternalScannerCheckpointCopyMemoryBudget|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|AdmissionSwitchCompactMemoryBudgetPeakFootprintBoundedOn(AdversarialWitness|WideGLR))$|^TestFreshSnapshotPages' -count=1 -v -timeout=8m > /evidence/integrated-root.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=go go test . -tags gts_parsercorephase0 -run '^TestV1InvariantGateR4EditSession$' -count=1 -v -timeout=8m > /evidence/integrated-go-invariant.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=yaml go test . -tags gts_parsercorephase0 -run '^TestV1InvariantGateR4EditSession$' -count=1 -v -timeout=8m > /evidence/integrated-yaml-invariant.log 2>&1
GTS_ADMISSION_CANDIDATE=1 go test . -tags gts_parsercorephase0 -run '^TestProgressArenaOwnedYAMLInvariant$' -count=1 -v -timeout=8m > /evidence/integrated-owned-yaml-invariant.log 2>&1
GTS_ADMISSION_CANDIDATE=1 go test . -tags gts_parsercorephase0 -run '^TestStreamedPrefixPublicWorkCensus$' -count=1 -v -timeout=8m > /evidence/integrated-public-work.log 2>&1
cd cgo_harness
go test . -tags gts_parsercorephase0,treesitter_c_parity -run '^TestCompact(YAMLDocumentStreamLockedC|YAMLVersionOwnershipCOracle)$' -count=1 -v -timeout=8m > /evidence/integrated-yaml-c.log 2>&1
printf 'complete\n' > /evidence/integrated-complete.txt
