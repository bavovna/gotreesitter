#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
cd /reference
go test . -tags gts_parsercorephase0 -run '^TestSnapshotShapeCensus$' -count=1 -v -timeout=5m > /evidence/shapes.log 2>&1
