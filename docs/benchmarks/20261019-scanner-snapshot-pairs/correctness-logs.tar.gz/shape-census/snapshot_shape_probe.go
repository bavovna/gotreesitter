package parsercorephase0

type ScannerSnapshotShape struct {Payload,Start,End,Tried int; RecordBytes uint64}
var scannerSnapshotShapes = map[ScannerSnapshotShape]int{}
func recordScannerSnapshotShape(shape ScannerSnapshotShape){scannerSnapshotShapes[shape]++}
func ResetSnapshotShapeCensusForTest(){clear(scannerSnapshotShapes)}
func SnapshotShapeCensusForTest()map[ScannerSnapshotShape]int{return scannerSnapshotShapes}
