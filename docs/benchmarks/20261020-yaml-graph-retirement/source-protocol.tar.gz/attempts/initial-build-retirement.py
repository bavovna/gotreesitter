from pathlib import Path
import subprocess,os,json,hashlib,shutil
p=Path(__file__).resolve().parent;root=p/'candidate-source'
def put(rel,s):
 f=root/rel;t=f.with_name(f.name+'.tmp');t.write_bytes(subprocess.run(['gofmt'],input=s.encode(),stdout=subprocess.PIPE,check=True).stdout);os.replace(t,f)
put('internal/parsercorephase0/publication_graph.go','''package parsercorephase0

import (
 "errors"
 "math"
 "unsafe"
)

var errPublicationGraphSealed = errors.New("parser-core phase zero: graph retired for publication; reset required")
var errPublicationGraphContext = errors.New("parser-core phase zero: publication retirement requires an unchanged completed fresh graph")

type publicationGraphState struct {
 owner *Core
 generation, phase, epoch uint64
 available, sealed bool
}

// RetireFreshGraphForPublication consumes GSS handles from a completed fresh
// run. Syntax, scanner checkpoints, authentication and Work remain live.
// Small graphs retain their buffers. After retirement Reset precedes mutation.
func (c *Core) RetireFreshGraphForPublication(head Head, minimumBytes uint64) (bool,error) {
 if c==nil || c.publicationGraph.sealed || c.schedulerFrame.active || len(c.transactions)!=0 ||
 !c.publicationGraph.available || c.publicationGraph.owner!=c ||
 c.publicationGraph.generation!=c.resetGeneration || c.publicationGraph.phase!=c.classificationPhase ||
 c.publicationGraph.epoch!=c.schedulerFrame.epoch || !c.metadataConstructionAuthenticated || len(c.reusedSubtrees)!=0 {
  return false,errPublicationGraphContext
 }
 if _,err:=c.Stats(head);err!=nil{return false,err}
 var total uint64
 for _,item:=range []struct{capacity int;size uintptr}{
 {cap(c.nodes),unsafe.Sizeof(nodeRecord{})}, {cap(c.links),unsafe.Sizeof(linkRecord{})},
 {cap(c.nodeLineages),unsafe.Sizeof(nodeLineageHot{})}, {cap(c.nodeLineageRecovery),unsafe.Sizeof(nodeLineageRecovery{})},
 {cap(c.nodeLineageRefSets),unsafe.Sizeof(DropCohortRefSet{})}, {cap(c.nodePrecedenceWide),unsafe.Sizeof(int64(0))},
 {cap(c.nodeCheckpoints),unsafe.Sizeof(CheckpointID(0))}, {cap(c.boundaries.slots),unsafe.Sizeof(boundarySlot{})},
 } {
  bytes:=uint64(item.capacity)*uint64(item.size)
  if math.MaxUint64-total<bytes{return false,errors.New("parser-core phase zero: publication graph footprint overflow")}
  total+=bytes
 }
 if total<minimumBytes{return false,nil}
 c.publicationGraph.available=false
 c.publicationGraph.sealed=true
 c.nodes=nil; c.links=nil; c.nodeLineages=nil; c.nodeLineageRecovery=nil; c.nodeLineageRefSets=nil
 c.nodePrecedenceWide=nil; c.nodePrecedenceWideBase=0; c.nodeCheckpoints=nil
 c.boundaries.slots=nil; c.boundaries.count=0; c.boundaryJournal=nil; c.nodeLineageJournal=nil
 c.popScratch=popEnumerationScratch{}
 return true,nil
}
''')
f=root/'internal/parsercorephase0/core.go';s=f.read_text();n='metadataConstructionAuthenticated bool';assert s.count(n)==1;s=s.replace(n,n+'\n publicationGraph publicationGraphState',1)
n='func (c *Core) markInto(mark *checkpoint) {';s=s.replace(n,n+'\n c.publicationGraph.available=false',1)
n='func (c *Core) RunFreshSchedulerSession(fn func(SchedulerTransactionToken) error) (err error) {';s=s.replace(n,n+'\n if c.publicationGraph.sealed {return errPublicationGraphSealed}\n c.publicationGraph.available=false',1)
n='\t\tframe.clearInactive()\n\t\tif err != nil {\n\t\t\t// ResetReleasingRetention';assert s.count(n)==1;s=s.replace(n,'\t\tframe.clearInactive()\n if err==nil {c.publicationGraph=publicationGraphState{owner:c,generation:c.resetGeneration,phase:c.classificationPhase,epoch:frame.epoch,available:true}}\n\t\tif err != nil {\n\t\t\t// ResetReleasingRetention',1)
for n in ['func (c *Core) ApplySchedulerAtomic(fn func(SchedulerTransactionToken) error) (err error) {','func (c *Core) ApplyAtomic(fn func() error) (err error) {']:
 assert s.count(n)==1;s=s.replace(n,n+'\n if c.publicationGraph.sealed {return errPublicationGraphSealed}',1)
n='\tc.nodes = c.nodes[:0]\n\tc.nodePrecedenceWide';assert s.count(n)==1;s=s.replace(n,'\tc.publicationGraph=publicationGraphState{}\n'+n,1);put(str(f.relative_to(root)),s)
f=root/'parsercore_phase0_fresh_full_runner.go';s=f.read_text();n='''		if _, err := compact.Stats(scheduler.acceptedHead); err != nil {
			return nil, err
		}
		_, _, tree, err := checkedNativeSelectedProjection''';assert s.count(n)==1
s=s.replace(n,'''		if _, err := compact.Stats(scheduler.acceptedHead); err != nil {
			return nil, err
		}
 if compact.NodeCount()>=1<<16 {
  if _,err:=compact.RetireFreshGraphForPublication(scheduler.acceptedHead,8<<20);err!=nil{return nil,err}
 }
		_, _, tree, err := checkedNativeSelectedProjection''',1);put(str(f.relative_to(root)),s)
put('internal/parsercorephase0/publication_graph_test.go','''package parsercorephase0

import ("errors"; "testing")

func TestPublicationGraphRetirementPreservesSyntaxAndWork(t *testing.T) {
 c:=newTinyCoreWithLimits(t,Limits{})
 head,err:=c.Seed(1,0);if err!=nil{t.Fatal(err)}
 payload:=appendShallowPayload(t,c,shallowPayloadSpec{symbol:20,startByte:0,endByte:1,childSymbols:[]Symbol{30}})
 c.metadataConstructionAuthenticated=true
 if err:=c.RunFreshSchedulerSession(func(SchedulerTransactionToken)error{return nil});err!=nil{t.Fatal(err)}
 work:=c.Work();subtrees:=c.SubtreeCount();before:=c.FootprintBytes()
 if retired,err:=c.RetireFreshGraphForPublication(head,0);err!=nil||!retired{t.Fatalf("retired=%v err=%v",retired,err)}
 if c.Work()!=work||c.SubtreeCount()!=subtrees||c.FootprintBytes()>=before{t.Fatal("retirement lost syntax/work or retained graph capacity")}
 if _,err:=c.MaterializationView(payload);err!=nil{t.Fatal(err)}
 if _,err:=c.Stats(head);err==nil{t.Fatal("retired head remained valid")}
 if _,err:=c.Seed(1,0);!errors.Is(err,errPublicationGraphSealed){t.Fatal(err)}
 if err:=c.ApplySchedulerAtomic(func(SchedulerTransactionToken)error{return nil});!errors.Is(err,errPublicationGraphSealed){t.Fatal(err)}
 if err:=c.RunFreshSchedulerSession(func(SchedulerTransactionToken)error{return nil});!errors.Is(err,errPublicationGraphSealed){t.Fatal(err)}
 if err:=c.Reset();err!=nil{t.Fatal(err)}
 if _,err:=c.Seed(1,0);err!=nil{t.Fatal("reset did not unseal",err)}
}
func TestPublicationGraphRetirementRejectsWrongLifetime(t *testing.T) {
 c:=newTinyCoreWithLimits(t,Limits{})
 head,err:=c.Seed(1,0);if err!=nil{t.Fatal(err)}
 c.metadataConstructionAuthenticated=true
 if _,err:=c.RetireFreshGraphForPublication(head,0);!errors.Is(err,errPublicationGraphContext){t.Fatal(err)}
 if err:=c.RunFreshSchedulerSession(func(SchedulerTransactionToken)error{
  if _,err:=c.RetireFreshGraphForPublication(head,0);!errors.Is(err,errPublicationGraphContext){t.Fatal(err)}
  return nil
 });err!=nil{t.Fatal(err)}
 if retired,err:=c.RetireFreshGraphForPublication(head,^uint64(0));err!=nil||retired{t.Fatal(retired,err)}
 if err:=c.ApplyAtomic(func()error{return nil});err!=nil{t.Fatal(err)}
 if _,err:=c.RetireFreshGraphForPublication(head,0);!errors.Is(err,errPublicationGraphContext){t.Fatal(err)}
}
''')
parent=p.parent/'20261020-yaml-paged-publication'
for f in parent.iterdir():
 if f.is_file() and (f.suffix in ['.sh','.py'] or f.name.endswith('test.go.txt') or f.name in ['overlay.json','qualification-overlay.json','census-overlay.json','shared_bench_test.go','attempt_census_test.go','counter_main.go.txt','languages.txt','reference-ledger.json','reference-owned-yaml-ledger.json','reference-canonical-work.json','production-strict-census.json']):shutil.copyfile(f,p/f.name)
pins={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*.go')};assert len(pins)==3535
(p/'candidate-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(p/'source-reference.json').write_text(json.dumps(dict(parent=str(parent),wide_origin_parent=str(p.parent/'20261020-go-wide-precedence-origin'),candidate_go_files=len(pins),purpose='Retire completed fresh GSS before large clean native publication; no GC/pool/budget overrides',runtime_promoted=False,held_Go_correctness_repair_included=False),indent=2)+'\n')
print('prototype frozen; source pins',len(pins))
