#!/usr/bin/env bash
set -euo pipefail
for role in baseline candidate; do
 if [[ "$role" = baseline ]]; then
  cd /reference/cgo_harness
  go test -c -tags gts_parsercorephase0,treesitter_c_parity -o /evidence/out/baseline-cgo.test . > /evidence/out/baseline-cgo-build.log 2>&1
  binary=/evidence/out/baseline-cgo.test
 else
  cd /candidate/cgo_harness
  binary=/evidence/out/candidate/cgo.test
 fi
 status=0
 "$binary" -test.run '^(TestGoTokenTurnExpandedLockedCProbe|TestGoGenericCallFrontierLockedCProbe)$' -test.count=1 -test.v -test.timeout=8m > "/evidence/out/$role-expanded-go-c.log" 2>&1 || status=$?
 printf '%s\n' "$status" > "/evidence/out/$role-expanded-go-c-exit.txt"
done
python3 /evidence/audit-go-c.py
