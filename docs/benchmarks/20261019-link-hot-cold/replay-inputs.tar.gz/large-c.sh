#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/qualify-complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/large-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /candidate/cgo_harness
go test . -tags gts_parsercorephase0,treesitter_c_parity -run '^TestCompactLineageLargeGoLockedC$' -count=1 -v -timeout=8m > /evidence/large-go-c.log 2>&1
printf 'complete\n' > /evidence/large-c-complete.txt
