#!/usr/bin/env bash
set -euo pipefail
lab=/home/draco/.local/state/gotreesitter-evidence/20261019-link-hot-cold-integration
bash "$lab/run-qualification.sh"
bash "$lab/run-rss-after-qualification.sh"
bash "$lab/run-perf-after-rss.sh"
python3 "$lab/analyze-perf.py" > "$lab/perf-analysis.log"
benchstat "$lab/perf/go-before.txt" "$lab/perf/go-after.txt" > "$lab/go-benchstat.txt"
benchstat "$lab/perf/yaml-before.txt" "$lab/perf/yaml-after.txt" > "$lab/yaml-benchstat.txt"
python3 "$lab/verify-source.py" > "$lab/final-source-verification.log"
