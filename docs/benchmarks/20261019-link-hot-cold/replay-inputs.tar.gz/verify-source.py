from pathlib import Path
import hashlib,json,sys
lab=Path(__file__).resolve().parent
source=Path(sys.argv[1]) if len(sys.argv)>1 else lab/'candidate-source'
pins=json.loads((lab/'candidate-source-pins.json').read_text())
for name,sha in pins.items():
 assert hashlib.sha256((source/name).read_bytes()).hexdigest()==sha,name
print('Verified',len(pins),'candidate Go hashes')
