#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /candidate
go test . -run '^TestCertifiedCStackLinkPayloadEquivalence$' -count=1 -v -timeout=8m > /evidence/root.log 2>&1
go test ./grammars/runtime -count=1 -v -timeout=8m > /evidence/runtime-profiles.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/counter ./cmd/perfcounterledger > /evidence/counter-build.log 2>&1
/evidence/counter --write --output /evidence/ledger.json > /evidence/ledger.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/counter --langs yaml > /evidence/owned-yaml-ledger.json 2> /evidence/owned-yaml-ledger.log
python3 - <<'AUDIT'
from pathlib import Path
import json
p=Path('/evidence');total=0
for a,b in [('reference-ledger.json','ledger.json'),('reference-owned-yaml-ledger.json','owned-yaml-ledger.json')]:
 x=json.loads((p/a).read_text());y=json.loads((p/b).read_text());assert x==y,(a,b);total+=len(y['rows'])
assert total==414
(p/'counter-gate.json').write_text(json.dumps({'complete_rows_exact':414})+'\n')
AUDIT
go test -c ./grammars -o /evidence/grammars.test > /evidence/grammars-build.log 2>&1
for grammar in typescript tsx; do
 /evidence/grammars.test -test.run "^TestTypeScriptAsyncGenericArrow$/^${grammar}$" -test.count=1 -test.v -test.timeout=8m > "/evidence/grammar-$grammar.log" 2>&1
done
cd /candidate/cgo_harness
go test -c -tags gts_parsercorephase0,treesitter_c_parity -o /evidence/cgo.test . > /evidence/cgo-build.log 2>&1
for grammar in typescript tsx; do
 /evidence/cgo.test -test.run "^TestTypeScriptAsyncGenericArrowLockedC$/^${grammar}$" -test.count=1 -test.v -test.timeout=8m > "/evidence/c-$grammar.log" 2>&1
done
printf 'complete\n' > /evidence/focused-complete.txt
