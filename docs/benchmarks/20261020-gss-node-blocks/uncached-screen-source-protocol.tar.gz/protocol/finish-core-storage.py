from pathlib import Path
import subprocess, os

root=Path(__file__).resolve().parent/'candidate-source/internal/parsercorephase0'
def put(name,text):
 p=root/name;tmp=p.with_name(p.name+'.tmp')
 tmp.write_bytes(subprocess.run(['gofmt'],input=text.encode(),stdout=subprocess.PIPE,check=True).stdout)
 os.replace(tmp,p)

s=(root/'core.go').read_text()
s=s.replace('c.nodes = append(c.nodes, r.record())','if id,ok := c.nodes.Append(r.record(),c.limits.MaxNodes); !ok || id!=next {\n return 0,errors.New("parser-core phase zero: node arena publication failed")\n }')
s=s.replace('c.truncateNodePathCounts(mark.nodes)\n\tc.nodes.Truncate(mark.nodes)','if !c.nodes.Truncate(mark.nodes) {panic("parser-core phase zero: checkpoint crosses retired node block")}\n c.truncateNodePathCounts(mark.nodes)')
s=s.replace('c.nodes.Truncate(c.nodes.Len() - 1)','if !c.nodes.Truncate(c.nodes.Len()-1) {panic("parser-core phase zero: seed rollback crosses retired node block")}')
old='''if id == 0 || uint64(id) > uint64(c.nodes.Len()) {
		return nil, fmt.Errorf("parser-core phase zero: invalid node id %d", id)
	}
	return c.nodes.At(int(id - 1)), nil'''
new='''if id!=0 && uint64(id)<=uint64(c.nodes.Len()) {
  if node:=c.nodes.At(int(id-1));node!=nil {return node,nil}
 }
 return nil,fmt.Errorf("parser-core phase zero: invalid node id %d",id)'''
assert old in s;s=s.replace(old,new)
put('core.go',s)

s=(root/'node_record_blocks.go').read_text()
s=s.replace('// only backing storage is recycled. Core does not use this prototype yet.','// only backing storage is recycled. Collection remains disabled in Core.')
needle='func (s *nodeRecordBlocks) Reset() {\n'
assert s.count(needle)==1
s=s.replace(needle,needle+''' if s.retiredThrough==0 {
  s.first=s.first[:0]
  for i:=range s.blocks {s.blocks[i].records=s.blocks[i].records[:0]}
  s.length=0
  return
 }
''')
put('node_record_blocks.go',s)

s=(root/'storage_bytes.go').read_text().replace('uint64(c.nodes.Capacity())*coreNodeRecordBytes','c.nodes.FootprintBytes()')
put('storage_bytes.go',s)

s=(root/'arena_reserve.go').read_text()
s=s.replace('c.nodes = reserveArena(c.nodes, nodes)','c.nodes.Grow(nodes)').replace('c.nodes = growArena(c.nodes, nodes)','c.nodes.Grow(nodes)')
old='''if maxBytes > 0 && total > maxBytes {
		nodes = scaleReserveCount(nodes, maxBytes, total)
		links = scaleReserveCount(links, maxBytes, total)
		subtrees = scaleReserveCount(subtrees, maxBytes, total)
		children = scaleReserveCount(children, maxBytes, total)
	}'''
assert s.count(old)==2
s=s.replace(old,'nodes,links,subtrees,children = boundedRecordReserveCounts(nodes,links,subtrees,children,maxBytes)')
old='''if maxBytes > 0 && total > maxBytes {
		return reserveTotalBytes(
			scaleReserveCount(nodes, maxBytes, total),
			scaleReserveCount(links, maxBytes, total),
			scaleReserveCount(subtrees, maxBytes, total),
			scaleReserveCount(children, maxBytes, total),
		)
	}
	return total'''
assert old in s
s=s.replace(old,'nodes,links,subtrees,children=boundedRecordReserveCounts(nodes,links,subtrees,children,maxBytes)\n return reserveTotalBytes(nodes,links,subtrees,children)')
# The pure estimator no longer needs its old unscaled total variable.
start=s.index('func (c *Core) ReserveRecordArenaBytes(');end=s.index('\n// reserveTotalBytes',start)
part=s[start:end].replace('\n\ttotal := reserveTotalBytes(nodes, links, subtrees, children)','')
s=s[:start]+part+s[end:]
s=s.replace('return uint64(nodes)*coreNodeRecordBytes +','return nodeRecordBlockMetadataBytes(nodes)+uint64(nodes)*coreNodeRecordBytes +')
s+='''
// Deduct the unscaled node-table cost before scaling record counts. The
// scaled table cannot be larger, so rounding never exceeds the byte ceiling.
func boundedRecordReserveCounts(nodes,links,subtrees,children int,maxBytes uint64)(int,int,int,int) {
 total:=reserveTotalBytes(nodes,links,subtrees,children)
 if maxBytes==0 || total<=maxBytes {return nodes,links,subtrees,children}
 metadata:=nodeRecordBlockMetadataBytes(nodes)
 allowed:=uint64(0);if maxBytes>metadata {allowed=maxBytes-metadata}
 records:=total-metadata
 return scaleReserveCount(nodes,allowed,records),scaleReserveCount(links,allowed,records),scaleReserveCount(subtrees,allowed,records),scaleReserveCount(children,allowed,records)
}
'''
put('arena_reserve.go',s)

s=(root/'arena_projection.go').read_text()
s=s.replace('delta(nodes, c.nodes.Capacity(), coreNodeRecordBytes)','c.nodes.GrowthFootprintBytes(nodes)').replace('c.nodes = growArena(c.nodes, nodes)','c.nodes.Grow(nodes)')
put('arena_projection.go',s)

s=(root/'eof_recovery_shadow.go').read_text()
s=s.replace('{live.nodes.Len(), coreNodeRecordBytes}','{1, live.nodes.CloneActiveFootprintBytes()}')
s=s.replace('shadow.nodes = cloneDiagnosticSlice(live.nodes, 0)','shadow.nodes = live.nodes.CloneActive()')
s=s.replace('equalDiagnosticSlice(live.nodes, shadow.nodes)','equalDiagnosticNodeBlocks(&live.nodes, &shadow.nodes)')
s=s.replace('disjointDiagnosticSlice(live.nodes, shadow.nodes)','disjointDiagnosticNodeBlocks(&live.nodes, &shadow.nodes)')
put('eof_recovery_shadow.go',s)
print('core append, rollback, reset, capacity gauges, reserves, projection, and EOF clone adapted')
