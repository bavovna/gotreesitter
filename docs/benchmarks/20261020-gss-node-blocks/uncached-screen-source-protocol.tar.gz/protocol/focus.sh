#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -run '^Test(NodeRecordBlocks|RecordArena|ReserveRecord|GrowRecord|ProjectRecord)' -count=1 -v -timeout=8m > /evidence/core-focus.log 2>&1
printf 'complete\n' > /evidence/focus-complete.txt
