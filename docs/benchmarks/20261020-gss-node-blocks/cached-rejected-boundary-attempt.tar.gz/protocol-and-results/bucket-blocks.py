from pathlib import Path
import gzip,hashlib,io,json,tarfile
lab=Path(__file__).resolve().parent
repo=Path('/home/draco/.codex/worktrees/gss-node-block-storage/gotreesitter')
out=repo/'docs/benchmarks/20261020-gss-node-blocks'
reference=lab.parent/'20261020-go-node16-path-counts/candidate-source'
variants=[('uncached-screen',lab.parent/'20261020-go-gss-block-core',3534),('cached-candidate',lab,3535)]
out.mkdir(parents=True,exist_ok=True)
archives=[];manifest={}
for label,p,count in variants:
 read=lambda n:json.loads((p/n).read_text())
 assert (p/'perf/complete.txt').read_text().strip()=='complete'
 assert (p/'final-core-modes-complete.txt').read_text().strip()=='complete'
 assert read('full-counter-gate.json')['passed']
 assert read('rss/rss-matched/audit.json')['candidate_safety_pass']
 assert not read('perf-summary.json')['median_10_percent_failures']
 bp,cp=read('reference-source-pins.json'),read('candidate-source-pins.json')
 assert len(bp)==3527 and len(cp)==count
 for root,pins in [(reference,bp),(p/'candidate-source',cp)]:
  for rel,want in pins.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==want,rel
 protocol={};qualification={};measurements={}
 def add(d,rel,file):d[rel]=file.read_bytes()
 for rel in cp:
  if bp.get(rel)!=cp[rel]:add(protocol,'candidate-overlay/'+rel,p/'candidate-source'/rel)
 protocol_names={'languages.txt','reference-source-pins.json','candidate-source-pins.json','reference-ledger.json','reference-owned-yaml-ledger.json','reference-canonical-work.json','production-strict-census.json','qualification-overlay.json','large-overlay.json','pre-test-adapter-pins.json','qualification-preparation.txt'}
 measurement_names={'perf-summary.json','go-benchstat.txt','yaml-benchstat.txt','post-perf-pins.json','qualified-screen-summary.json','cached-candidate-summary.json'}
 for f in p.iterdir():
  if not f.is_file():continue
  if f.suffix in ['.sh','.py'] or f.name.endswith('.go.txt') or f.name in protocol_names:
   add(protocol,'protocol/'+f.name,f)
  if (f.suffix=='.log' and not f.name.startswith('buckley')) or f.name.endswith('complete.txt') or f.name in ['full-counter-gate.json','final-core-mode-audit.json','test-adapter-source-audit.json','prequalification-pin-audit.json']:
   add(qualification,f.name,f)
  if f.name in measurement_names:add(measurements,f.name,f)
 for f in (p/'out').rglob('*'):
  if f.is_file() and f.suffix in ['.log','.json','.txt']:add(qualification,str(f.relative_to(p)),f)
 for name in ['rss','capacity']:
  for f in (p/name).iterdir():
   if f.is_file() and (f.suffix in ['.sh','.py','.json'] or f.name.endswith('.go.txt') or f.name=='go-source.txt'):
    add(protocol,'protocol/'+name+'/'+f.name,f)
 for name in ['rss','capacity','perf']:
  for f in (p/name).rglob('*'):
   if f.is_file() and f.suffix in ['.log','.rss','.txt','.json']:
    if f.name.endswith('.go.txt') or f.name in ['go-source.txt','overlay.json']:continue
    add(measurements,str(f.relative_to(p)),f)
 for kind,files in [('source-protocol',protocol),('qualification',qualification),('measurements',measurements)]:
  name=label+'-'+kind+'.tar.gz'
  rows={rel:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for rel,data in sorted(files.items())}
  with (out/name).open('wb') as raw:
   with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as z:
    with tarfile.open(fileobj=z,mode='w') as t:
     for rel,data in sorted(files.items()):
      info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
  with tarfile.open(out/name) as t:
   assert len(t.getmembers())==len(rows)
   for member in t:
    data=t.extractfile(member).read();row=rows[member.name]
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],member.name
  manifest[name]=rows;data=(out/name).read_bytes()
  archives.append(dict(name=name,bytes=len(data),members=len(rows),sha256=hashlib.sha256(data).hexdigest()))
(out/'archive-members.json').write_text(json.dumps(manifest,indent=2)+'\n')
report=dict(archives=archives,reference_Go_commit='2264c231a57bb1f22c93e4929b0a5e73ed6441e5',equivalent_main_Go_commit='c9770115d6bc23873c7a452ea5753d12ff2c5d1b',reference_go_files=3527,variants=[dict(name=n,go_files=c) for n,_,c in variants])
(out/'archives.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
