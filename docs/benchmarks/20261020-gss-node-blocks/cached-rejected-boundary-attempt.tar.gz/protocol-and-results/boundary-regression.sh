#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/boundary-regression-overlay.json'
cd /candidate
set +e
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^TestNodeRecordBlocksMaximumLimitStartsSuffix$' -count=1 -v > /evidence/boundary-386-max-limit-before.log 2>&1
a=$?
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^TestNodeRecordBlocksRetirementRejectsMaximumInt32Tail$' -count=1 -v > /evidence/boundary-386-tail-before.log 2>&1
b=$?
set -e
test "$a" -ne 0
test "$b" -ne 0
printf 'both expected regressions reproduced\n' > /evidence/boundary-regression-complete.txt
