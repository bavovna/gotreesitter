from pathlib import Path
import os, subprocess
root=Path(__file__).resolve().parent/'candidate-source/internal/parsercorephase0'
def put(name,text):
 p=root/name;tmp=p.with_name(p.name+'.tmp');tmp.write_bytes(subprocess.run(['gofmt'],input=text.encode(),stdout=subprocess.PIPE,check=True).stdout);os.replace(tmp,p)

s=(root/'node_record_blocks.go').read_text()
s=s.replace('\tretiredThrough int\n','\tretiredThrough int\n\tslotCapacity int\n\tbufferBytes uint64\n',1)
s=s.replace('\t\ts.first = append(s.first, record)','\t\toldCapacity:=cap(s.first)\n\t\ts.first = append(s.first, record)',1)
s=s.replace('\t\ts.length++\n\t\treturn NodeID(s.length), true','\t\ts.length++\n\t\tif cap(s.first)!=oldCapacity {s.refreshGeometry()}\n\t\treturn NodeID(s.length), true',1)
s=s.replace('\tif block == len(s.blocks) {','\toldMetadataCapacity:=cap(s.blocks)\n\tif block == len(s.blocks) {',1)
s=s.replace('\trecords := s.blocks[block].records\n\tif offset >= cap(records) {','\trecords := s.blocks[block].records\n\tchangedCapacity:=offset>=cap(records)\n\tif changedCapacity {',1)
s=s.replace('\ts.blocks[block].records = records\n\ts.length++','\ts.blocks[block].records = records\n\tif changedCapacity || cap(s.blocks)!=oldMetadataCapacity {s.refreshGeometry()}\n\ts.length++',1)
s=s.replace('\ts.retiredThrough = max(s.retiredThrough, end)\n\treturn true','\ts.retiredThrough = max(s.retiredThrough, end)\n\ts.refreshGeometry()\n\treturn true',1)
s=s.replace('\treturn clone\n','\tclone.refreshGeometry()\n\treturn clone\n',1)
s=s.replace('\ts.retiredThrough = 0\n}', '\ts.retiredThrough = 0\n\ts.refreshGeometry()\n}',1)
start=s.index('func (s *nodeRecordBlocks) FootprintBytes() uint64 {')
s=s[:start]+'''// Geometry is fixed between backing-buffer mutations. Budget polling reads
// these cached scalars rather than scanning the arena's block table.
func (s *nodeRecordBlocks) FootprintBytes() uint64 {return s.bufferBytes}

func (s *nodeRecordBlocks) refreshGeometry() {
 slots:=cap(s.first)
 total:=uint64(slots)*uint64(unsafe.Sizeof(nodeRecord{}))+
  uint64(cap(s.blocks))*uint64(unsafe.Sizeof(nodeRecordBlock{}))+
  uint64(cap(s.spare))*uint64(unsafe.Sizeof([]nodeRecord{}))
 for _,block:=range s.blocks {
  slots+=cap(block.records)
  total+=uint64(cap(block.records))*uint64(unsafe.Sizeof(nodeRecord{}))
 }
 for _,records:=range s.spare {total+=uint64(cap(records))*uint64(unsafe.Sizeof(nodeRecord{}))}
 s.slotCapacity,s.bufferBytes=slots,total
}
'''
put('node_record_blocks.go',s)

s=(root/'node_record_block_growth.go').read_text()
a=s.index('func (s *nodeRecordBlocks) Capacity() int {');b=s.index('\nfunc nodeRecordBlockMetadataBytes',a)
s=s[:a]+'func (s *nodeRecordBlocks) Capacity() int {return s.slotCapacity}\n'+s[b:]
s=s.replace('\tif want <= cap(s.first) {\n\t\treturn\n\t}', '\tif want <= cap(s.first) {\n\t\ts.refreshGeometry()\n\t\treturn\n\t}',1)
s=s.rstrip()[:-1]+'\ts.refreshGeometry()\n}\n'
put('node_record_block_growth.go',s)

s=(root/'node_record_block_test_helpers_test.go').read_text()
s=s.replace('return nodeRecordBlocks{first: records, length: len(records)}','arena:=nodeRecordBlocks{first: records, length: len(records)}\n arena.refreshGeometry()\n return arena')
put('node_record_block_test_helpers_test.go',s)

s=(root/'node_record_blocks_test.go').read_text()
s=s.replace('\ts.length = 8\n','\ts.length = 8\n\ts.refreshGeometry()\n',1)
needle='s := nodeRecordBlocks{first: make([]nodeRecord, nodeRecordBlockSize), length: nodeRecordBlockSize}\n'
assert s.count(needle)==1;s=s.replace(needle,needle+'\ts.refreshGeometry()\n',1)
put('node_record_blocks_test.go',s)
print('cached capacity/footprint; geometry refreshed on allocation, reuse, retirement, reset and clone')
