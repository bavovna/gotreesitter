#!/usr/bin/env bash
set -euo pipefail
bash /evidence/capacity/run-root.sh
bash /evidence/perf.sh
