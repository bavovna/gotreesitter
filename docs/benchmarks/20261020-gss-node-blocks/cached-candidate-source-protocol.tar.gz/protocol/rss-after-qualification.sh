#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import json
p=Path('/lab')
for n in ['full-counter-gate.json','final-core-mode-audit.json']:
 assert json.loads((p/n).read_text())['passed'],n
assert (p/'final-core-modes-complete.txt').read_text().strip()=='complete'
PY
bash /evidence/run.sh
