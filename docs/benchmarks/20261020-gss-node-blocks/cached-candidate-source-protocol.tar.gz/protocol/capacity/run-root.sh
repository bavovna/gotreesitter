#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/capacity/overlay.json'
test -f /lab/full-counter-gate.json
for role in baseline candidate; do
 if [[ "$role" = baseline ]];then cd /reference;else cd /candidate;fi
 go test -c -tags gts_parsercorephase0 -o "/evidence/capacity/$role.test" . > "/evidence/capacity/$role-build.log" 2>&1
 GTS_STORAGE_CASE=go "/evidence/capacity/$role.test" -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=8m > "/evidence/capacity/$role-go.log" 2>&1
done
printf 'complete\n' > /evidence/capacity/complete.txt
