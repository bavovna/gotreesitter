#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import json
p=Path('/evidence')
for n in ['full-counter-gate.json','final-core-mode-audit.json']:
 assert json.loads((p/n).read_text())['passed'],n
assert (p/'rss/complete.txt').read_text().strip()=='complete'
assert json.loads((p/'rss/rss-matched/audit.json').read_text())['candidate_safety_pass']
PY
bash /evidence/capacity-and-perf.sh
