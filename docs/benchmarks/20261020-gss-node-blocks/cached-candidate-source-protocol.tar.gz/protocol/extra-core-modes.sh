#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/qualify-complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-phase0-shadow.log 2>&1
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_parsercorephase0a,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-phase0a-shadow.log 2>&1
go test ./internal/parsercorephase0 -tags gts_parsercorephase0_selectedstore_onepass,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-onepass-shadow.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
printf 'complete\n' > /evidence/final-core-modes-complete.txt
