#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/core-all-complete.txt
cp /evidence/core-shadow.log /evidence/core-focused.log
printf 'complete\n' > /evidence/focused-complete.txt
bash /evidence/qualify.sh
bash /evidence/extra-core-modes.sh
python3 /evidence/audit-completed.py > /evidence/final-full-audit.log
python3 /evidence/audit-core-modes.py > /evidence/final-mode-audit.log
