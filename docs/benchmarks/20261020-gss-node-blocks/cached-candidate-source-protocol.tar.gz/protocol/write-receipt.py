from pathlib import Path
import json,re
p=Path(__file__).resolve().parent
repo=Path('/home/draco/.codex/worktrees/gss-node-block-storage/gotreesitter')
read=lambda n:json.loads((p/n).read_text())
perf=read('perf-summary.json');rss=read('rss/rss-matched/audit.json')
assert perf['benchmark_rows']==480 and not perf['median_10_percent_failures']
assert read('full-counter-gate.json')['passed'] and read('final-core-mode-audit.json')['passed'] and rss['candidate_safety_pass']
ps={}
for lang in ['go','yaml']:
 section=None
 for line in (p/(lang+'-benchstat.txt')).read_text().splitlines():
  if '│' in line:section=next((u for u in ['sec/op','B/op','allocs/op'] if u in line),None)
  m=re.match(r'CompactThroughput(?:Go|YAML)/(\S+).*\(p=([0-9.]+) n=20\)',line)
  if m and section:ps[(lang,m[1],section)]=float(m[2])
assert len(ps)==36
pv=lambda x:'<.001' if x==0 else f'{x:.3f}'
num=lambda x:f'{x:,.0f}' if x==int(x) else f'{x:,.1f}'
large=perf['results']['go']['BenchmarkCompactThroughputGo/fresh_one_mib']['metrics']
lr=perf['results']['go']['BenchmarkCompactThroughputGo/grammargen_lr']['metrics']['ns/op']
maximum=max(x['rss_bytes_per_source_byte'] for x in rss['initial']+rss['matched'] if x['role']=='candidate')
ratio=rss['candidate_baseline_median_ratios']
lead=f"""Blocked graph-node storage reduces allocated bytes on fresh one-MiB Go **{num(large['B/op']['before'])}→{num(large['B/op']['after'])} B/op ({large['B/op']['change_percent']:+.2f}%, p{pv(ps['go','fresh_one_mib','B/op']) if ps['go','fresh_one_mib','B/op']==0 else '='+pv(ps['go','fresh_one_mib','B/op'])})**. The measured trade is **{lr['change_percent']:+.2f}% time on grammargen/lr.go (p={pv(ps['go','grammargen_lr','sec/op'])})**. All 414 ledger rows and four canonical Go work/tree vectors remain exact. This is a memory-allocation improvement; compact graduation and a general throughput improvement remain unproven.\n\n"""
counters="""| Counter | Before→after |
| --- | ---: |
| Complete ordinary and owned ledger rows | 414→414, exact |
| Canonical Go tree/work vectors | 4→4, exact |
| Go R4 full nodes / tokens | 1,251→1,251 / 589→589 |
| Go R4 first-edit reused bytes / splices | 1,784→1,784 / 266→266 |
| Owned YAML candidate full / first-edit nodes | 484→484 / 484→484 |
| One-MiB Go public constructions / tokens | 903,086→903,086 / 425,742→425,742 |
\n"""
validation="""All 206 × 72-step invariant sessions, explicit owned YAML, 618 exact language-specific C fixture checks, and 204 strict corpus rows pass their comparison gates. The 45 known strict legacy failures remain. All 306 expanded Go outcomes and 300 routes remain exact, retaining 39 known failures and 90 compact / 210 fallback routes. The actual one-MiB Go C test runs before timing and preserves tree digest `1464b53d73dd7d3ad9ff2b7e064235a4a68442ec7e1379d4c2c263fc6a9eef6c`. Large YAML C tests pass.\n\nDefault, shadow, phase-zero, phase-zero-A and one-pass Core suites pass with 584 / 595 / 619 / 717 / 595 named top-level tests. Native, 386, scoped race, budget/pool, layout and API guards pass. Both new 32-bit boundary regressions fail on the rejected prototype and pass on the final source, including race and 386 runs. All 3,535 candidate Go hashes remain exact.\n\n"""
architecture="""Small node arenas keep a contiguous prefix. Larger ones use 65,536-record suffix blocks, so growth copies at most a partial block. Logical one-based NodeIDs, records, limits, path-count widths and rollback behavior remain intact. Reset retains reusable buffers; detached EOF snapshots copy active records and preserve the ID map. Footprint and capacity gauges read cached scalars, refreshed when backing storage changes. Budgets charge retained buffers and full pointer-table capacity.\n\nThe paired capacity probe keeps 1,032,095 graph nodes and 16,777,216 record-capacity bytes. Block metadata adds 360 bytes: backing capacity moves 119,918,492→119,918,852. The fixed Core header grows 4,240→4,320 bytes; this is reported separately because the existing footprint contract measures backing buffers. No production code calls block retirement. Reclamation still requires an owner proof.\n\n"""
table='| Case | Time change | p | B/op change | Objects before→after |\n| --- | ---: | ---: | ---: | ---: |\n'
for lang,benches in perf['results'].items():
 for name,row in sorted(benches.items()):
  case=name.split('/',1)[1];m=row['metrics']
  table+=f"| {lang}/{case} | {m['ns/op']['change_percent']:+.3f}% | {pv(ps[lang,case,'sec/op'])} | {m['B/op']['change_percent']:+.3f}% | {num(m['allocs/op']['before'])}→{num(m['allocs/op']['after'])} |\n"
objects=f"Go one-MiB object medians move {num(large['allocs/op']['before'])}→{num(large['allocs/op']['after'])} ({large['allocs/op']['change_percent']:+.2f}%, p={pv(ps['go','fresh_one_mib','allocs/op'])}); that comparison is inconclusive. No-edit samples allocate zero bytes and objects. A nanosecond-scale no-edit timing change does not establish a general parser speedup. All directional changes, including the grammargen regression, are retained above.\n\n"
measure=f"""Twenty alternating matched pairs per language use GOMAXPROCS=1, count 1/process, 750 ms, benchmem, normal pools, CPU 6 and serialized six-GiB Docker. The repository randomized runner uses Go seeds 46001–46020 and YAML 45901–45920. All 480 rows, paired workload orders, route/work metrics and median ratchets pass.\n\nAll 126 RSS processes pass, retaining all six initial and 120 matched processes. Candidate/baseline median ratios are {ratio['go']:.6f} Go / {ratio['yaml_ordinary']:.6f} ordinary YAML / {ratio['yaml_owned']:.6f} owned YAML. Maximum candidate RSS is {maximum:.3f} bytes/source byte, below 400. RSS seeds are 45801–45820. These are safety results, not a causal RSS-reduction claim.\n\n"""
attempts="""The earlier uncached arena screen passed its original gates and reduced Go allocated bytes by 6.84%, but its budget gauges scanned block tables. The first cached prototype was stopped after a new 386 audit reproduced a maximum-width limit conversion panic and mistaken append-tail retirement. The final source clamps in uint64 before converting capacity to int and tests the remaining tail span without overflowing an end offset. Both rejected sources, partial results, expected failures and the uncached measurements remain archived. The final comparison uses the node16 main baseline directly; it is not an uncached-versus-cached timing comparison.\n\nOrdinary YAML keeps its fallback route. The pending Go correctness exception, language allowlists, production ledger pins and graduation settings remain unchanged. The [replay bundle](benchmarks/20261020-gss-node-blocks/README.md) contains exact overlays, protocols, source hashes, all raw results and every archive-member hash.\n"""
objects+='Ordinary YAML R4 / 8 KiB time medians move −2.11% / −3.01%, while legacy controls also move −1.67% / −2.71%. Those control shifts prevent attributing the observed YAML timing changes to the Core storage change.\n\n'
receipt='# Blocked graph-node storage\n\n'+lead+architecture+validation+counters+measure+table+'\n'+objects+attempts
(repo/'docs/compact-gss-node-block-receipt-20261020.md').write_text(receipt)
a=json.loads((repo/'docs/benchmarks/20261020-gss-node-blocks/archives.json').read_text())
count=sum(x['members'] for x in a['archives'])
readme=f"""# Blocked graph-node storage evidence

The [receipt](../../compact-gss-node-block-receipt-20261020.md) records results and the measured grammargen time regression. Reference Go commit `2264c231a57bb1f22c93e4929b0a5e73ed6441e5` and main `c9770115d6bc23873c7a452ea5753d12ff2c5d1b` have identical 3,527-file Go source. The final candidate has 3,535 Go files. No ordinary YAML ownership or Go correctness-exception repair is included.

`archives.json` pins seven archive hashes, sizes and member counts. `archive-members.json` pins every member; all {count:,} members were reopened and verified by size and SHA-256. Binaries and caches are excluded.

- `cached-candidate-source-protocol.tar.gz`, `cached-candidate-qualification.tar.gz` and `cached-candidate-measurements.tar.gz` contain the final overlay, executed protocols, complete qualification and matched measurements.
- The three `uncached-screen-*` archives retain the earlier measured screen. Its original standard gates passed, but the later boundary audit exposed 386 defects shared with the rejected cached prototype. It is held and is not the promoted source.
- `cached-rejected-boundary-attempt.tar.gz` retains the exact rejected source, its completed unit/invariant/ledger checks, interrupted qualification and both expected 386 failures. It has no completed C/RSS/timing claim.

For a fresh final-source replay, check out main `c9770115d6bc23873c7a452ea5753d12ff2c5d1b`, verify all reference source hashes, copy that checkout, apply `candidate-overlay/`, then verify all candidate hashes. Extract `protocol/` into a fresh results directory. Mount sources read-only at `/reference` and `/candidate`, results/protocol at `/evidence`, and use Go 1.25.14 image `sha256:187907888b4bdc6f326c87b045718339e5f665baceb27db6b74633ca41e996df`, the locked C cache, both Docker locks, six-GiB memory, CPU 6 and GOMAXPROCS=1.

Run `core-all.sh`, then `qualify-and-audit.sh`. This reuses the already completed default/shadow Core logs and runs the remaining build modes, 206 separate edit sessions, 618 named C fixtures, strict/expanded C controls, actual large-Go C witness, race/386 and layout/API guards. Empty test runs are rejected. The unchanged known C failures remain explicit.

For RSS, mount the protocol root at `/lab` and its `rss/` directory at `/evidence`, then run `/lab/rss-after-qualification.sh`. It retains all 126 processes and stops on a ceiling or median-ratchet failure. For paired capacity and timing, mount the protocol root at both `/lab` and `/evidence` again and run `capacity-perf-after-rss.sh`. Go seeds are 46001–46020, YAML 45901–45920, RSS 45801–45820. Normal pools, memory and stack settings stay in force. Run `analyze-perf.py`, compare both complete language files with benchstat, and verify all source hashes again.

The original final lab is `/home/draco/.local/state/gotreesitter-evidence/20261020-go-gss-block-cached-safe`. Archived scripts retain their original paths; adjust only mount/output locations for a fresh replay. `bucket-blocks.py` verifies and packs the evidence; its working-checkout path can be changed for replay.
"""
(repo/'docs/benchmarks/20261020-gss-node-blocks/README.md').write_text(readme)
context='Title: optimize(gss): avoid whole-arena node copies during growth\n\n'+lead+architecture+counters+validation+measure+objects+'Full directional timing and allocation table: docs/compact-gss-node-block-receipt-20261020.md. Exact evidence: docs/benchmarks/20261020-gss-node-blocks/README.md.\n\nRelated: #1294, #1313, #1319. Graduation remains open.\n'
(p/'pr-context.md').write_text(context)
print('Receipt, replay README and Buckley PR context written')
