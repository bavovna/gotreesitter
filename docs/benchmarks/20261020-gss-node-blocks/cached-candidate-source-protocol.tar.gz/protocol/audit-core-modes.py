from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
expected={"core-default.log":584,"core-shadow.log":595,"core-phase0-shadow.log":619,"core-phase0a-shadow.log":717,"core-onepass-shadow.log":595}
for name,count in expected.items():
 s=(p/name).read_text()
 assert s.rstrip().splitlines()[-1].startswith("ok") and "--- FAIL:" not in s and "--- SKIP:" not in s,name
 assert len(re.findall(r"^--- PASS:",s,re.M))==count,(name,count)
 for test in ["TestNodeRecordBlocksMaximumLimitStartsSuffix","TestNodeRecordBlocksRetirementRejectsMaximumInt32Tail","TestNodeRecordBlocksCachedGeometryFollowsEveryMutation","TestNodeRecordBlocksSnapshotPreservesNilness"]:
  assert "--- PASS: "+test+" " in s,(name,test)
for name in ["boundary-386-after.log","out/candidate/node-blocks-386.log","out/candidate/core-race.log"]:
 s=(p/name).read_text()
 for test in ["TestNodeRecordBlocksMaximumLimitStartsSuffix","TestNodeRecordBlocksRetirementRejectsMaximumInt32Tail"]:
  assert "--- PASS: "+test+" " in s,(name,test)
 assert "--- FAIL:" not in s and "no tests to run" not in s,name
calls=[]
for f in (p/"candidate-source/internal/parsercorephase0").glob("*.go"):
 if not f.name.endswith("_test.go") and ".RetireBlock(" in f.read_text():calls.append(f.name)
assert not calls,calls
pins=json.loads((p/"candidate-source-pins.json").read_text());assert len(pins)==3535
for rel,want in pins.items():assert hashlib.sha256((p/"candidate-source"/rel).read_bytes()).hexdigest()==want,rel
report=dict(passed=True,full_Core_suite_passes=expected,boundary_regressions_pass_native_386_race=True,cached_geometry_and_nilness_tests_run=True,collection_calls_in_engine=0,source_hashes_exact=3535)
(p/"final-core-mode-audit.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
