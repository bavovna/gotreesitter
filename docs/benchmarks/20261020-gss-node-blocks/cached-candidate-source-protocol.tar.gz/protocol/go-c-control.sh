#!/usr/bin/env bash
set -euo pipefail
cd /candidate/cgo_harness
status=0
/evidence/out/candidate/cgo.test -test.run '^(TestGoTokenTurnExpandedLockedCProbe|TestGoGenericCallFrontierLockedCProbe)$' -test.count=1 -test.v -test.timeout=8m > /evidence/out/candidate-expanded-go-c.log 2>&1 || status=$?
printf '%s\n' "$status" > /evidence/out/candidate-expanded-go-c-exit.txt
python3 /evidence/audit-go-c.py
