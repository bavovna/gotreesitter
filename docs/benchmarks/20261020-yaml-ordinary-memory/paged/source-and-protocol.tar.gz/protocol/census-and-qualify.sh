#!/usr/bin/env bash
set -euo pipefail
bash /evidence/census.sh
python3 /evidence/analyze-counters.py > /evidence/counter-audit.log
bash /evidence/qualify.sh
