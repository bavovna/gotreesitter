from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
read=lambda n:json.loads((p/n).read_text())
assert (p/'qualify-complete.txt').read_text().strip()=='complete'
out=p/'out/candidate'
for pattern in ['invariant-*.log','c-*.log']:
 files=list(out.glob(pattern));assert len(files)==206
 for f in files:
  s=f.read_text();assert 'PASS' in s and '--- FAIL:' not in s and '--- SKIP:' not in s,f.name
  if pattern.startswith('invariant'):assert 'session_steps=72' in s and 'no_edit_allocs=0' in s,f.name
assert sum(len(re.findall(r'^--- PASS:',f.read_text(),re.M)) for f in out.glob('c-*.log'))==618
key=lambda r:(r['language'],r['route'])
b={key(r):r for r in read('reference-ledger.json')['rows']};a={key(r):r for r in read('out/candidate/ledger.json')['rows']}
assert b.keys()==a.keys() and len(a)==412
assert [k for k in a if a[k]!=b[k]]==[('yaml','candidate')]
ob=read('reference-owned-yaml-ledger.json')['rows'];oa=read('out/candidate/owned-yaml-ledger.json')['rows'];assert len(ob)==len(oa)==2 and ob[1]==oa[1]
for phase in ['full','edits']:
 x=ob[0][phase];y=oa[0][phase]
 if phase=='edits':x=x[0]['counters'];y=y[0]['counters']
 assert x['new_nodes']==484 and y['new_nodes']==232
 assert {k:v for k,v in x.items() if k!='new_nodes'}=={k:v for k,v in y.items() if k!='new_nodes'}
assert read('counter-gate.json')['passed'] and len(read('counter-gate.json')['comparisons'])==50
pins=read('candidate-source-pins.json');assert len(pins)==3532
for rel,want in pins.items():assert hashlib.sha256((p/'candidate-source'/rel).read_bytes()).hexdigest()==want,rel
old=(p.parent/'20261020-go-borrowed-dispatch-cell/out/baseline-expanded-go-c.log').read_text();log=(out/'go-expanded-c.log').read_text()
fail=lambda s:sorted(re.findall(r'^\s*--- FAIL: (\S+)',s,re.M))
assert fail(log)==fail(old) and len([s for s in fail(log) if '/' in s])==39
strict=read('out/candidate/strict-differences.json');assert len(strict)==1 and strict[0]['language']=='yaml' and strict[0]['candidate']['status']==strict[0]['production']['status']=='PASS'
for name in ['core-shadow','root-default','memory-pooling','root-race','core-race','core-386','root-386','yaml-large-c','large-go-c','owned-yaml-invariant']:
 s=(out/(name+'.log')).read_text();assert 'PASS' in s and '--- FAIL:' not in s and '--- SKIP:' not in s,name
rows={}
for line in (out/'canonical-work.log').read_text().splitlines():
 if 'CANONICAL_WORK_CENSUS ' in line:
  row=json.loads(line.split('CANONICAL_WORK_CENSUS ',1)[1]);rows[row['Fixture']]=row
assert rows==read('reference-canonical-work.json')['candidate'] and len(rows)==4
report=dict(canonical_Go_vectors_exact=4,passed=True,ordinary_ledger_rows=412,unchanged_ordinary_rows=411,newly_completed_ordinary_yaml_row=True,owned_yaml_rows=2,owned_yaml_new_nodes=[484,232],focused_public_and_whole_request_comparisons=50,work_direction_passed=True,invariant_languages=206,steps_per_session=72,C_fixture_checks=618,strict_rows=204,strict_yaml_now_compact_C_exact=True,expanded_Go_known_failures_unchanged=39,source_pin_count=len(pins),held_Go_repair_included=False,runtime_promoted=False)
(p/'full-counter-gate.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
