#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/focused-complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1
export GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/census-overlay.json'
mkdir -p /evidence/census
for role in baseline candidate; do
 if [[ "$role" = baseline ]]; then cd /reference; else cd /candidate; fi
 go test . -tags gts_parsercorephase0 -run '^TestStreamedPrefix(PublicWorkCensus|AttemptCensus)$' -count=1 -v -timeout=8m > "/evidence/census/$role.log" 2>&1
done
cd /candidate
GOFLAGS='-p=1 -buildvcs=false' go test . -tags gts_parsercorephase0 -run '^Test(CompactMemoryBudgetDetectsGrowthAfterSmallPoll|AdmissionSwitchCompactMemoryBudgetPeakFootprintBoundedOn(AdversarialWitness|WideGLR)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactAcceptance.*(MemoryBudget|RetentionBound|RebuildBudget)|G18RefSetSchedulerMemoryBudgetAccounting|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle)$' -count=1 -v -timeout=8m > /evidence/census/memory-pool.log 2>&1
printf 'complete\n' > /evidence/census/complete.txt
