#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(StreamedPrefixWorkspaceLifecycleAndAccounting|StreamedPrefixPublicationMetadata|SinglePrefixRejectsHistoricalOpaqueBindingSwap|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|DiagnosticParserCoreVersionLexer.*|FreshSnapshotPages.*|SnapshotPairFootprint.*|PackedSnapshotTrial.*)$' -count=1 -v -timeout=8m > /evidence/metadata-go.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=yaml go test . -tags gts_parsercorephase0 -run '^TestV1InvariantGateR4EditSession$' -count=1 -v -timeout=8m > /evidence/yaml-ordinary.log 2>&1
GTS_ADMISSION_CANDIDATE=1 go test . -tags gts_parsercorephase0 -run '^TestProgressArenaOwnedYAMLInvariant$' -count=1 -v -timeout=8m > /evidence/yaml-owned.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/yaml-c.test . > /evidence/cgo-build.log 2>&1
GTS_YAML_LARGE_PROBE=1 /evidence/yaml-c.test -test.run '^TestCompact(YAMLDocumentStreamLockedC|YAMLVersionOwnershipCOracle)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-c.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
