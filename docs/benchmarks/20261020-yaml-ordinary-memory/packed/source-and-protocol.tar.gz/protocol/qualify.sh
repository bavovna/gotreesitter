#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/census/complete.txt
test -f /evidence/counter-gate.json
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/qualification-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
mkdir -p /evidence/out/candidate
cd /candidate
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/out/candidate/core-shadow.log 2>&1
go test . -run '^TestCompact(ArenaReserve.*|Staged.*|IncrementalDoesNotReserveFullSource)$' -count=1 -v -timeout=8m > /evidence/out/candidate/root-default.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|CompactLegacyReadScratchPooledLargeThenSmall|ParserCoreFreshFullRunnerReusesSchedulerStorage|FreshSnapshotPages.*|SnapshotPairFootprint.*)$' -count=1 -v -timeout=8m > /evidence/out/candidate/memory-pooling.log 2>&1
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v -timeout=8m > /evidence/out/candidate/canonical-work.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/out/candidate/root.test . > /evidence/out/candidate/root-build.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/out/candidate/counter ./cmd/perfcounterledger > /evidence/out/candidate/counter-build.log 2>&1
/evidence/out/candidate/counter --write --output /evidence/out/candidate/ledger.json > /evidence/out/candidate/ledger.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/out/candidate/counter --langs yaml > /evidence/out/candidate/owned-yaml-ledger.json 2> /evidence/out/candidate/owned-yaml-ledger.log
while IFS= read -r grammar; do
 GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE="$grammar" /evidence/out/candidate/root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=4m > "/evidence/out/candidate/invariant-$grammar.log" 2>&1
done < /evidence/languages.txt
GTS_ADMISSION_CANDIDATE=1 /evidence/out/candidate/root.test -test.run '^TestProgressArenaOwnedYAMLInvariant$' -test.count=1 -test.v -test.timeout=4m > /evidence/out/candidate/owned-yaml-invariant.log 2>&1
cd /candidate/cgo_harness
go test -c -tags gts_parsercorephase0,treesitter_c_parity -o /evidence/out/candidate/cgo.test . > /evidence/out/candidate/cgo-build.log 2>&1
while IFS= read -r grammar; do
 GTS_ADMISSION_CANDIDATE=1 GTS_PARITY_MODE=exhaustive /evidence/out/candidate/cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${grammar}$" -test.count=1 -test.v -test.timeout=4m > "/evidence/out/candidate/c-$grammar.log" 2>&1
done < /evidence/languages.txt
python3 /evidence/strict.py candidate > /evidence/out/candidate/strict.log 2>&1
GTS_YAML_LARGE_PROBE=1 /evidence/out/candidate/cgo.test -test.run '^TestCompactYAMLDocumentStreamLockedC$' -test.count=1 -test.v -test.timeout=8m > /evidence/out/candidate/yaml-large-c.log 2>&1
cd /candidate
go test . -race -tags gts_parsercorephase0 -run '^Test(ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|CompactAcceptanceCachedPublicationStopControl|G18RefSetSchedulerMemoryBudgetAccounting)$' -count=1 -v -timeout=8m > /evidence/out/candidate/root-race.log 2>&1
go test ./internal/parsercorephase0 -race -run '^Test(ActionRowDescriptor|AlternativeSetTaggedWord|NodeLineage)' -count=1 -v -timeout=8m > /evidence/out/candidate/core-race.log 2>&1
/evidence/out/candidate/cgo.test -test.run '^(TestGoGenericCallFrontierLockedCProbe|TestGoTokenTurnExpandedLockedCProbe)$' -test.count=1 -test.v -test.timeout=8m > /evidence/out/candidate/go-expanded-c.log 2>&1 || status=$?
printf '%s\n' "${status:-0}" > /evidence/out/candidate/go-expanded-c-exit.txt
/evidence/out/candidate/cgo.test -test.run '^TestCompactLineageLargeGoLockedC$' -test.count=1 -test.v -test.timeout=8m > /evidence/out/candidate/large-go-c.log 2>&1
printf 'complete\n' > /evidence/qualify-complete.txt
