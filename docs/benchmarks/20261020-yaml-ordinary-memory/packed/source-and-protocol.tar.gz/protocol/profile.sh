#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/rss/rss-matched/audit.json
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_RSS_EXPECT_ORDINARY_COMPACT=1
mkdir -p /evidence/profile
cd /candidate
/evidence/rss/probes/candidate-rss-root.test -test.run '^TestCompactLineageRSS$/^yaml_ordinary$' -test.count=1 -test.v -test.timeout=8m -test.memprofile=/evidence/profile/yaml-ordinary-one-mib.alloc.pprof -test.memprofilerate=1 > /evidence/profile/yaml-ordinary-one-mib.log 2>&1
go tool pprof -sample_index=alloc_space -top -nodecount=16 /evidence/rss/probes/candidate-rss-root.test /evidence/profile/yaml-ordinary-one-mib.alloc.pprof > /evidence/profile/yaml-ordinary-one-mib.alloc-top.txt 2>&1
go tool pprof -sample_index=alloc_objects -top -nodecount=16 /evidence/rss/probes/candidate-rss-root.test /evidence/profile/yaml-ordinary-one-mib.alloc.pprof > /evidence/profile/yaml-ordinary-one-mib.objects-top.txt 2>&1
printf 'complete\n' > /evidence/profile/complete.txt
