TEXT github.com/odvcencio/gotreesitter.(*diagnosticParserCoreGenericScheduler).elect(SB) /candidate/parsercore_phase0_driver.go
  parsercore_phase0_driver.go:14137	0xa01cc0		4c8da42420fdffff	LEAQ 0xfffffd20(SP), R12														
  parsercore_phase0_driver.go:14137	0xa01cc8		4d3b6610		CMPQ R12, 0x10(R14)															
  parsercore_phase0_driver.go:14137	0xa01ccc		0f8635110000		JBE 0xa02e07																
  parsercore_phase0_driver.go:14137	0xa01cd2		55			PUSHQ BP																
  parsercore_phase0_driver.go:14137	0xa01cd3		4889e5			MOVQ SP, BP																
  parsercore_phase0_driver.go:14137	0xa01cd6		4881ec58030000		SUBQ $0x358, SP																
  parsercore_phase0_driver.go:14138	0xa01cdd		8400			TESTB AL, 0(AX)																
  parsercore_phase0_driver.go:14138	0xa01cdf		80b8801a000000		CMPB 0x1a80(AX), $0x0															
  parsercore_phase0_driver.go:14138	0xa01ce6		746e			JE 0xa01d56																
  parsercore_phase0_driver.go:14138	0xa01ce8		80b8811a000000		CMPB 0x1a81(AX), $0x0															
  parsercore_phase0_driver.go:14138	0xa01cef		7465			JE 0xa01d56																
  parsercore_phase0_driver.go:14139	0xa01cf1		440fb680821a0000	MOVZX 0x1a82(AX), R8															
  parsercore_phase0_driver.go:14139	0xa01cf9		4584c0			TESTL R8, R8																
  parsercore_phase0_driver.go:14139	0xa01cfc		7458			JE 0xa01d56																
  parsercore_phase0_driver.go:14139	0xa01cfe		6690			NOPW																	
  parsercore_phase0_driver.go:14140	0xa01d00		4180f8ff		CMPL R8, $0xff																
  parsercore_phase0_driver.go:14140	0xa01d04		7450			JE 0xa01d56																
  parsercore_phase0_driver.go:14141	0xa01d06		4180f807		CMPL R8, $0x7																
  parsercore_phase0_driver.go:14141	0xa01d0a		744a			JE 0xa01d56																
  parsercore_phase0_driver.go:14142	0xa01d0c		90			NOPL																	
  parsercore_phase0_driver.go:3346	0xa01d0d		66c780811a000000ff	MOVW $-0x100, 0x1a81(AX)														
  parsercore_phase0_driver.go:3348	0xa01d16		48c780c01c0000ffffffff	MOVQ $-0x1, 0x1cc0(AX)															
  parsercore_phase0_driver.go:3349	0xa01d21		48c780981b00000c000000	MOVQ $0xc, 0x1b98(AX)															
  parsercore_phase0_driver.go:3349	0xa01d2c		833d6d297b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parsercore_phase0_driver.go:3349	0xa01d33		7413			JE 0xa01d48																
  parsercore_phase0_driver.go:3349	0xa01d35		4c8b80901b0000		MOVQ 0x1b90(AX), R8															
  parsercore_phase0_driver.go:3349	0xa01d3c		0f1f4000		NOPL 0(AX)																
  parsercore_phase0_driver.go:3349	0xa01d40		e85b61a8ff		CALL runtime.gcWriteBarrier1(SB)													
  parsercore_phase0_driver.go:3349	0xa01d45		4d8903			MOVQ R8, 0(R11)																
  parsercore_phase0_driver.go:3349	0xa01d48		4c8d05cf01aa00		LEAQ 0xaa01cf(IP), R8															
  parsercore_phase0_driver.go:3349	0xa01d4f		4c8980901b0000		MOVQ R8, 0x1b90(AX)															
  parsercore_phase0_driver.go:14144	0xa01d56		4c8b80f8030000		MOVQ 0x3f8(AX), R8															
  parsercore_phase0_driver.go:14144	0xa01d5d		0f1f00			NOPL 0(AX)																
  parsercore_phase0_driver.go:14144	0xa01d60		4c398070040000		CMPQ 0x470(AX), R8															
  parsercore_phase0_driver.go:14144	0xa01d67		766e			JBE 0xa01dd7																
  parsercore_phase0_driver.go:14138	0xa01d69		4889842468030000	MOVQ AX, 0x368(SP)															
  parsercore_phase0_driver.go:14138	0xa01d71		889c2470030000		MOVB BL, 0x370(SP)															
  parsercore_phase0_driver.go:14152	0xa01d78		4c8b80b8180000		MOVQ 0x18b8(AX), R8															
  parsercore_phase0_driver.go:14153	0xa01d7f		488b4820		MOVQ 0x20(AX), CX															
  parsercore_phase0_driver.go:14152	0xa01d83		4c8b88a8180000		MOVQ 0x18a8(AX), R9															
  parsercore_phase0_driver.go:14153	0xa01d8a		4c39c1			CMPQ CX, R8																
  parsercore_phase0_driver.go:14153	0xa01d8d		7e36			JLE 0xa01dc5																
  parsercore_phase0_driver.go:14154	0xa01d8f		4b8d1400		LEAQ 0(R8)(R8*1), DX															
  parsercore_phase0_driver.go:14154	0xa01d93		4839d1			CMPQ CX, DX																
  parsercore_phase0_driver.go:14154	0xa01d96		480f4cca		CMOVL DX, CX																
  parsercore_phase0_driver.go:14154	0xa01d9a		48894c2468		MOVQ CX, 0x68(SP)															
  parsercore_phase0_driver.go:14154	0xa01d9f		488d05ba1c9500		LEAQ 0x951cba(IP), AX															
  parsercore_phase0_driver.go:14154	0xa01da6		31db			XORL BX, BX																
  parsercore_phase0_driver.go:14154	0xa01da8		e83304a8ff		CALL runtime.makeslice(SB)														
  parsercore_phase0_driver.go:14138	0xa01dad		0fb69c2470030000	MOVZX 0x370(SP), BX															
  parsercore_phase0_driver.go:14179	0xa01db5		4c8b442468		MOVQ 0x68(SP), R8															
  parsercore_phase0_driver.go:14179	0xa01dba		4989c1			MOVQ AX, R9																
  parsercore_phase0_driver.go:14156	0xa01dbd		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14156	0xa01dc5		4c8b5020		MOVQ 0x20(AX), R10															
  parsercore_phase0_driver.go:14156	0xa01dc9		4c89942410010000	MOVQ R10, 0x110(SP)															
  parsercore_phase0_driver.go:14156	0xa01dd1		31c9			XORL CX, CX																
  parsercore_phase0_driver.go:14156	0xa01dd3		31d2			XORL DX, DX																
  parsercore_phase0_driver.go:14156	0xa01dd5		eb71			JMP 0xa01e48																
  parsercore_phase0_driver.go:14145	0xa01dd7		488d05e2839d00		LEAQ 0x9d83e2(IP), AX															
  parsercore_phase0_driver.go:14145	0xa01dde		6690			NOPW																	
  parsercore_phase0_driver.go:14145	0xa01de0		e83bbba1ff		CALL runtime.newobject(SB)														
  parsercore_phase0_driver.go:14145	0xa01de5		48c7400803000000	MOVQ $0x3, 0x8(AX)															
  parsercore_phase0_driver.go:14145	0xa01ded		488d0d8c6da900		LEAQ 0xa96d8c(IP), CX															
  parsercore_phase0_driver.go:14145	0xa01df4		488908			MOVQ CX, 0(AX)																
  parsercore_phase0_driver.go:14145	0xa01df7		48c740181b000000	MOVQ $0x1b, 0x18(AX)															
  parsercore_phase0_driver.go:14145	0xa01dff		488d0d3615ac00		LEAQ 0xac1536(IP), CX															
  parsercore_phase0_driver.go:14145	0xa01e06		48894810		MOVQ CX, 0x10(AX)															
  parsercore_phase0_driver.go:14145	0xa01e0a		4889c3			MOVQ AX, BX																
  parsercore_phase0_driver.go:14145	0xa01e0d		488d050c2ede01		LEAQ go:itab.*github.com/odvcencio/gotreesitter.diagnosticParserCoreDecline,error(SB), AX						
  parsercore_phase0_driver.go:14145	0xa01e14		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14145	0xa01e1b		5d			POPQ BP																	
  parsercore_phase0_driver.go:14145	0xa01e1c		c3			RET																	
  parsercore_phase0_driver.go:14179	0xa01e1d		89449afc		MOVL AX, -0x4(DX)(BX*4)															
  parsercore_phase0_driver.go:14156	0xa01e21		4c8b5c2470		MOVQ 0x70(SP), R11															
  parsercore_phase0_driver.go:14156	0xa01e26		49ffc3			INCQ R11																
  parsercore_phase0_driver.go:14157	0xa01e29		4c89e0			MOVQ R12, AX																
  parsercore_phase0_driver.go:14156	0xa01e2c		4c8b942410010000	MOVQ 0x110(SP), R10															
  parsercore_phase0_driver.go:14179	0xa01e34		4989d1			MOVQ DX, R9																
  parsercore_phase0_driver.go:14179	0xa01e37		4989c8			MOVQ CX, R8																
  parsercore_phase0_driver.go:14156	0xa01e3a		4c89d9			MOVQ R11, CX																
  parsercore_phase0_driver.go:14179	0xa01e3d		4889da			MOVQ BX, DX																
  parsercore_phase0_driver.go:14138	0xa01e40		0fb69c2470030000	MOVZX 0x370(SP), BX															
  parsercore_phase0_driver.go:14179	0xa01e48		4c898c2458010000	MOVQ R9, 0x158(SP)															
  parsercore_phase0_driver.go:14179	0xa01e50		4c89442468		MOVQ R8, 0x68(SP)															
  parsercore_phase0_driver.go:14179	0xa01e55		4889542460		MOVQ DX, 0x60(SP)															
  parsercore_phase0_driver.go:14179	0xa01e5a		660f1f440000		NOPW 0(AX)(AX*1)															
  parsercore_phase0_driver.go:14156	0xa01e60		4c39d1			CMPQ CX, R10																
  parsercore_phase0_driver.go:14156	0xa01e63		0f8dae010000		JGE 0xa02017																
  parsercore_phase0_driver.go:14157	0xa01e69		488b7020		MOVQ 0x20(AX), SI															
  parsercore_phase0_driver.go:14157	0xa01e6d		4839f1			CMPQ CX, SI																
  parsercore_phase0_driver.go:14157	0xa01e70		0f83850f0000		JAE 0xa02dfb																
  parsercore_phase0_driver.go:14156	0xa01e76		48894c2470		MOVQ CX, 0x70(SP)															
  parsercore_phase0_driver.go:14157	0xa01e7b		488b5018		MOVQ 0x18(AX), DX															
  parsercore_phase0_driver.go:14157	0xa01e7f		4889942418020000	MOVQ DX, 0x218(SP)															
  parsercore_phase0_driver.go:14157	0xa01e87		488d0c89		LEAQ 0(CX)(CX*4), CX															
  parsercore_phase0_driver.go:14157	0xa01e8b		48c1e104		SHLQ $0x4, CX																
  parsercore_phase0_driver.go:14157	0xa01e8f		48898c2408010000	MOVQ CX, 0x108(SP)															
  parsercore_phase0_driver.go:14157	0xa01e97		488d1c0a		LEAQ 0(DX)(CX*1), BX															
  parsercore_phase0_driver.go:14158	0xa01e9b		0f1f440000		NOPL 0(AX)(AX*1)															
  parsercore_phase0_driver.go:14158	0xa01ea0		e87b96fcff		CALL github.com/odvcencio/gotreesitter.(*diagnosticParserCoreGenericScheduler).electHeaderState(SB)					
  parsercore_phase0_driver.go:14159	0xa01ea5		4885db			TESTQ BX, BX																
  parsercore_phase0_driver.go:14159	0xa01ea8		0f855a010000		JNE 0xa02008																
  parsercore_phase0_driver.go:14162	0xa01eae		4c8b842408010000	MOVQ 0x108(SP), R8															
  parsercore_phase0_driver.go:14162	0xa01eb6		4c8b8c2418020000	MOVQ 0x218(SP), R9															
  parsercore_phase0_driver.go:14162	0xa01ebe		470fb654013b		MOVZX 0x3b(R9)(R8*1), R10														
  parsercore_phase0_driver.go:14162	0xa01ec4		4584d2			TESTL R10, R10																
  parsercore_phase0_driver.go:14162	0xa01ec7		740b			JE 0xa01ed4																
  parsercore_phase0_driver.go:14138	0xa01ec9		440fb6942470030000	MOVZX 0x370(SP), R10															
  parsercore_phase0_driver.go:14162	0xa01ed2		eb15			JMP 0xa01ee9																
  parsercore_phase0_driver.go:14138	0xa01ed4		440fb6942470030000	MOVZX 0x370(SP), R10															
  parsercore_phase0_driver.go:14138	0xa01edd		0f1f00			NOPL 0(AX)																
  parsercore_phase0_driver.go:14138	0xa01ee0		4584d2			TESTL R10, R10																
  parsercore_phase0_driver.go:14162	0xa01ee3		0f8486000000		JE 0xa01f6f																
  parsercore_phase0_driver.go:14167	0xa01ee9		470fb65c013c		MOVZX 0x3c(R9)(R8*1), R11														
  parsercore_phase0_driver.go:14167	0xa01eef		4584db			TESTL R11, R11																
  parsercore_phase0_driver.go:14167	0xa01ef2		7571			JNE 0xa01f65																
  parsercore_phase0_driver.go:14167	0xa01ef4		478b5c010c		MOVL 0xc(R9)(R8*1), R11															
  parsercore_phase0_driver.go:14167	0xa01ef9		4c8ba42468030000	MOVQ 0x368(SP), R12															
  parsercore_phase0_driver.go:14167	0xa01f01		45399c249c000000	CMPL 0x9c(R12), R11															
  parsercore_phase0_driver.go:14167	0xa01f09		756c			JNE 0xa01f77																
  parsercore_phase0_driver.go:14179	0xa01f0b		488b5c2460		MOVQ 0x60(SP), BX															
  parsercore_phase0_driver.go:14179	0xa01f10		48ffc3			INCQ BX																	
  parsercore_phase0_driver.go:14179	0xa01f13		488b4c2468		MOVQ 0x68(SP), CX															
  parsercore_phase0_driver.go:14179	0xa01f18		4839d9			CMPQ CX, BX																
  parsercore_phase0_driver.go:14179	0xa01f1b		720d			JB 0xa01f2a																
  parsercore_phase0_driver.go:14179	0xa01f1d		488b942458010000	MOVQ 0x158(SP), DX															
  parsercore_phase0_driver.go:14179	0xa01f25		e9f3feffff		JMP 0xa01e1d																
  parsercore_phase0_driver.go:14158	0xa01f2a		8944244c		MOVL AX, 0x4c(SP)															
  parsercore_phase0_driver.go:14179	0xa01f2e		488b842458010000	MOVQ 0x158(SP), AX															
  parsercore_phase0_driver.go:14179	0xa01f36		bf01000000		MOVL $0x1, DI																
  parsercore_phase0_driver.go:14179	0xa01f3b		488d351e1b9500		LEAQ 0x951b1e(IP), SI															
  parsercore_phase0_driver.go:14179	0xa01f42		e87903a8ff		CALL runtime.growslice(SB)														
  parsercore_phase0_driver.go:14138	0xa01f47		440fb6942470030000	MOVZX 0x370(SP), R10															
  parsercore_phase0_driver.go:14157	0xa01f50		4c8ba42468030000	MOVQ 0x368(SP), R12															
  parsercore_phase0_driver.go:14179	0xa01f58		4889c2			MOVQ AX, DX																
  parsercore_phase0_driver.go:14179	0xa01f5b		8b44244c		MOVL 0x4c(SP), AX															
  parsercore_phase0_driver.go:14179	0xa01f5f		90			NOPL																	
  parsercore_phase0_driver.go:14179	0xa01f60		e9b8feffff		JMP 0xa01e1d																
  parsercore_phase0_driver.go:4781	0xa01f65		4c8ba42468030000	MOVQ 0x368(SP), R12															
  parsercore_phase0_driver.go:14167	0xa01f6d		eb08			JMP 0xa01f77																
  parsercore_phase0_driver.go:4781	0xa01f6f		4c8ba42468030000	MOVQ 0x368(SP), R12															
  parsercore_phase0_driver.go:4781	0xa01f77		4180bc246004000000	CMPB 0x460(R12), $0x0															
  parsercore_phase0_driver.go:14172	0xa01f80		742b			JE 0xa01fad																
  parsercore_phase0_driver.go:14173	0xa01f82		498b0424		MOVQ 0(R12), AX																
  parsercore_phase0_driver.go:14173	0xa01f86		438b5c010c		MOVL 0xc(R9)(R8*1), BX															
  parsercore_phase0_driver.go:14173	0xa01f8b		e890b8c1ff		CALL github.com/odvcencio/gotreesitter/internal/parsercorephase0.(*Core).CheckpointReceipt(SB)						
  parsercore_phase0_driver.go:14173	0xa01f90		0f100424		MOVUPS 0(SP), X0															
  parsercore_phase0_driver.go:14173	0xa01f94		0f118424e0000000	MOVUPS X0, 0xe0(SP)															
  parsercore_phase0_driver.go:14173	0xa01f9c		0f10442410		MOVUPS 0x10(SP), X0															
  parsercore_phase0_driver.go:14173	0xa01fa1		0f118424f0000000	MOVUPS X0, 0xf0(SP)															
  parsercore_phase0_driver.go:14173	0xa01fa9		84db			TESTL BL, BL																
  parsercore_phase0_driver.go:14173	0xa01fab		7444			JE 0xa01ff1																
  parsercore_phase0_driver.go:14177	0xa01fad		488d050c829d00		LEAQ 0x9d820c(IP), AX															
  parsercore_phase0_driver.go:14177	0xa01fb4		e867b9a1ff		CALL runtime.newobject(SB)														
  parsercore_phase0_driver.go:14177	0xa01fb9		48c7400808000000	MOVQ $0x8, 0x8(AX)															
  parsercore_phase0_driver.go:14177	0xa01fc1		488d0db2a8a900		LEAQ 0xa9a8b2(IP), CX															
  parsercore_phase0_driver.go:14177	0xa01fc8		488908			MOVQ CX, 0(AX)																
  parsercore_phase0_driver.go:14177	0xa01fcb		48c740184b000000	MOVQ $0x4b, 0x18(AX)															
  parsercore_phase0_driver.go:14177	0xa01fd3		488d0df4f6b800		LEAQ 0xb8f6f4(IP), CX															
  parsercore_phase0_driver.go:14177	0xa01fda		48894810		MOVQ CX, 0x10(AX)															
  parsercore_phase0_driver.go:14177	0xa01fde		4889c3			MOVQ AX, BX																
  parsercore_phase0_driver.go:14177	0xa01fe1		488d05382cde01		LEAQ go:itab.*github.com/odvcencio/gotreesitter.diagnosticParserCoreDecline,error(SB), AX						
  parsercore_phase0_driver.go:14177	0xa01fe8		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14177	0xa01fef		5d			POPQ BP																	
  parsercore_phase0_driver.go:14177	0xa01ff0		c3			RET																	
  parsercore_phase0_driver.go:14174	0xa01ff1		488b0588b17402		MOVQ github.com/odvcencio/gotreesitter.errDiagnosticParserCoreUnknownCheckpointIdentity(SB), AX						
  parsercore_phase0_driver.go:14174	0xa01ff8		488b1d89b17402		MOVQ github.com/odvcencio/gotreesitter.errDiagnosticParserCoreUnknownCheckpointIdentity+8(SB), BX					
  parsercore_phase0_driver.go:14174	0xa01fff		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14174	0xa02006		5d			POPQ BP																	
  parsercore_phase0_driver.go:14174	0xa02007		c3			RET																	
  parsercore_phase0_driver.go:14160	0xa02008		4889d8			MOVQ BX, AX																
  parsercore_phase0_driver.go:14160	0xa0200b		4889cb			MOVQ CX, BX																
  parsercore_phase0_driver.go:14160	0xa0200e		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14160	0xa02015		5d			POPQ BP																	
  parsercore_phase0_driver.go:14160	0xa02016		c3			RET																	
  parsercore_phase0_driver.go:14181	0xa02017		488990b0180000		MOVQ DX, 0x18b0(AX)															
  parsercore_phase0_driver.go:14181	0xa0201e		4c8980b8180000		MOVQ R8, 0x18b8(AX)															
  parsercore_phase0_driver.go:14181	0xa02025		833d74267b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parsercore_phase0_driver.go:14181	0xa0202c		7413			JE 0xa02041																
  parsercore_phase0_driver.go:14181	0xa0202e		4c8b90a8180000		MOVQ 0x18a8(AX), R10															
  parsercore_phase0_driver.go:14181	0xa02035		e8865ea8ff		CALL runtime.gcWriteBarrier2(SB)													
  parsercore_phase0_driver.go:14181	0xa0203a		4d890b			MOVQ R9, 0(R11)																
  parsercore_phase0_driver.go:14181	0xa0203d		4d895308		MOVQ R10, 0x8(R11)															
  parsercore_phase0_driver.go:14181	0xa02041		4c8988a8180000		MOVQ R9, 0x18a8(AX)															
  parsercore_phase0_driver.go:14182	0xa02048		4c8b9070230000		MOVQ 0x2370(AX), R10															
  parsercore_phase0_driver.go:14182	0xa0204f		4d85d2			TESTQ R10, R10																
  parsercore_phase0_driver.go:14182	0xa02052		742f			JE 0xa02083																
  parsercore_phase0_driver.go:14183	0xa02054		498b0a			MOVQ 0(R10), CX																
  parsercore_phase0_driver.go:14183	0xa02057		4c89d2			MOVQ R10, DX																
  parsercore_phase0_driver.go:14183	0xa0205a		ffd1			CALL CX																	
  parsercore_phase0_driver.go:14183	0xa0205c		0f1f4000		NOPL 0(AX)																
  parsercore_phase0_driver.go:14183	0xa02060		4885c0			TESTQ AX, AX																
  parsercore_phase0_driver.go:14183	0xa02063		0f8571050000		JNE 0xa025da																
  parsercore_phase0_driver.go:14187	0xa02069		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14187	0xa02071		488b542460		MOVQ 0x60(SP), DX															
  parsercore_phase0_driver.go:14276	0xa02076		4c8b442468		MOVQ 0x68(SP), R8															
  parsercore_phase0_driver.go:14187	0xa0207b		4c8b8c2458010000	MOVQ 0x158(SP), R9															
  parsercore_phase0_driver.go:14187	0xa02083		4885d2			TESTQ DX, DX																
  parsercore_phase0_driver.go:14187	0xa02086		0f86650d0000		JBE 0xa02df1																
  parsercore_phase0_driver.go:14187	0xa0208c		4c8b5008		MOVQ 0x8(AX), R10															
  parsercore_phase0_driver.go:14187	0xa02090		458b19			MOVL 0(R9), R11																
  parser_dfa_token_source.go:910	0xa02093		45895a18		MOVL R11, 0x18(R10)															
  parsercore_phase0_driver.go:14188	0xa02097		4883fa01		CMPQ DX, $0x1																
  parsercore_phase0_driver.go:14188	0xa0209b		7534			JNE 0xa020d1																
  parsercore_phase0_driver.go:14189	0xa0209d		488b4808		MOVQ 0x8(AX), CX															
  parser_dfa_token_source.go:921	0xa020a1		440f11b958020000	MOVUPS X15, 0x258(CX)															
  parser_dfa_token_source.go:921	0xa020a9		833df0257b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parser_dfa_token_source.go:921	0xa020b0		740f			JE 0xa020c1																
  parser_dfa_token_source.go:921	0xa020b2		488bb150020000		MOVQ 0x250(CX), SI															
  parser_dfa_token_source.go:921	0xa020b9		e8e25da8ff		CALL runtime.gcWriteBarrier1(SB)													
  parser_dfa_token_source.go:921	0xa020be		498933			MOVQ SI, 0(R11)																
  parser_dfa_token_source.go:921	0xa020c1		48c7815002000000000000	MOVQ $0x0, 0x250(CX)															
  parsercore_phase0_driver.go:14189	0xa020cc		e9f8000000		JMP 0xa021c9																
  parsercore_phase0_driver.go:14194	0xa020d1		488b88d0180000		MOVQ 0x18d0(AX), CX															
  parsercore_phase0_driver.go:14194	0xa020d8		4c8b90c0180000		MOVQ 0x18c0(AX), R10															
  parsercore_phase0_driver.go:14194	0xa020df		90			NOPL																	
  parsercore_phase0_driver.go:14194	0xa020e0		4839ca			CMPQ DX, CX																
  parsercore_phase0_driver.go:14194	0xa020e3		7705			JA 0xa020ea																
  parsercore_phase0_driver.go:14179	0xa020e5		4889d3			MOVQ DX, BX																
  parsercore_phase0_driver.go:14194	0xa020e8		eb28			JMP 0xa02112																
  parsercore_phase0_driver.go:14194	0xa020ea		4c89d0			MOVQ R10, AX																
  parsercore_phase0_driver.go:14194	0xa020ed		4889d3			MOVQ DX, BX																
  parsercore_phase0_driver.go:14194	0xa020f0		4889df			MOVQ BX, DI																
  parsercore_phase0_driver.go:14194	0xa020f3		488d3566199500		LEAQ 0x951966(IP), SI															
  parsercore_phase0_driver.go:14194	0xa020fa		e8c101a8ff		CALL runtime.growslice(SB)														
  parsercore_phase0_driver.go:14194	0xa020ff		4c8b8c2458010000	MOVQ 0x158(SP), R9															
  parsercore_phase0_driver.go:14194	0xa02107		4989c2			MOVQ AX, R10																
  parsercore_phase0_driver.go:14194	0xa0210a		4889da			MOVQ BX, DX																
  parsercore_phase0_driver.go:14194	0xa0210d		488b5c2460		MOVQ 0x60(SP), BX															
  parsercore_phase0_driver.go:14194	0xa02112		48898c2480000000	MOVQ CX, 0x80(SP)															
  parsercore_phase0_driver.go:14194	0xa0211a		4889542478		MOVQ DX, 0x78(SP)															
  parsercore_phase0_driver.go:14194	0xa0211f		4c89942460010000	MOVQ R10, 0x160(SP)															
  parsercore_phase0_driver.go:14194	0xa02127		4889d9			MOVQ BX, CX																
  parsercore_phase0_driver.go:14194	0xa0212a		48c1e102		SHLQ $0x2, CX																
  parsercore_phase0_driver.go:14194	0xa0212e		4c89d0			MOVQ R10, AX																
  parsercore_phase0_driver.go:14194	0xa02131		4c89cb			MOVQ R9, BX																
  parsercore_phase0_driver.go:14194	0xa02134		e8076ba8ff		CALL runtime.memmove(SB)														
  parsercore_phase0_driver.go:14195	0xa02139		488b542478		MOVQ 0x78(SP), DX															
  parsercore_phase0_driver.go:14195	0xa0213e		488bb42468030000	MOVQ 0x368(SP), SI															
  parsercore_phase0_driver.go:14195	0xa02146		488996c8180000		MOVQ DX, 0x18c8(SI)															
  parsercore_phase0_driver.go:14195	0xa0214d		488bbc2480000000	MOVQ 0x80(SP), DI															
  parsercore_phase0_driver.go:14195	0xa02155		4889bed0180000		MOVQ DI, 0x18d0(SI)															
  parsercore_phase0_driver.go:14195	0xa0215c		833d3d257b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parsercore_phase0_driver.go:14195	0xa02163		750a			JNE 0xa0216f																
  parsercore_phase0_driver.go:14195	0xa02165		4c8b842460010000	MOVQ 0x160(SP), R8															
  parsercore_phase0_driver.go:14195	0xa0216d		eb1b			JMP 0xa0218a																
  parsercore_phase0_driver.go:14195	0xa0216f		488b8ec0180000		MOVQ 0x18c0(SI), CX															
  parsercore_phase0_driver.go:14195	0xa02176		e8455da8ff		CALL runtime.gcWriteBarrier2(SB)													
  parsercore_phase0_driver.go:14195	0xa0217b		4c8b842460010000	MOVQ 0x160(SP), R8															
  parsercore_phase0_driver.go:14195	0xa02183		4d8903			MOVQ R8, 0(R11)																
  parsercore_phase0_driver.go:14195	0xa02186		49894b08		MOVQ CX, 0x8(R11)															
  parsercore_phase0_driver.go:14195	0xa0218a		4c8986c0180000		MOVQ R8, 0x18c0(SI)															
  parsercore_phase0_driver.go:14196	0xa02191		488b4e08		MOVQ 0x8(SI), CX															
  parser_dfa_token_source.go:921	0xa02195		48899158020000		MOVQ DX, 0x258(CX)															
  parser_dfa_token_source.go:921	0xa0219c		4889b960020000		MOVQ DI, 0x260(CX)															
  parser_dfa_token_source.go:921	0xa021a3		833df6247b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parser_dfa_token_source.go:921	0xa021aa		7413			JE 0xa021bf																
  parser_dfa_token_source.go:921	0xa021ac		488b9150020000		MOVQ 0x250(CX), DX															
  parser_dfa_token_source.go:921	0xa021b3		e8085da8ff		CALL runtime.gcWriteBarrier2(SB)													
  parser_dfa_token_source.go:921	0xa021b8		4d8903			MOVQ R8, 0(R11)																
  parser_dfa_token_source.go:921	0xa021bb		49895308		MOVQ DX, 0x8(R11)															
  parser_dfa_token_source.go:921	0xa021bf		4c898150020000		MOVQ R8, 0x250(CX)															
  parsercore_phase0_driver.go:14198	0xa021c6		4889f0			MOVQ SI, AX																
  parsercore_phase0_driver.go:14198	0xa021c9		488b4808		MOVQ 0x8(AX), CX															
  parsercore_phase0_driver.go:14198	0xa021cd		488b5810		MOVQ 0x10(AX), BX															
  parsercore_phase0_driver.go:14198	0xa021d1		4889c8			MOVQ CX, AX																
  parsercore_phase0_driver.go:14198	0xa021d4		e8477adcff		CALL github.com/odvcencio/gotreesitter.(*dfaTokenSource).captureExternalScannerStateInto(SB)						
  parsercore_phase0_driver.go:14198	0xa021d9		48898424a0010000	MOVQ AX, 0x1a0(SP)															
  parsercore_phase0_driver.go:14198	0xa021e1		48899c24a8000000	MOVQ BX, 0xa8(SP)															
  parsercore_phase0_driver.go:14198	0xa021e9		48898c24b0000000	MOVQ CX, 0xb0(SP)															
  parsercore_phase0_driver.go:14203	0xa021f1		4889cf			MOVQ CX, DI																
  parsercore_phase0_driver.go:14203	0xa021f4		4889d9			MOVQ BX, CX																
  parsercore_phase0_driver.go:14203	0xa021f7		4889c3			MOVQ AX, BX																
  parsercore_phase0_driver.go:14203	0xa021fa		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14203	0xa02202		e83913fdff		CALL github.com/odvcencio/gotreesitter.(*diagnosticParserCoreGenericScheduler).captureSharedElectionSnapshotFromExternalPayload(SB)	
  parsercore_phase0_driver.go:14203	0xa02207		4885c0			TESTQ AX, AX																
  parsercore_phase0_driver.go:14203	0xa0220a		0f85c1030000		JNE 0xa025d1																
  parsercore_phase0_driver.go:14206	0xa02210		488b942468030000	MOVQ 0x368(SP), DX															
  parsercore_phase0_driver.go:14206	0xa02218		488b02			MOVQ 0(DX), AX																
  parsercore_phase0_driver.go:14206	0xa0221b		488b9c24a0010000	MOVQ 0x1a0(SP), BX															
  parsercore_phase0_driver.go:14206	0xa02223		488b8c24a8000000	MOVQ 0xa8(SP), CX															
  parsercore_phase0_driver.go:14206	0xa0222b		488bbc24b0000000	MOVQ 0xb0(SP), DI															
  parsercore_phase0_driver.go:14206	0xa02233		e84852fbff		CALL github.com/odvcencio/gotreesitter.diagnosticParserCoreInternCheckpoint(SB)								
  parsercore_phase0_driver.go:14206	0xa02238		488b1424		MOVQ 0(SP), DX																
  parsercore_phase0_driver.go:14206	0xa0223c		4889942420020000	MOVQ DX, 0x220(SP)															
  parsercore_phase0_driver.go:14206	0xa02244		0f10442408		MOVUPS 0x8(SP), X0															
  parsercore_phase0_driver.go:14206	0xa02249		0f11842428020000	MOVUPS X0, 0x228(SP)															
  parsercore_phase0_driver.go:14206	0xa02251		0f10442418		MOVUPS 0x18(SP), X0															
  parsercore_phase0_driver.go:14206	0xa02256		0f11842438020000	MOVUPS X0, 0x238(SP)															
  parsercore_phase0_driver.go:14206	0xa0225e		488b942420020000	MOVQ 0x220(SP), DX															
  parsercore_phase0_driver.go:14206	0xa02266		48899424b8000000	MOVQ DX, 0xb8(SP)															
  parsercore_phase0_driver.go:14206	0xa0226e		0f10842428020000	MOVUPS 0x228(SP), X0															
  parsercore_phase0_driver.go:14206	0xa02276		0f118424c0000000	MOVUPS X0, 0xc0(SP)															
  parsercore_phase0_driver.go:14206	0xa0227e		0f10842438020000	MOVUPS 0x238(SP), X0															
  parsercore_phase0_driver.go:14206	0xa02286		0f118424d0000000	MOVUPS X0, 0xd0(SP)															
  parsercore_phase0_driver.go:14207	0xa0228e		4885db			TESTQ BX, BX																
  parsercore_phase0_driver.go:14207	0xa02291		0f852b030000		JNE 0xa025c2																
  parsercore_phase0_driver.go:14210	0xa02297		488b8c2468030000	MOVQ 0x368(SP), CX															
  parsercore_phase0_driver.go:14210	0xa0229f		90			NOPL																	
  parsercore_phase0_driver.go:14210	0xa022a0		39819c000000		CMPL 0x9c(CX), AX															
  parsercore_phase0_driver.go:14210	0xa022a6		0f85d2020000		JNE 0xa0257e																
  parsercore_phase0_driver.go:14206	0xa022ac		89442458		MOVL AX, 0x58(SP)															
  parsercore_phase0_driver.go:14213	0xa022b0		898198000000		MOVL AX, 0x98(CX)															
  parsercore_phase0_driver.go:14215	0xa022b6		488b4108		MOVQ 0x8(CX), AX															
  parsercore_phase0_driver.go:14215	0xa022ba		e8a1fedaff		CALL github.com/odvcencio/gotreesitter.(*dfaTokenSource).Next(SB)									
  parsercore_phase0_driver.go:14215	0xa022bf		0f100424		MOVUPS 0(SP), X0															
  parsercore_phase0_driver.go:14215	0xa022c3		0f11842418010000	MOVUPS X0, 0x118(SP)															
  parsercore_phase0_driver.go:14215	0xa022cb		0f10442410		MOVUPS 0x10(SP), X0															
  parsercore_phase0_driver.go:14215	0xa022d0		0f11842428010000	MOVUPS X0, 0x128(SP)															
  parsercore_phase0_driver.go:14215	0xa022d8		0f10442420		MOVUPS 0x20(SP), X0															
  parsercore_phase0_driver.go:14215	0xa022dd		0f11842438010000	MOVUPS X0, 0x138(SP)															
  parsercore_phase0_driver.go:14215	0xa022e5		0f10442430		MOVUPS 0x30(SP), X0															
  parsercore_phase0_driver.go:14215	0xa022ea		0f11842448010000	MOVUPS X0, 0x148(SP)															
  parsercore_phase0_driver.go:14216	0xa022f2		488b8c2468030000	MOVQ 0x368(SP), CX															
  parsercore_phase0_driver.go:14216	0xa022fa		488b4108		MOVQ 0x8(CX), AX															
  parsercore_phase0_driver.go:14216	0xa022fe		488b5910		MOVQ 0x10(CX), BX															
  parsercore_phase0_driver.go:14216	0xa02302		e81979dcff		CALL github.com/odvcencio/gotreesitter.(*dfaTokenSource).captureExternalScannerStateInto(SB)						
  parsercore_phase0_driver.go:14217	0xa02307		488b942468030000	MOVQ 0x368(SP), DX															
  parsercore_phase0_driver.go:14217	0xa0230f		488b12			MOVQ 0(DX), DX																
  parsercore_phase0_driver.go:14217	0xa02312		4889cf			MOVQ CX, DI																
  parsercore_phase0_driver.go:14217	0xa02315		4889d9			MOVQ BX, CX																
  parsercore_phase0_driver.go:14217	0xa02318		4889c3			MOVQ AX, BX																
  parsercore_phase0_driver.go:14217	0xa0231b		4889d0			MOVQ DX, AX																
  parsercore_phase0_driver.go:14217	0xa0231e		6690			NOPW																	
  parsercore_phase0_driver.go:14217	0xa02320		e85b51fbff		CALL github.com/odvcencio/gotreesitter.diagnosticParserCoreInternCheckpoint(SB)								
  parsercore_phase0_driver.go:14217	0xa02325		488b1424		MOVQ 0(SP), DX																
  parsercore_phase0_driver.go:14217	0xa02329		4889942420020000	MOVQ DX, 0x220(SP)															
  parsercore_phase0_driver.go:14217	0xa02331		0f10442408		MOVUPS 0x8(SP), X0															
  parsercore_phase0_driver.go:14217	0xa02336		0f11842428020000	MOVUPS X0, 0x228(SP)															
  parsercore_phase0_driver.go:14217	0xa0233e		0f10442418		MOVUPS 0x18(SP), X0															
  parsercore_phase0_driver.go:14217	0xa02343		0f11842438020000	MOVUPS X0, 0x238(SP)															
  parsercore_phase0_driver.go:14217	0xa0234b		488b942420020000	MOVQ 0x220(SP), DX															
  parsercore_phase0_driver.go:14217	0xa02353		48899424e0000000	MOVQ DX, 0xe0(SP)															
  parsercore_phase0_driver.go:14217	0xa0235b		0f10842428020000	MOVUPS 0x228(SP), X0															
  parsercore_phase0_driver.go:14217	0xa02363		0f118424e8000000	MOVUPS X0, 0xe8(SP)															
  parsercore_phase0_driver.go:14217	0xa0236b		0f10842438020000	MOVUPS 0x238(SP), X0															
  parsercore_phase0_driver.go:14217	0xa02373		0f118424f8000000	MOVUPS X0, 0xf8(SP)															
  parsercore_phase0_driver.go:14217	0xa0237b		0f1f440000		NOPL 0(AX)(AX*1)															
  parsercore_phase0_driver.go:14218	0xa02380		4885db			TESTQ BX, BX																
  parsercore_phase0_driver.go:14218	0xa02383		0f85e6010000		JNE 0xa0256f																
  parsercore_phase0_driver.go:14217	0xa02389		8944245c		MOVL AX, 0x5c(SP)															
  parsercore_phase0_driver.go:14221	0xa0238d		488b8c2468030000	MOVQ 0x368(SP), CX															
  parsercore_phase0_driver.go:14221	0xa02395		488b5908		MOVQ 0x8(CX), BX															
  parsercore_phase0_driver.go:14221	0xa02399		488d056027de01		LEAQ go:itab.*github.com/odvcencio/gotreesitter.dfaTokenSource,github.com/odvcencio/gotreesitter.TokenSource(SB), AX			
  parsercore_phase0_driver.go:14221	0xa023a0		e89bc7cdff		CALL github.com/odvcencio/gotreesitter.currentExternalScannerCheckpoint(SB)								
  parsercore_phase0_driver.go:14221	0xa023a5		4889842420020000	MOVQ AX, 0x220(SP)															
  parsercore_phase0_driver.go:14221	0xa023ad		48899c2428020000	MOVQ BX, 0x228(SP)															
  parsercore_phase0_driver.go:14221	0xa023b5		48898c2430020000	MOVQ CX, 0x230(SP)															
  parsercore_phase0_driver.go:14221	0xa023bd		4889bc2438020000	MOVQ DI, 0x238(SP)															
  parsercore_phase0_driver.go:14221	0xa023c5		4889b42440020000	MOVQ SI, 0x240(SP)															
  parsercore_phase0_driver.go:14221	0xa023cd		4c89842448020000	MOVQ R8, 0x248(SP)															
  parsercore_phase0_driver.go:14221	0xa023d5		0f10842420020000	MOVUPS 0x220(SP), X0															
  parsercore_phase0_driver.go:14221	0xa023dd		0f11842470010000	MOVUPS X0, 0x170(SP)															
  parsercore_phase0_driver.go:14221	0xa023e5		0f10842430020000	MOVUPS 0x230(SP), X0															
  parsercore_phase0_driver.go:14221	0xa023ed		0f11842480010000	MOVUPS X0, 0x180(SP)															
  parsercore_phase0_driver.go:14221	0xa023f5		0f10842440020000	MOVUPS 0x240(SP), X0															
  parsercore_phase0_driver.go:14221	0xa023fd		0f11842490010000	MOVUPS X0, 0x190(SP)															
  parsercore_phase0_driver.go:14222	0xa02405		488b8c2468030000	MOVQ 0x368(SP), CX															
  parsercore_phase0_driver.go:14222	0xa0240d		80b98923000000		CMPB 0x2389(CX), $0x0															
  parsercore_phase0_driver.go:14222	0xa02414		0f8484000000		JE 0xa0249e																
  parsercore_phase0_driver.go:14223	0xa0241a		6683bc245001000000	CMPW 0x150(SP), $0x0															
  parsercore_phase0_driver.go:14223	0xa02423		752e			JNE 0xa02453																
  parsercore_phase0_driver.go:14223	0xa02425		8b942428010000		MOVL 0x128(SP), DX															
  parsercore_phase0_driver.go:14223	0xa0242c		3994242c010000		CMPL 0x12c(SP), DX															
  parsercore_phase0_driver.go:14223	0xa02433		751e			JNE 0xa02453																
  parsercore_phase0_driver.go:14224	0xa02435		80bc245201000000	CMPB 0x152(SP), $0x0															
  parsercore_phase0_driver.go:14224	0xa0243d		7514			JNE 0xa02453																
  parsercore_phase0_driver.go:14224	0xa0243f		80bc245301000000	CMPB 0x153(SP), $0x0															
  parsercore_phase0_driver.go:14224	0xa02447		750a			JNE 0xa02453																
  parsercore_phase0_driver.go:14224	0xa02449		80bc245401000000	CMPB 0x154(SP), $0x0															
  parsercore_phase0_driver.go:14224	0xa02451		7444			JE 0xa02497																
  parsercore_phase0_driver.go:14225	0xa02453		488d05667d9d00		LEAQ 0x9d7d66(IP), AX															
  parsercore_phase0_driver.go:14225	0xa0245a		e8c1b4a1ff		CALL runtime.newobject(SB)														
  parsercore_phase0_driver.go:14226	0xa0245f		48c7400811000000	MOVQ $0x11, 0x8(AX)															
  parsercore_phase0_driver.go:14226	0xa02467		488d0d218aaa00		LEAQ 0xaa8a21(IP), CX															
  parsercore_phase0_driver.go:14226	0xa0246e		488908			MOVQ CX, 0(AX)																
  parsercore_phase0_driver.go:14227	0xa02471		48c7401856000000	MOVQ $0x56, 0x18(AX)															
  parsercore_phase0_driver.go:14227	0xa02479		488d0d4de2b900		LEAQ 0xb9e24d(IP), CX															
  parsercore_phase0_driver.go:14227	0xa02480		48894810		MOVQ CX, 0x10(AX)															
  parsercore_phase0_driver.go:14225	0xa02484		4889c3			MOVQ AX, BX																
  parsercore_phase0_driver.go:14225	0xa02487		488d059227de01		LEAQ go:itab.*github.com/odvcencio/gotreesitter.diagnosticParserCoreDecline,error(SB), AX						
  parsercore_phase0_driver.go:14225	0xa0248e		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14225	0xa02495		5d			POPQ BP																	
  parsercore_phase0_driver.go:14225	0xa02496		c3			RET																	
  parsercore_phase0_driver.go:14230	0xa02497		c6818923000000		MOVB $0x0, 0x2389(CX)															
  parsercore_phase0_driver.go:14221	0xa0249e		44894c2450		MOVL R9, 0x50(SP)															
  parsercore_phase0_driver.go:14221	0xa024a3		4489542454		MOVL R10, 0x54(SP)															
  parsercore_phase0_driver.go:14221	0xa024a8		44885c244b		MOVB R11, 0x4b(SP)															
  parsercore_phase0_driver.go:14232	0xa024ad		80bc245301000000	CMPB 0x153(SP), $0x0															
  parsercore_phase0_driver.go:14232	0xa024b5		7458			JE 0xa0250f																
  parsercore_phase0_driver.go:14233	0xa024b7		0fb691d8030000		MOVZX 0x3d8(CX), DX															
  parsercore_phase0_driver.go:14233	0xa024be		ffc2			INCL DX																	
  parsercore_phase0_driver.go:14233	0xa024c0		8891d8030000		MOVB DL, 0x3d8(CX)															
  parsercore_phase0_driver.go:14234	0xa024c6		80fa40			CMPL DL, $0x40																
  parsercore_phase0_driver.go:14234	0xa024c9		764b			JBE 0xa02516																
  parsercore_phase0_driver.go:14235	0xa024cb		488d05ee7c9d00		LEAQ 0x9d7cee(IP), AX															
  parsercore_phase0_driver.go:14235	0xa024d2		e849b4a1ff		CALL runtime.newobject(SB)														
  parsercore_phase0_driver.go:14236	0xa024d7		48c7400803000000	MOVQ $0x3, 0x8(AX)															
  parsercore_phase0_driver.go:14236	0xa024df		488d0d9a66a900		LEAQ 0xa9669a(IP), CX															
  parsercore_phase0_driver.go:14236	0xa024e6		488908			MOVQ CX, 0(AX)																
  parsercore_phase0_driver.go:14237	0xa024e9		48c740182e000000	MOVQ $0x2e, 0x18(AX)															
  parsercore_phase0_driver.go:14237	0xa024f1		488d0d1401b100		LEAQ 0xb10114(IP), CX															
  parsercore_phase0_driver.go:14237	0xa024f8		48894810		MOVQ CX, 0x10(AX)															
  parsercore_phase0_driver.go:14235	0xa024fc		4889c3			MOVQ AX, BX																
  parsercore_phase0_driver.go:14235	0xa024ff		488d051a27de01		LEAQ go:itab.*github.com/odvcencio/gotreesitter.diagnosticParserCoreDecline,error(SB), AX						
  parsercore_phase0_driver.go:14235	0xa02506		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14235	0xa0250d		5d			POPQ BP																	
  parsercore_phase0_driver.go:14235	0xa0250e		c3			RET																	
  parsercore_phase0_driver.go:14241	0xa0250f		c681d803000000		MOVB $0x0, 0x3d8(CX)															
  parsercore_phase0_driver.go:14243	0xa02516		488b01			MOVQ 0(CX), AX																
  parsercore_phase0_driver.go:14243	0xa02519		e802aac1ff		CALL github.com/odvcencio/gotreesitter/internal/parsercorephase0.(*Core).BeginFrontier(SB)						
  parsercore_phase0_driver.go:14243	0xa0251e		6690			NOPW																	
  parsercore_phase0_driver.go:14243	0xa02520		4885c0			TESTQ AX, AX																
  parsercore_phase0_driver.go:14243	0xa02523		7541			JNE 0xa02566																
  parsercore_phase0_driver.go:14246	0xa02525		488b942468030000	MOVQ 0x368(SP), DX															
  parsercore_phase0_driver.go:14246	0xa0252d		488b02			MOVQ 0(DX), AX																
  parsercore_phase0_driver.go:14246	0xa02530		8b5c2458		MOVL 0x58(SP), BX															
  parsercore_phase0_driver.go:14246	0xa02534		8b4c245c		MOVL 0x5c(SP), CX															
  parsercore_phase0_driver.go:14246	0xa02538		e8a3acc1ff		CALL github.com/odvcencio/gotreesitter/internal/parsercorephase0.(*Core).SetPhaseExternalTokenScannerCheckpoints(SB)			
  parsercore_phase0_driver.go:14246	0xa0253d		0f1f00			NOPL 0(AX)																
  parsercore_phase0_driver.go:14246	0xa02540		4885c0			TESTQ AX, AX																
  parsercore_phase0_driver.go:14246	0xa02543		7518			JNE 0xa0255d																
  parsercore_phase0_driver.go:14249	0xa02545		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14249	0xa0254d		4c8b4020		MOVQ 0x20(AX), R8															
  parsercore_phase0_driver.go:14249	0xa02551		448b4c245c		MOVL 0x5c(SP), R9															
  parsercore_phase0_driver.go:14249	0xa02556		31c9			XORL CX, CX																
  parsercore_phase0_driver.go:14249	0xa02558		e9a3000000		JMP 0xa02600																
  parsercore_phase0_driver.go:14247	0xa0255d		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14247	0xa02564		5d			POPQ BP																	
  parsercore_phase0_driver.go:14247	0xa02565		c3			RET																	
  parsercore_phase0_driver.go:14244	0xa02566		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14244	0xa0256d		5d			POPQ BP																	
  parsercore_phase0_driver.go:14244	0xa0256e		c3			RET																	
  parsercore_phase0_driver.go:14219	0xa0256f		4889d8			MOVQ BX, AX																
  parsercore_phase0_driver.go:14219	0xa02572		4889cb			MOVQ CX, BX																
  parsercore_phase0_driver.go:14219	0xa02575		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14219	0xa0257c		5d			POPQ BP																	
  parsercore_phase0_driver.go:14219	0xa0257d		c3			RET																	
  parsercore_phase0_driver.go:14211	0xa0257e		488d053b7c9d00		LEAQ 0x9d7c3b(IP), AX															
  parsercore_phase0_driver.go:14211	0xa02585		e896b3a1ff		CALL runtime.newobject(SB)														
  parsercore_phase0_driver.go:14211	0xa0258a		48c7400808000000	MOVQ $0x8, 0x8(AX)															
  parsercore_phase0_driver.go:14211	0xa02592		488d0de1a2a900		LEAQ 0xa9a2e1(IP), CX															
  parsercore_phase0_driver.go:14211	0xa02599		488908			MOVQ CX, 0(AX)																
  parsercore_phase0_driver.go:14211	0xa0259c		48c7401836000000	MOVQ $0x36, 0x18(AX)															
  parsercore_phase0_driver.go:14211	0xa025a4		488d0d0799b300		LEAQ 0xb39907(IP), CX															
  parsercore_phase0_driver.go:14211	0xa025ab		48894810		MOVQ CX, 0x10(AX)															
  parsercore_phase0_driver.go:14211	0xa025af		4889c3			MOVQ AX, BX																
  parsercore_phase0_driver.go:14211	0xa025b2		488d056726de01		LEAQ go:itab.*github.com/odvcencio/gotreesitter.diagnosticParserCoreDecline,error(SB), AX						
  parsercore_phase0_driver.go:14211	0xa025b9		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14211	0xa025c0		5d			POPQ BP																	
  parsercore_phase0_driver.go:14211	0xa025c1		c3			RET																	
  parsercore_phase0_driver.go:14208	0xa025c2		4889d8			MOVQ BX, AX																
  parsercore_phase0_driver.go:14208	0xa025c5		4889cb			MOVQ CX, BX																
  parsercore_phase0_driver.go:14208	0xa025c8		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14208	0xa025cf		5d			POPQ BP																	
  parsercore_phase0_driver.go:14208	0xa025d0		c3			RET																	
  parsercore_phase0_driver.go:14204	0xa025d1		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14204	0xa025d8		5d			POPQ BP																	
  parsercore_phase0_driver.go:14204	0xa025d9		c3			RET																	
  parsercore_phase0_driver.go:14184	0xa025da		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14184	0xa025e1		5d			POPQ BP																	
  parsercore_phase0_driver.go:14184	0xa025e2		c3			RET																	
  parsercore_phase0_driver.go:14254	0xa025e3		4c8b5018		MOVQ 0x18(AX), R10															
  parsercore_phase0_driver.go:1563	0xa025e7		470fb6641a43		MOVZX 0x43(R10)(R11*1), R12														
  parsercore_phase0_driver.go:1563	0xa025ed		4183e4fb		ANDL $-0x5, R12																
  parsercore_phase0_driver.go:1563	0xa025f1		4788641a43		MOVB R12, 0x43(R10)(R11*1)														
  parsercore_phase0_driver.go:14249	0xa025f6		48ffc1			INCQ CX																	
  parsercore_phase0_driver.go:14249	0xa025f9		0f1f8000000000		NOPL 0(AX)																
  parsercore_phase0_driver.go:14249	0xa02600		4c39c1			CMPQ CX, R8																
  parsercore_phase0_driver.go:14249	0xa02603		0f8d7c000000		JGE 0xa02685																
  parsercore_phase0_driver.go:14250	0xa02609		4c8b5020		MOVQ 0x20(AX), R10															
  parsercore_phase0_driver.go:14250	0xa0260d		4c39d1			CMPQ CX, R10																
  parsercore_phase0_driver.go:14250	0xa02610		0f83d0070000		JAE 0xa02de6																
  parsercore_phase0_driver.go:14250	0xa02616		4c8b5018		MOVQ 0x18(AX), R10															
  parsercore_phase0_driver.go:14250	0xa0261a		4c8d1c89		LEAQ 0(CX)(CX*4), R11															
  parsercore_phase0_driver.go:14250	0xa0261e		49c1e304		SHLQ $0x4, R11																
  parsercore_phase0_driver.go:14250	0xa02622		43c6441a3b00		MOVB $0x0, 0x3b(R10)(R11*1)														
  parsercore_phase0_driver.go:14251	0xa02628		4c8b5020		MOVQ 0x20(AX), R10															
  parsercore_phase0_driver.go:14251	0xa0262c		4c39d1			CMPQ CX, R10																
  parsercore_phase0_driver.go:14251	0xa0262f		0f83a6070000		JAE 0xa02ddb																
  parsercore_phase0_driver.go:14251	0xa02635		4c8b5018		MOVQ 0x18(AX), R10															
  parsercore_phase0_driver.go:14251	0xa02639		43c6441a3d00		MOVB $0x0, 0x3d(R10)(R11*1)														
  parsercore_phase0_driver.go:14252	0xa0263f		4c8b5020		MOVQ 0x20(AX), R10															
  parsercore_phase0_driver.go:14252	0xa02643		4c39d1			CMPQ CX, R10																
  parsercore_phase0_driver.go:14252	0xa02646		0f8384070000		JAE 0xa02dd0																
  parsercore_phase0_driver.go:14252	0xa0264c		4c8b5018		MOVQ 0x18(AX), R10															
  parsercore_phase0_driver.go:14252	0xa02650		43c7441a3400000000	MOVL $0x0, 0x34(R10)(R11*1)														
  parsercore_phase0_driver.go:14253	0xa02659		4c8b5020		MOVQ 0x20(AX), R10															
  parsercore_phase0_driver.go:14253	0xa0265d		0f1f00			NOPL 0(AX)																
  parsercore_phase0_driver.go:14253	0xa02660		4c39d1			CMPQ CX, R10																
  parsercore_phase0_driver.go:14253	0xa02663		0f835c070000		JAE 0xa02dc5																
  parsercore_phase0_driver.go:14253	0xa02669		4c8b5018		MOVQ 0x18(AX), R10															
  parsercore_phase0_driver.go:14253	0xa0266d		47894c1a0c		MOVL R9, 0xc(R10)(R11*1)														
  parsercore_phase0_driver.go:14254	0xa02672		4c8b5020		MOVQ 0x20(AX), R10															
  parsercore_phase0_driver.go:14254	0xa02676		4c39d1			CMPQ CX, R10																
  parsercore_phase0_driver.go:14254	0xa02679		0f8264ffffff		JB 0xa025e3																
  parsercore_phase0_driver.go:14254	0xa0267f		90			NOPL																	
  parsercore_phase0_driver.go:14254	0xa02680		e933070000		JMP 0xa02db8																
  parsercore_phase0_driver.go:9189	0xa02685		488b9860240000		MOVQ 0x2460(AX), BX															
  parsercore_phase0_driver.go:14256	0xa0268c		90			NOPL																	
  parsercore_phase0_driver.go:9189	0xa0268d		4885db			TESTQ BX, BX																
  parsercore_phase0_driver.go:9189	0xa02690		7405			JE 0xa02697																
  parsercore_phase0_driver.go:9189	0xa02692		4c8b03			MOVQ 0(BX), R8																
  parsercore_phase0_driver.go:9189	0xa02695		eb03			JMP 0xa0269a																
  parsercore_phase0_driver.go:9189	0xa02697		4531c0			XORL R8, R8																
  parsercore_phase0_driver.go:9189	0xa0269a		4d85c0			TESTQ R8, R8																
  parsercore_phase0_driver.go:9189	0xa0269d		7440			JE 0xa026df																
  parsercore_phase0_driver.go:9192	0xa0269f		488dbc24a8010000	LEAQ 0x1a8(SP), DI															
  parsercore_phase0_driver.go:9192	0xa026a7		488d7fe0		LEAQ -0x20(DI), DI															
  parsercore_phase0_driver.go:9192	0xa026ab		48896c24f0		MOVQ BP, -0x10(SP)															
  parsercore_phase0_driver.go:9192	0xa026b0		488d6c24f0		LEAQ -0x10(SP), BP															
  parsercore_phase0_driver.go:9192	0xa026b5		e8b15ea8ff		CALL 0x48856b																
  parsercore_phase0_driver.go:9192	0xa026ba		488b6d00		MOVQ 0(BP), BP																
  parsercore_phase0_driver.go:9192	0xa026be		488d057be99900		LEAQ 0x99e97b(IP), AX															
  parsercore_phase0_driver.go:9192	0xa026c5		488d8c24a8010000	LEAQ 0x1a8(SP), CX															
  parsercore_phase0_driver.go:9192	0xa026cd		e82eb9a1ff		CALL runtime.mapIterStart(SB)														
  parsercore_phase0_driver.go:9192	0xa026d2		488b942468030000	MOVQ 0x368(SP), DX															
  parsercore_phase0_driver.go:9192	0xa026da		e97b060000		JMP 0xa02d5a																
  parsercore_phase0_driver.go:14257	0xa026df		48ff80d0030000		INCQ 0x3d0(AX)																
  parsercore_phase0_driver.go:14258	0xa026e6		48ff80f8030000		INCQ 0x3f8(AX)																
  parsercore_phase0_driver.go:14259	0xa026ed		80b86104000000		CMPB 0x461(AX), $0x0															
  parsercore_phase0_driver.go:14259	0xa026f4		740e			JE 0xa02704																
  parsercore_phase0_driver.go:14259	0xa026f6		4883782001		CMPQ 0x20(AX), $0x1															
  parsercore_phase0_driver.go:14259	0xa026fb		7e07			JLE 0xa02704																
  parsercore_phase0_driver.go:14260	0xa026fd		48ff8020040000		INCQ 0x420(AX)																
  parsercore_phase0_driver.go:14262	0xa02704		48ff80001a0000		INCQ 0x1a00(AX)																
  parsercore_phase0_driver.go:14263	0xa0270b		833d8e1f7b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parsercore_phase0_driver.go:14263	0xa02712		7425			JE 0xa02739																
  parsercore_phase0_driver.go:14263	0xa02714		488d5830		LEAQ 0x30(AX), BX															
  parsercore_phase0_driver.go:14263	0xa02718		488d0521d6a600		LEAQ 0xa6d621(IP), AX															
  parsercore_phase0_driver.go:14263	0xa0271f		488d8c2418010000	LEAQ 0x118(SP), CX															
  parsercore_phase0_driver.go:14263	0xa02727		e8d4b9a1ff		CALL runtime.wbMove(SB)															
  parsercore_phase0_driver.go:14263	0xa0272c		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14265	0xa02734		448b4c245c		MOVL 0x5c(SP), R9															
  parsercore_phase0_driver.go:14263	0xa02739		0f10842418010000	MOVUPS 0x118(SP), X0															
  parsercore_phase0_driver.go:14263	0xa02741		0f114030		MOVUPS X0, 0x30(AX)															
  parsercore_phase0_driver.go:14263	0xa02745		0f10842428010000	MOVUPS 0x128(SP), X0															
  parsercore_phase0_driver.go:14263	0xa0274d		0f114040		MOVUPS X0, 0x40(AX)															
  parsercore_phase0_driver.go:14263	0xa02751		0f10842438010000	MOVUPS 0x138(SP), X0															
  parsercore_phase0_driver.go:14263	0xa02759		0f114050		MOVUPS X0, 0x50(AX)															
  parsercore_phase0_driver.go:14263	0xa0275d		0f10842448010000	MOVUPS 0x148(SP), X0															
  parsercore_phase0_driver.go:14263	0xa02765		0f114060		MOVUPS X0, 0x60(AX)															
  parsercore_phase0_driver.go:14264	0xa02769		4c8b8424e0000000	MOVQ 0xe0(SP), R8															
  parsercore_phase0_driver.go:14264	0xa02771		4c894070		MOVQ R8, 0x70(AX)															
  parsercore_phase0_driver.go:14264	0xa02775		0f108424e8000000	MOVUPS 0xe8(SP), X0															
  parsercore_phase0_driver.go:14264	0xa0277d		0f114078		MOVUPS X0, 0x78(AX)															
  parsercore_phase0_driver.go:14264	0xa02781		0f108424f8000000	MOVUPS 0xf8(SP), X0															
  parsercore_phase0_driver.go:14264	0xa02789		0f118088000000		MOVUPS X0, 0x88(AX)															
  parsercore_phase0_driver.go:14265	0xa02790		4489889c000000		MOVL R9, 0x9c(AX)															
  parsercore_phase0_driver.go:14266	0xa02797		c680581a000000		MOVB $0x0, 0x1a58(AX)															
  parsercore_phase0_driver.go:4781	0xa0279e		80b86004000000		CMPB 0x460(AX), $0x0															
  parsercore_phase0_driver.go:14271	0xa027a5		7414			JE 0xa027bb																
  parsercore_phase0_driver.go:14276	0xa027a7		488b4c2460		MOVQ 0x60(SP), CX															
  parsercore_phase0_driver.go:14276	0xa027ac		488b542468		MOVQ 0x68(SP), DX															
  parsercore_phase0_driver.go:14276	0xa027b1		488b9c2458010000	MOVQ 0x158(SP), BX															
  parsercore_phase0_driver.go:14271	0xa027b9		eb6a			JMP 0xa02825																
  parsercore_phase0_driver.go:14272	0xa027bb		31c0			XORL AX, AX																
  parsercore_phase0_driver.go:14272	0xa027bd		488b5c2460		MOVQ 0x60(SP), BX															
  parsercore_phase0_driver.go:14272	0xa027c2		31c9			XORL CX, CX																
  parsercore_phase0_driver.go:14272	0xa027c4		4889df			MOVQ BX, DI																
  parsercore_phase0_driver.go:14272	0xa027c7		488d3592129500		LEAQ 0x951292(IP), SI															
  parsercore_phase0_driver.go:14272	0xa027ce		e8edfaa7ff		CALL runtime.growslice(SB)														
  parsercore_phase0_driver.go:14272	0xa027d3		4889842468010000	MOVQ AX, 0x168(SP)															
  parsercore_phase0_driver.go:14272	0xa027db		48899c2488000000	MOVQ BX, 0x88(SP)															
  parsercore_phase0_driver.go:14272	0xa027e3		48898c2490000000	MOVQ CX, 0x90(SP)															
  parsercore_phase0_driver.go:14272	0xa027eb		488b4c2460		MOVQ 0x60(SP), CX															
  parsercore_phase0_driver.go:14272	0xa027f0		48c1e102		SHLQ $0x2, CX																
  parsercore_phase0_driver.go:14272	0xa027f4		488b9c2458010000	MOVQ 0x158(SP), BX															
  parsercore_phase0_driver.go:14272	0xa027fc		0f1f4000		NOPL 0(AX)																
  parsercore_phase0_driver.go:14272	0xa02800		e83b64a8ff		CALL runtime.memmove(SB)														
  parsercore_phase0_driver.go:14276	0xa02805		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14276	0xa0280d		488b8c2488000000	MOVQ 0x88(SP), CX															
  parsercore_phase0_driver.go:14276	0xa02815		488b942490000000	MOVQ 0x90(SP), DX															
  parsercore_phase0_driver.go:14276	0xa0281d		488b9c2468010000	MOVQ 0x168(SP), BX															
  parsercore_phase0_driver.go:14276	0xa02825		488988a8000000		MOVQ CX, 0xa8(AX)															
  parsercore_phase0_driver.go:14276	0xa0282c		488990b0000000		MOVQ DX, 0xb0(AX)															
  parsercore_phase0_driver.go:14276	0xa02833		833d661e7b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parsercore_phase0_driver.go:14276	0xa0283a		7446			JE 0xa02882																
  parsercore_phase0_driver.go:14276	0xa0283c		48899c2468010000	MOVQ BX, 0x168(SP)															
  parsercore_phase0_driver.go:14276	0xa02844		488b90a0000000		MOVQ 0xa0(AX), DX															
  parsercore_phase0_driver.go:14276	0xa0284b		e87056a8ff		CALL runtime.gcWriteBarrier2(SB)													
  parsercore_phase0_driver.go:14276	0xa02850		49891b			MOVQ BX, 0(R11)																
  parsercore_phase0_driver.go:14276	0xa02853		49895308		MOVQ DX, 0x8(R11)															
  parsercore_phase0_driver.go:14277	0xa02857		488d98b8000000		LEAQ 0xb8(AX), BX															
  parsercore_phase0_driver.go:14277	0xa0285e		488d05dbd4a600		LEAQ 0xa6d4db(IP), AX															
  parsercore_phase0_driver.go:14277	0xa02865		488d8c2418010000	LEAQ 0x118(SP), CX															
  parsercore_phase0_driver.go:14277	0xa0286d		e88eb8a1ff		CALL runtime.wbMove(SB)															
  parsercore_phase0_driver.go:14276	0xa02872		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14276	0xa0287a		488b9c2468010000	MOVQ 0x168(SP), BX															
  parsercore_phase0_driver.go:14276	0xa02882		488998a0000000		MOVQ BX, 0xa0(AX)															
  parsercore_phase0_driver.go:14277	0xa02889		0f10842418010000	MOVUPS 0x118(SP), X0															
  parsercore_phase0_driver.go:14277	0xa02891		0f1180b8000000		MOVUPS X0, 0xb8(AX)															
  parsercore_phase0_driver.go:14277	0xa02898		0f10842428010000	MOVUPS 0x128(SP), X0															
  parsercore_phase0_driver.go:14277	0xa028a0		0f1180c8000000		MOVUPS X0, 0xc8(AX)															
  parsercore_phase0_driver.go:14277	0xa028a7		0f10842438010000	MOVUPS 0x138(SP), X0															
  parsercore_phase0_driver.go:14277	0xa028af		0f1180d8000000		MOVUPS X0, 0xd8(AX)															
  parsercore_phase0_driver.go:14277	0xa028b6		0f10842448010000	MOVUPS 0x148(SP), X0															
  parsercore_phase0_driver.go:14277	0xa028be		0f1180e8000000		MOVUPS X0, 0xe8(AX)															
  parsercore_phase0_driver.go:14278	0xa028c5		4c8b8424b8000000	MOVQ 0xb8(SP), R8															
  parsercore_phase0_driver.go:14278	0xa028cd		4c8980f8000000		MOVQ R8, 0xf8(AX)															
  parsercore_phase0_driver.go:14278	0xa028d4		0f108424c0000000	MOVUPS 0xc0(SP), X0															
  parsercore_phase0_driver.go:14278	0xa028dc		0f118000010000		MOVUPS X0, 0x100(AX)															
  parsercore_phase0_driver.go:14278	0xa028e3		0f108424d0000000	MOVUPS 0xd0(SP), X0															
  parsercore_phase0_driver.go:14278	0xa028eb		0f118010010000		MOVUPS X0, 0x110(AX)															
  parsercore_phase0_driver.go:14279	0xa028f2		4c8b8424e0000000	MOVQ 0xe0(SP), R8															
  parsercore_phase0_driver.go:14279	0xa028fa		4c898020010000		MOVQ R8, 0x120(AX)															
  parsercore_phase0_driver.go:14279	0xa02901		0f108424e8000000	MOVUPS 0xe8(SP), X0															
  parsercore_phase0_driver.go:14279	0xa02909		0f118028010000		MOVUPS X0, 0x128(AX)															
  parsercore_phase0_driver.go:14279	0xa02910		0f108424f8000000	MOVUPS 0xf8(SP), X0															
  parsercore_phase0_driver.go:14279	0xa02918		0f118038010000		MOVUPS X0, 0x138(AX)															
  parsercore_phase0_driver.go:14280	0xa0291f		440fb644244b		MOVZX 0x4b(SP), R8															
  parsercore_phase0_driver.go:14280	0xa02925		44888048010000		MOVB R8, 0x148(AX)															
  parsercore_phase0_driver.go:14281	0xa0292c		448b442450		MOVL 0x50(SP), R8															
  parsercore_phase0_driver.go:14281	0xa02931		448980a0010000		MOVL R8, 0x1a0(AX)															
  parsercore_phase0_driver.go:14281	0xa02938		448b442454		MOVL 0x54(SP), R8															
  parsercore_phase0_driver.go:14281	0xa0293d		448980a4010000		MOVL R8, 0x1a4(AX)															
  parsercore_phase0_driver.go:4781	0xa02944		80b86004000000		CMPB 0x460(AX), $0x0															
  parsercore_phase0_driver.go:14285	0xa0294b		0f8584030000		JNE 0xa02cd5																
  parsercore_phase0_driver.go:14286	0xa02951		488b9c2478010000	MOVQ 0x178(SP), BX															
  parsercore_phase0_driver.go:14286	0xa02959		4c8b842470010000	MOVQ 0x170(SP), R8															
  parsercore_phase0_driver.go:14286	0xa02961		488b8c2480010000	MOVQ 0x180(SP), CX															
  parsercore_phase0_driver.go:14286	0xa02969		440f11bc2420020000	MOVUPS X15, 0x220(SP)															
  parsercore_phase0_driver.go:14286	0xa02972		440f11bc2428020000	MOVUPS X15, 0x228(SP)															
  parsercore_phase0_driver.go:14286	0xa0297b		440f11bc2438020000	MOVUPS X15, 0x238(SP)															
  parsercore_phase0_driver.go:984	0xa02984		4885db			TESTQ BX, BX																
  parsercore_phase0_driver.go:984	0xa02987		752f			JNE 0xa029b8																
  parsercore_phase0_driver.go:14286	0xa02989		4c8b05b0207b02		MOVQ github.com/odvcencio/gotreesitter.parserCoreEmptyCheckpoint(SB), R8								
  parsercore_phase0_driver.go:14286	0xa02990		4c89842420020000	MOVQ R8, 0x220(SP)															
  parsercore_phase0_driver.go:14286	0xa02998		0f1005a9207b02		MOVUPS github.com/odvcencio/gotreesitter.parserCoreEmptyCheckpoint+8(SB), X0								
  parsercore_phase0_driver.go:14286	0xa0299f		0f11842428020000	MOVUPS X0, 0x228(SP)															
  parsercore_phase0_driver.go:14286	0xa029a7		0f1005aa207b02		MOVUPS github.com/odvcencio/gotreesitter.parserCoreEmptyCheckpoint+24(SB), X0								
  parsercore_phase0_driver.go:14286	0xa029ae		0f11842438020000	MOVUPS X0, 0x238(SP)															
  parsercore_phase0_driver.go:14286	0xa029b6		eb7c			JMP 0xa02a34																
  parsercore_phase0_driver.go:14286	0xa029b8		48899c24a0000000	MOVQ BX, 0xa0(SP)															
  parsercore_phase0_driver.go:987	0xa029c0		4c89c0			MOVQ R8, AX																
  parsercore_phase0_driver.go:987	0xa029c3		e8f878b8ff		CALL crypto/sha256.Sum256(SB)														
  parsercore_phase0_driver.go:987	0xa029c8		0f100424		MOVUPS 0(SP), X0															
  parsercore_phase0_driver.go:987	0xa029cc		0f118424e0000000	MOVUPS X0, 0xe0(SP)															
  parsercore_phase0_driver.go:987	0xa029d4		0f10442410		MOVUPS 0x10(SP), X0															
  parsercore_phase0_driver.go:987	0xa029d9		0f118424f0000000	MOVUPS X0, 0xf0(SP)															
  parsercore_phase0_driver.go:14286	0xa029e1		440f11bc2420020000	MOVUPS X15, 0x220(SP)															
  parsercore_phase0_driver.go:14286	0xa029ea		440f11bc2428020000	MOVUPS X15, 0x228(SP)															
  parsercore_phase0_driver.go:14286	0xa029f3		440f11bc2438020000	MOVUPS X15, 0x238(SP)															
  parsercore_phase0_driver.go:987	0xa029fc		488b9424a0000000	MOVQ 0xa0(SP), DX															
  parsercore_phase0_driver.go:987	0xa02a04		4889942420020000	MOVQ DX, 0x220(SP)															
  parsercore_phase0_driver.go:987	0xa02a0c		0f108424e0000000	MOVUPS 0xe0(SP), X0															
  parsercore_phase0_driver.go:987	0xa02a14		0f11842428020000	MOVUPS X0, 0x228(SP)															
  parsercore_phase0_driver.go:987	0xa02a1c		0f108424f0000000	MOVUPS 0xf0(SP), X0															
  parsercore_phase0_driver.go:987	0xa02a24		0f11842438020000	MOVUPS X0, 0x238(SP)															
  parsercore_phase0_driver.go:14286	0xa02a2c		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14286	0xa02a34		4c8b842420020000	MOVQ 0x220(SP), R8															
  parsercore_phase0_driver.go:14286	0xa02a3c		4c898050010000		MOVQ R8, 0x150(AX)															
  parsercore_phase0_driver.go:14286	0xa02a43		0f10842428020000	MOVUPS 0x228(SP), X0															
  parsercore_phase0_driver.go:14286	0xa02a4b		0f118058010000		MOVUPS X0, 0x158(AX)															
  parsercore_phase0_driver.go:14286	0xa02a52		0f10842438020000	MOVUPS 0x238(SP), X0															
  parsercore_phase0_driver.go:14286	0xa02a5a		0f118068010000		MOVUPS X0, 0x168(AX)															
  parsercore_phase0_driver.go:14287	0xa02a61		488b9c2490010000	MOVQ 0x190(SP), BX															
  parsercore_phase0_driver.go:14287	0xa02a69		4c8b842488010000	MOVQ 0x188(SP), R8															
  parsercore_phase0_driver.go:14287	0xa02a71		488b8c2498010000	MOVQ 0x198(SP), CX															
  parsercore_phase0_driver.go:14287	0xa02a79		440f11bc2420020000	MOVUPS X15, 0x220(SP)															
  parsercore_phase0_driver.go:14287	0xa02a82		440f11bc2428020000	MOVUPS X15, 0x228(SP)															
  parsercore_phase0_driver.go:14287	0xa02a8b		440f11bc2438020000	MOVUPS X15, 0x238(SP)															
  parsercore_phase0_driver.go:984	0xa02a94		4885db			TESTQ BX, BX																
  parsercore_phase0_driver.go:984	0xa02a97		752f			JNE 0xa02ac8																
  parsercore_phase0_driver.go:14287	0xa02a99		4c8b05a01f7b02		MOVQ github.com/odvcencio/gotreesitter.parserCoreEmptyCheckpoint(SB), R8								
  parsercore_phase0_driver.go:14287	0xa02aa0		4c89842420020000	MOVQ R8, 0x220(SP)															
  parsercore_phase0_driver.go:14287	0xa02aa8		0f1005991f7b02		MOVUPS github.com/odvcencio/gotreesitter.parserCoreEmptyCheckpoint+8(SB), X0								
  parsercore_phase0_driver.go:14287	0xa02aaf		0f11842428020000	MOVUPS X0, 0x228(SP)															
  parsercore_phase0_driver.go:14287	0xa02ab7		0f10059a1f7b02		MOVUPS github.com/odvcencio/gotreesitter.parserCoreEmptyCheckpoint+24(SB), X0								
  parsercore_phase0_driver.go:14287	0xa02abe		0f11842438020000	MOVUPS X0, 0x238(SP)															
  parsercore_phase0_driver.go:14287	0xa02ac6		eb7c			JMP 0xa02b44																
  parsercore_phase0_driver.go:14287	0xa02ac8		48899c2498000000	MOVQ BX, 0x98(SP)															
  parsercore_phase0_driver.go:987	0xa02ad0		4c89c0			MOVQ R8, AX																
  parsercore_phase0_driver.go:987	0xa02ad3		e8e877b8ff		CALL crypto/sha256.Sum256(SB)														
  parsercore_phase0_driver.go:987	0xa02ad8		0f100424		MOVUPS 0(SP), X0															
  parsercore_phase0_driver.go:987	0xa02adc		0f118424e0000000	MOVUPS X0, 0xe0(SP)															
  parsercore_phase0_driver.go:987	0xa02ae4		0f10442410		MOVUPS 0x10(SP), X0															
  parsercore_phase0_driver.go:987	0xa02ae9		0f118424f0000000	MOVUPS X0, 0xf0(SP)															
  parsercore_phase0_driver.go:14287	0xa02af1		440f11bc2420020000	MOVUPS X15, 0x220(SP)															
  parsercore_phase0_driver.go:14287	0xa02afa		440f11bc2428020000	MOVUPS X15, 0x228(SP)															
  parsercore_phase0_driver.go:14287	0xa02b03		440f11bc2438020000	MOVUPS X15, 0x238(SP)															
  parsercore_phase0_driver.go:987	0xa02b0c		488b942498000000	MOVQ 0x98(SP), DX															
  parsercore_phase0_driver.go:987	0xa02b14		4889942420020000	MOVQ DX, 0x220(SP)															
  parsercore_phase0_driver.go:987	0xa02b1c		0f108424e0000000	MOVUPS 0xe0(SP), X0															
  parsercore_phase0_driver.go:987	0xa02b24		0f11842428020000	MOVUPS X0, 0x228(SP)															
  parsercore_phase0_driver.go:987	0xa02b2c		0f108424f0000000	MOVUPS 0xf0(SP), X0															
  parsercore_phase0_driver.go:987	0xa02b34		0f11842438020000	MOVUPS X0, 0x238(SP)															
  parsercore_phase0_driver.go:14287	0xa02b3c		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14287	0xa02b44		4c8b842420020000	MOVQ 0x220(SP), R8															
  parsercore_phase0_driver.go:14287	0xa02b4c		4c898078010000		MOVQ R8, 0x178(AX)															
  parsercore_phase0_driver.go:14287	0xa02b53		0f10842428020000	MOVUPS 0x228(SP), X0															
  parsercore_phase0_driver.go:14287	0xa02b5b		0f118080010000		MOVUPS X0, 0x180(AX)															
  parsercore_phase0_driver.go:14287	0xa02b62		0f10842438020000	MOVUPS 0x238(SP), X0															
  parsercore_phase0_driver.go:14287	0xa02b6a		0f118090010000		MOVUPS X0, 0x190(AX)															
  parsercore_phase0_driver.go:14288	0xa02b71		4c8b80a0000000		MOVQ 0xa0(AX), R8															
  parsercore_phase0_driver.go:14288	0xa02b78		488db0a8000000		LEAQ 0xa8(AX), SI															
  parsercore_phase0_driver.go:14288	0xa02b7f		4c89842450020000	MOVQ R8, 0x250(SP)															
  parsercore_phase0_driver.go:14288	0xa02b87		488dbc2458020000	LEAQ 0x258(SP), DI															
  parsercore_phase0_driver.go:14288	0xa02b8f		660f1f840000000000	NOPW 0(AX)(AX*1)															
  parsercore_phase0_driver.go:14288	0xa02b98		0f1f840000000000	NOPL 0(AX)(AX*1)															
  parsercore_phase0_driver.go:14288	0xa02ba0		48896c24f0		MOVQ BP, -0x10(SP)															
  parsercore_phase0_driver.go:14288	0xa02ba5		488d6c24f0		LEAQ -0x10(SP), BP															
  parsercore_phase0_driver.go:14288	0xa02baa		e8915ca8ff		CALL 0x488840																
  parsercore_phase0_driver.go:14288	0xa02baf		488b6d00		MOVQ 0(BP), BP																
  parsercore_phase0_driver.go:14288	0xa02bb3		4c8b80000c0000		MOVQ 0xc00(AX), R8															
  parsercore_phase0_driver.go:14288	0xa02bba		498b88a0000000		MOVQ 0xa0(R8), CX															
  parsercore_phase0_driver.go:14288	0xa02bc1		498b9898000000		MOVQ 0x98(R8), BX															
  parsercore_phase0_driver.go:14288	0xa02bc8		48ffc3			INCQ BX																	
  parsercore_phase0_driver.go:14288	0xa02bcb		4d8b8890000000		MOVQ 0x90(R8), R9															
  parsercore_phase0_driver.go:14288	0xa02bd2		4839d9			CMPQ CX, BX																
  parsercore_phase0_driver.go:14288	0xa02bd5		735c			JAE 0xa02c33																
  parsercore_phase0_driver.go:14288	0xa02bd7		4c89842410020000	MOVQ R8, 0x210(SP)															
  parsercore_phase0_driver.go:14288	0xa02bdf		4c89c8			MOVQ R9, AX																
  parsercore_phase0_driver.go:14288	0xa02be2		bf01000000		MOVL $0x1, DI																
  parsercore_phase0_driver.go:14288	0xa02be7		488d35529ca400		LEAQ 0xa49c52(IP), SI															
  parsercore_phase0_driver.go:14288	0xa02bee		e8cdf6a7ff		CALL runtime.growslice(SB)														
  parsercore_phase0_driver.go:14288	0xa02bf3		488b942410020000	MOVQ 0x210(SP), DX															
  parsercore_phase0_driver.go:14288	0xa02bfb		48898aa0000000		MOVQ CX, 0xa0(DX)															
  parsercore_phase0_driver.go:14288	0xa02c02		833d971a7b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parsercore_phase0_driver.go:14288	0xa02c09		7413			JE 0xa02c1e																
  parsercore_phase0_driver.go:14288	0xa02c0b		4c8b8290000000		MOVQ 0x90(DX), R8															
  parsercore_phase0_driver.go:14288	0xa02c12		e8a952a8ff		CALL runtime.gcWriteBarrier2(SB)													
  parsercore_phase0_driver.go:14288	0xa02c17		498903			MOVQ AX, 0(R11)																
  parsercore_phase0_driver.go:14288	0xa02c1a		4d894308		MOVQ R8, 0x8(R11)															
  parsercore_phase0_driver.go:14288	0xa02c1e		48898290000000		MOVQ AX, 0x90(DX)															
  parsercore_phase0_driver.go:14288	0xa02c25		4989d0			MOVQ DX, R8																
  parsercore_phase0_driver.go:14288	0xa02c28		4989c1			MOVQ AX, R9																
  parsercore_phase0_driver.go:14294	0xa02c2b		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14288	0xa02c33		49899898000000		MOVQ BX, 0x98(R8)															
  parsercore_phase0_driver.go:14288	0xa02c3a		4989d8			MOVQ BX, R8																
  parsercore_phase0_driver.go:14288	0xa02c3d		48c1e308		SHLQ $0x8, BX																
  parsercore_phase0_driver.go:14288	0xa02c41		4e8d04c3		LEAQ 0(BX)(R8*8), R8															
  parsercore_phase0_driver.go:14288	0xa02c45		4b8d1c08		LEAQ 0(R8)(R9*1), BX															
  parsercore_phase0_driver.go:14288	0xa02c49		488d9bf8feffff		LEAQ 0xfffffef8(BX), BX															
  parsercore_phase0_driver.go:14288	0xa02c50		833d491a7b0200		CMPL runtime.writeBarrier(SB), $0x0													
  parsercore_phase0_driver.go:14288	0xa02c57		743c			JE 0xa02c95																
  parsercore_phase0_driver.go:14288	0xa02c59		4c898c2408020000	MOVQ R9, 0x208(SP)															
  parsercore_phase0_driver.go:14288	0xa02c61		4c89842410010000	MOVQ R8, 0x110(SP)															
  parsercore_phase0_driver.go:14288	0xa02c69		488d05d09ba400		LEAQ 0xa49bd0(IP), AX															
  parsercore_phase0_driver.go:14288	0xa02c70		488d8c2450020000	LEAQ 0x250(SP), CX															
  parsercore_phase0_driver.go:14288	0xa02c78		e883b4a1ff		CALL runtime.wbMove(SB)															
  parsercore_phase0_driver.go:14294	0xa02c7d		488b842468030000	MOVQ 0x368(SP), AX															
  parsercore_phase0_driver.go:14288	0xa02c85		4c8b842410010000	MOVQ 0x110(SP), R8															
  parsercore_phase0_driver.go:14288	0xa02c8d		4c8b8c2408020000	MOVQ 0x208(SP), R9															
  parsercore_phase0_driver.go:14288	0xa02c95		4b8d3c08		LEAQ 0(R8)(R9*1), DI															
  parsercore_phase0_driver.go:14288	0xa02c99		488dbf00ffffff		LEAQ 0xffffff00(DI), DI															
  parsercore_phase0_driver.go:14288	0xa02ca0		488b8c2450020000	MOVQ 0x250(SP), CX															
  parsercore_phase0_driver.go:14288	0xa02ca8		4b898c08f8feffff	MOVQ CX, 0xfffffef8(R8)(R9*1)														
  parsercore_phase0_driver.go:14288	0xa02cb0		488db42458020000	LEAQ 0x258(SP), SI															
  parsercore_phase0_driver.go:14288	0xa02cb8		0f1f840000000000	NOPL 0(AX)(AX*1)															
  parsercore_phase0_driver.go:14288	0xa02cc0		48896c24f0		MOVQ BP, -0x10(SP)															
  parsercore_phase0_driver.go:14288	0xa02cc5		488d6c24f0		LEAQ -0x10(SP), BP															
  parsercore_phase0_driver.go:14288	0xa02cca		e8715ba8ff		CALL 0x488840																
  parsercore_phase0_driver.go:14288	0xa02ccf		488b6d00		MOVQ 0(BP), BP																
  parsercore_phase0_driver.go:14288	0xa02cd3		eb30			JMP 0xa02d05																
  parsercore_phase0_driver.go:14291	0xa02cd5		440f11b850010000	MOVUPS X15, 0x150(AX)															
  parsercore_phase0_driver.go:14291	0xa02cdd		440f11b858010000	MOVUPS X15, 0x158(AX)															
  parsercore_phase0_driver.go:14291	0xa02ce5		440f11b868010000	MOVUPS X15, 0x168(AX)															
  parsercore_phase0_driver.go:14292	0xa02ced		440f11b878010000	MOVUPS X15, 0x178(AX)															
  parsercore_phase0_driver.go:14292	0xa02cf5		440f11b880010000	MOVUPS X15, 0x180(AX)															
  parsercore_phase0_driver.go:14292	0xa02cfd		440f11b890010000	MOVUPS X15, 0x190(AX)															
  parsercore_phase0_driver.go:14294	0xa02d05		488b9078230000		MOVQ 0x2378(AX), DX															
  parsercore_phase0_driver.go:14294	0xa02d0c		4885d2			TESTQ DX, DX																
  parsercore_phase0_driver.go:14294	0xa02d0f		7418			JE 0xa02d29																
  parsercore_phase0_driver.go:14295	0xa02d11		488b0a			MOVQ 0(DX), CX																
  parsercore_phase0_driver.go:14295	0xa02d14		ffd1			CALL CX																	
  parsercore_phase0_driver.go:14296	0xa02d16		4885db			TESTQ BX, BX																
  parsercore_phase0_driver.go:14296	0xa02d19		751b			JNE 0xa02d36																
  parsercore_phase0_driver.go:14299	0xa02d1b		488b8c2468030000	MOVQ 0x368(SP), CX															
  parsercore_phase0_driver.go:14299	0xa02d23		888188230000		MOVB AL, 0x2388(CX)															
  parsercore_phase0_driver.go:14301	0xa02d29		31c0			XORL AX, AX																
  parsercore_phase0_driver.go:14301	0xa02d2b		31db			XORL BX, BX																
  parsercore_phase0_driver.go:14301	0xa02d2d		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14301	0xa02d34		5d			POPQ BP																	
  parsercore_phase0_driver.go:14301	0xa02d35		c3			RET																	
  parsercore_phase0_driver.go:14297	0xa02d36		4889d8			MOVQ BX, AX																
  parsercore_phase0_driver.go:14297	0xa02d39		4889cb			MOVQ CX, BX																
  parsercore_phase0_driver.go:14297	0xa02d3c		4881c458030000		ADDQ $0x358, SP																
  parsercore_phase0_driver.go:14297	0xa02d43		5d			POPQ BP																	
  parsercore_phase0_driver.go:14297	0xa02d44		c3			RET																	
  parsercore_phase0_driver.go:9192	0xa02d45		488d8424a8010000	LEAQ 0x1a8(SP), AX															
  parsercore_phase0_driver.go:9192	0xa02d4d		e80eb3a1ff		CALL runtime.mapIterNext(SB)														
  parsercore_phase0_driver.go:9194	0xa02d52		488b942468030000	MOVQ 0x368(SP), DX															
  parsercore_phase0_driver.go:9192	0xa02d5a		4c8b8424a8010000	MOVQ 0x1a8(SP), R8															
  parsercore_phase0_driver.go:9192	0xa02d62		4d85c0			TESTQ R8, R8																
  parsercore_phase0_driver.go:9192	0xa02d65		7424			JE 0xa02d8b																
  parsercore_phase0_driver.go:9192	0xa02d67		498b08			MOVQ 0(R8), CX																
  parsercore_phase0_driver.go:9194	0xa02d6a		488b7218		MOVQ 0x18(DX), SI															
  parsercore_phase0_driver.go:9194	0xa02d6e		488b7a20		MOVQ 0x20(DX), DI															
  parsercore_phase0_driver.go:9194	0xa02d72		31c0			XORL AX, AX																
  parsercore_phase0_driver.go:9194	0xa02d74		eb2a			JMP 0xa02da0																
  parsercore_phase0_driver.go:9201	0xa02d76		488b9a60240000		MOVQ 0x2460(DX), BX															
  parsercore_phase0_driver.go:9201	0xa02d7d		488d05bce29900		LEAQ 0x99e2bc(IP), AX															
  parsercore_phase0_driver.go:9201	0xa02d84		e8b7cba0ff		CALL runtime.mapdelete_fast64(SB)													
  parsercore_phase0_driver.go:9201	0xa02d89		ebba			JMP 0xa02d45																
  parsercore_phase0_driver.go:14257	0xa02d8b		4889d0			MOVQ DX, AX																
  parsercore_phase0_driver.go:14265	0xa02d8e		448b4c245c		MOVL 0x5c(SP), R9															
  parsercore_phase0_driver.go:9192	0xa02d93		e947f9ffff		JMP 0xa026df																
  parsercore_phase0_driver.go:9194	0xa02d98		48ffc0			INCQ AX																	
  parsercore_phase0_driver.go:9194	0xa02d9b		0f1f440000		NOPL 0(AX)(AX*1)															
  parsercore_phase0_driver.go:9194	0xa02da0		4839f8			CMPQ AX, DI																
  parsercore_phase0_driver.go:9194	0xa02da3		7dd1			JGE 0xa02d76																
  parsercore_phase0_driver.go:9195	0xa02da5		4c8d0480		LEAQ 0(AX)(AX*4), R8															
  parsercore_phase0_driver.go:9195	0xa02da9		49c1e004		SHLQ $0x4, R8																
  parsercore_phase0_driver.go:9195	0xa02dad		4e8b0406		MOVQ 0(SI)(R8*1), R8															
  parsercore_phase0_driver.go:9195	0xa02db1		4939c8			CMPQ R8, CX																
  parsercore_phase0_driver.go:9195	0xa02db4		75e2			JNE 0xa02d98																
  parsercore_phase0_driver.go:9195	0xa02db6		eb8d			JMP 0xa02d45																
  parsercore_phase0_driver.go:14254	0xa02db8		4889c8			MOVQ CX, AX																
  parsercore_phase0_driver.go:14254	0xa02dbb		4c89d1			MOVQ R10, CX																
  parsercore_phase0_driver.go:14254	0xa02dbe		6690			NOPW																	
  parsercore_phase0_driver.go:14254	0xa02dc0		e89b54a8ff		CALL runtime.panicIndex(SB)														
  parsercore_phase0_driver.go:14253	0xa02dc5		4889c8			MOVQ CX, AX																
  parsercore_phase0_driver.go:14253	0xa02dc8		4c89d1			MOVQ R10, CX																
  parsercore_phase0_driver.go:14253	0xa02dcb		e89054a8ff		CALL runtime.panicIndex(SB)														
  parsercore_phase0_driver.go:14252	0xa02dd0		4889c8			MOVQ CX, AX																
  parsercore_phase0_driver.go:14252	0xa02dd3		4c89d1			MOVQ R10, CX																
  parsercore_phase0_driver.go:14252	0xa02dd6		e88554a8ff		CALL runtime.panicIndex(SB)														
  parsercore_phase0_driver.go:14251	0xa02ddb		4889c8			MOVQ CX, AX																
  parsercore_phase0_driver.go:14251	0xa02dde		4c89d1			MOVQ R10, CX																
  parsercore_phase0_driver.go:14251	0xa02de1		e87a54a8ff		CALL runtime.panicIndex(SB)														
  parsercore_phase0_driver.go:14250	0xa02de6		4889c8			MOVQ CX, AX																
  parsercore_phase0_driver.go:14250	0xa02de9		4c89d1			MOVQ R10, CX																
  parsercore_phase0_driver.go:14250	0xa02dec		e86f54a8ff		CALL runtime.panicIndex(SB)														
  parsercore_phase0_driver.go:14187	0xa02df1		31c0			XORL AX, AX																
  parsercore_phase0_driver.go:14187	0xa02df3		4889c1			MOVQ AX, CX																
  parsercore_phase0_driver.go:14187	0xa02df6		e86554a8ff		CALL runtime.panicIndex(SB)														
  parsercore_phase0_driver.go:14157	0xa02dfb		4889c8			MOVQ CX, AX																
  parsercore_phase0_driver.go:14157	0xa02dfe		4889f1			MOVQ SI, CX																
  parsercore_phase0_driver.go:14157	0xa02e01		e85a54a8ff		CALL runtime.panicIndex(SB)														
  parsercore_phase0_driver.go:14157	0xa02e06		90			NOPL																	
  parsercore_phase0_driver.go:14137	0xa02e07		4889442408		MOVQ AX, 0x8(SP)															
  parsercore_phase0_driver.go:14137	0xa02e0c		885c2410		MOVB BL, 0x10(SP)															
  parsercore_phase0_driver.go:14137	0xa02e10		e84b33a8ff		CALL runtime.morestack_noctxt.abi0(SB)													
  parsercore_phase0_driver.go:14137	0xa02e15		488b442408		MOVQ 0x8(SP), AX															
  parsercore_phase0_driver.go:14137	0xa02e1a		0fb65c2410		MOVZX 0x10(SP), BX															
  parsercore_phase0_driver.go:14137	0xa02e1f		90			NOPL																	
  parsercore_phase0_driver.go:14137	0xa02e20		e99beeffff		JMP github.com/odvcencio/gotreesitter.(*diagnosticParserCoreGenericScheduler).elect(SB)							
