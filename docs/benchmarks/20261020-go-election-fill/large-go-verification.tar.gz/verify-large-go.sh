#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/large-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /candidate/cgo_harness
go test . -tags gts_parsercorephase0,treesitter_c_parity -run '^TestCompactLineageLargeGoLockedC$' -count=1 -v -timeout=8m > /evidence/large-go-c-verified.log 2>&1
python3 - <<'CHECK'
from pathlib import Path
s=Path('/evidence/large-go-c-verified.log').read_text()
assert '=== RUN   TestCompactLineageLargeGoLockedC' in s and '--- PASS: TestCompactLineageLargeGoLockedC' in s
assert '--- SKIP:' not in s and 'no tests to run' not in s and '--- FAIL:' not in s
Path('/evidence/large-go-verified-complete.txt').write_text('complete\n')
CHECK
