#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/build.log 2>&1
for case in go yaml yaml_legacy; do
 GTS_STORAGE_CASE="$case" /evidence/root.test -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=8m > "/evidence/$case.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
