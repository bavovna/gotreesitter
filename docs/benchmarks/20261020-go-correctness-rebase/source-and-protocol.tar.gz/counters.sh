#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/counter-overlay.json'
cd /candidate
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v -timeout=8m > /evidence/canonical-work.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/counter ./cmd/perfcounterledger > /evidence/counter-build.log 2>&1
/evidence/counter --write --output /evidence/ledger.json > /evidence/ledger.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/counter --langs yaml > /evidence/owned-yaml-ledger.json 2> /evidence/owned-yaml-ledger.log
printf 'complete\n' > /evidence/counters-complete.txt
