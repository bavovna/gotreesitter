package parsercorephase0

import (
	"errors"
	"unsafe"
)

// SharedDFATerminalSource authenticates the complete token elected by the
// adapter's actual internal DFA source. An owner-scoped dispatch must be
// active; matching scalar token values alone must never return true.
type SharedDFATerminalSource interface {
	SharedDFATerminalOrigin(Token) uint32
}

// SharedDFATerminalSourceAdapter keeps the cross-package interface on the
// internal side. A stable caller-owned context and method expression need no
// callback closure or per-dispatch allocation. Empty adapters issue no origin.
type SharedDFATerminalSourceAdapter[T any] struct {
	Source *T
	Origin func(*T, Token) uint32
}

func (a *SharedDFATerminalSourceAdapter[T]) SharedDFATerminalOrigin(tok Token) uint32 {
	if a == nil || a.Source == nil || a.Origin == nil {
		return 0
	}
	return a.Origin(a.Source, tok)
}

// Receipt origins are issued by one actual elected DFA read, not derived
// from token values, lexer-mode equality or a hash. The source is fixed by the
// fresh owner; its sequence cannot cross owner or reset generations.
type dfaTerminalOriginReceipt struct {
	payload SubtreeID
	origin  uint32
}

type freshDFATerminalIdentity struct {
	source     SharedDFATerminalSource
	owner      SchedulerTransactionToken
	generation uint64
	certified  []dfaTerminalOriginReceipt
}

// BindFreshDFATerminalSourceOwned binds one source to this fresh owner and
// reset generation, before any payload exists. No transaction, nested binding
// or later source replacement can issue receipts for existing payloads.
func (c *Core) BindFreshDFATerminalSourceOwned(owner SchedulerTransactionToken, source SharedDFATerminalSource) (err error) {
	if err = c.beginSchedulerOwned(owner); err != nil {
		return err
	}
	defer c.recoverSchedulerOwnedPanic(owner)
	if !c.schedulerFrame.fresh || source == nil || len(c.subtrees) != 0 || c.freshDFATerminalIdentityActive() {
		return c.finishSchedulerOwned(owner, errors.New("parser-core phase zero: DFA identity source requires one empty fresh session"))
	}
	if c.dfaTerminalIdentity == nil {
		c.dfaTerminalIdentity = new(freshDFATerminalIdentity)
	}
	state := c.dfaTerminalIdentity
	clear(state.certified)
	state.certified = state.certified[:0]
	state.source, state.owner, state.generation = source, owner, c.resetGeneration
	return c.finishSchedulerOwned(owner, nil)
}

func (c *Core) freshDFATerminalIdentityActive() bool {
	state := c.dfaTerminalIdentity
	return state != nil && state.source != nil && c.schedulerFrame.active && c.schedulerFrame.fresh &&
		state.owner.owner == c && state.owner.epoch == c.schedulerFrame.epoch &&
		state.owner.transaction == c.schedulerFrame.mark.transaction && state.generation == c.resetGeneration
}

func (c *Core) clearFreshDFATerminalIdentity() {
	if state := c.dfaTerminalIdentity; state != nil {
		state.source = nil
		state.owner = SchedulerTransactionToken{}
		state.generation = 0
		clear(state.certified)
		state.certified = state.certified[:0]
	}
}

func (c *Core) recordFreshDFATerminalIdentity(id SubtreeID, record subtreeRecord, prefix uint16) {
	if !c.freshDFATerminalIdentityActive() || record.external || record.missing || record.symbol == 0 || record.symbol >= ErrorRegionSymbol-1 {
		return
	}
	token := Token{Symbol: record.symbol, StartByte: record.startByte, EndByte: record.endByte, Extra: record.extra, LexerSkippedPrefixLength: prefix}
	state := c.dfaTerminalIdentity
	origin := state.source.SharedDFATerminalOrigin(token)
	if origin == 0 {
		return
	}
	state.certified = append(state.certified, dfaTerminalOriginReceipt{payload: id, origin: origin})
}

func (c *Core) freshDFATerminalOrigin(id SubtreeID) uint32 {
	if id == 0 || !c.freshDFATerminalIdentityActive() {
		return 0
	}
	rows := c.dfaTerminalIdentity.certified
	low, high := 0, len(rows)
	for low < high {
		mid := low + (high-low)/2
		if rows[mid].payload < id {
			low = mid + 1
		} else {
			high = mid
		}
	}
	if low == len(rows) || rows[low].payload != id {
		return 0
	}
	return rows[low].origin
}

func (c *Core) freshDFATerminalIdentityExact(id SubtreeID) bool {
	return c.freshDFATerminalOrigin(id) != 0
}

func (c *Core) freshDFATerminalIdentityFootprintBytes() uint64 {
	if c.dfaTerminalIdentity == nil {
		return 0
	}
	return uint64(unsafe.Sizeof(*c.dfaTerminalIdentity)) + uint64(cap(c.dfaTerminalIdentity.certified))*8
}
