package parsercorephase0

// VersionDynamicPrecedence reads C's stored per-version running value. It can
// differ from the maximum surviving path score after link replacement or a
// discarded contribution. Reading it grants no merge or election authority.
func (c *Core) VersionDynamicPrecedence(head Head) (int64, error) {
	if _, err := c.node(head.Node); err != nil {
		return 0, err
	}
	return c.storedNodePrecedence(head.Node)
}
