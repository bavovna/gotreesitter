package parsercorephase0

import (
	"errors"
	"testing"
)

type testSharedDFASource struct {
	allow  bool
	origin uint32
}

func (s *testSharedDFASource) AuthenticatesSharedDFATerminal(tok Token) bool {
	return s.allow && tok.Symbol == 3 && tok.StartByte == 0 && tok.EndByte == 1 && !tok.External
}

func (s *testSharedDFASource) SharedDFATerminalOrigin(tok Token) uint32 {
	if !s.AuthenticatesSharedDFATerminal(tok) {
		return 0
	}
	if s.origin != 0 {
		return s.origin
	}
	return 1
}

func TestFreshDFATerminalIdentitySelectionAndScope(t *testing.T) {
	c := newCSelectionCompareTestCore(t)
	source := &testSharedDFASource{allow: true}
	var leaf SubtreeID
	err := c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
		if err := c.BindFreshDFATerminalSourceOwned(owner, source); err != nil {
			return err
		}
		var err error
		leaf, err = c.appendAuthenticatedTerminal(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, 0)
		if err != nil {
			return err
		}
		if !c.freshDFATerminalIdentityExact(leaf) {
			t.Fatal("actual source terminal was not certified")
		}
		left, right := reductionSelectionPair(t, c, leaf, leaf)
		cmp, selected, err := c.compareReconvergedReductionChildren(left, right)
		if err != nil || !selected || cmp != 1 {
			t.Fatalf("selection %d %t %v", cmp, selected, err)
		}
		if c.freshDFATerminalIdentityFootprintBytes() == 0 {
			t.Fatal("receipt capacity is not budgeted")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if c.freshDFATerminalIdentityExact(leaf) || c.dfaTerminalIdentity.source != nil {
		t.Fatal("source or receipt escaped its owner")
	}
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	if c.freshDFATerminalIdentityExact(leaf) {
		t.Fatal("receipt survived reset")
	}
}

func TestFreshDFATerminalIdentityRejectsUnprovenOrDifferentOrigins(t *testing.T) {
	for _, allow := range []bool{false, true} {
		c := newCSelectionCompareTestCore(t)
		source := &testSharedDFASource{allow: allow}
		err := c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
			if err := c.BindFreshDFATerminalSourceOwned(owner, source); err != nil {
				return err
			}
			a, e := c.appendAuthenticatedTerminal(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, 0)
			if e != nil {
				return e
			}
			source.origin = 2
			b, e := c.appendAuthenticatedTerminal(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, 0)
			if e != nil {
				return e
			}
			left, right := reductionSelectionPair(t, c, a, b)
			if _, selected, e := c.compareReconvergedReductionChildren(left, right); e != nil || selected {
				t.Fatalf("allow %t: different identities selected: %t %v", allow, selected, e)
			}
			if !allow {
				left, right = reductionSelectionPair(t, c, a, a)
				if _, selected, e := c.compareReconvergedReductionChildren(left, right); e != nil || selected {
					t.Fatal("unproven identical IDs selected")
				}
			}
			return nil
		})
		if err != nil {
			t.Fatal(err)
		}
	}
}

func TestFreshDFATerminalIdentityRejectsRebindingAndReleasesOnFailure(t *testing.T) {
	c := newCSelectionCompareTestCore(t)
	source := &testSharedDFASource{allow: true}
	err := c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
		if e := c.BindFreshDFATerminalSourceOwned(owner, source); e != nil {
			return e
		}
		if e := c.BindFreshDFATerminalSourceOwned(owner, source); e == nil {
			t.Fatal("source replacement succeeded")
		}
		return nil
	})
	if err == nil {
		t.Fatal("ignored source-binding failure did not poison session")
	}
	if c.dfaTerminalIdentity != nil {
		t.Fatal("failed source retained capacity")
	}
	sentinel := errors.New("stop")
	err = c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
		if e := c.BindFreshDFATerminalSourceOwned(owner, source); e != nil {
			return e
		}
		_, e := c.appendAuthenticatedTerminal(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, 0)
		if e != nil {
			return e
		}
		return sentinel
	})
	if !errors.Is(err, sentinel) || c.dfaTerminalIdentity != nil {
		t.Fatal("failed parse retained a source or proof")
	}
}

func TestFreshDFATerminalIdentityDoesNotCertifyGenericPublication(t *testing.T) {
	c := newCSelectionCompareTestCore(t)
	if err := c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
		if err := c.BindFreshDFATerminalSourceOwned(owner, &testSharedDFASource{allow: true}); err != nil {
			return err
		}
		leaf, err := c.appendSubtree(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, nil, nil, nil)
		if err != nil {
			return err
		}
		if c.freshDFATerminalIdentityExact(leaf) {
			t.Fatal("generic record inherited an elected-token receipt")
		}
		left, right := reductionSelectionPair(t, c, leaf, leaf)
		if _, selected, err := c.compareReconvergedReductionChildren(left, right); err != nil || selected {
			t.Fatal("generic publication authorized child selection")
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

func TestFreshDFATerminalIdentityRejectsLateOrTransactionalBinding(t *testing.T) {
	for _, kind := range []string{"late", "transaction"} {
		c := newCSelectionCompareTestCore(t)
		run := c.RunFreshSchedulerSession
		if kind == "transaction" {
			run = c.ApplySchedulerAtomic
		}
		err := run(func(owner SchedulerTransactionToken) error {
			if kind == "late" {
				if _, e := c.appendSubtree(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, nil, nil, nil); e != nil {
					return e
				}
			}
			if e := c.BindFreshDFATerminalSourceOwned(owner, &testSharedDFASource{allow: true}); e == nil {
				t.Fatalf("%s binding succeeded", kind)
			}
			return nil
		})
		if err == nil {
			t.Fatalf("%s ignored failure did not poison its owner", kind)
		}
	}
}

func TestFreshDFATerminalIdentityRejectsForeignOwner(t *testing.T) {
	a, b := newCSelectionCompareTestCore(t), newCSelectionCompareTestCore(t)
	if err := a.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
		inner := b.RunFreshSchedulerSession(func(SchedulerTransactionToken) error {
			if err := b.BindFreshDFATerminalSourceOwned(owner, &testSharedDFASource{allow: true}); err == nil {
				t.Fatal("foreign owner issued a source")
			}
			return nil
		})
		if inner == nil {
			t.Fatal("foreign owner did not poison receiver")
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

func TestFreshDFATerminalIdentityPanicClearsSource(t *testing.T) {
	c := newCSelectionCompareTestCore(t)
	sentinel := errors.New("panic")
	func() {
		defer func() {
			if recover() != sentinel {
				t.Fatal("panic contract changed")
			}
		}()
		_ = c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
			if err := c.BindFreshDFATerminalSourceOwned(owner, &testSharedDFASource{allow: true}); err != nil {
				return err
			}
			if _, err := c.appendAuthenticatedTerminal(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, 0); err != nil {
				return err
			}
			panic(sentinel)
		})
	}()
	if c.dfaTerminalIdentity != nil {
		t.Fatal("panicked owner retained source capacity")
	}
}

func TestFreshDFATerminalOriginSameElectionDifferentPayloads(t *testing.T) {
	c := newCSelectionCompareTestCore(t)
	source := &testSharedDFASource{allow: true, origin: 7}
	if err := c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
		if err := c.BindFreshDFATerminalSourceOwned(owner, source); err != nil {
			return err
		}
		a, err := c.appendAuthenticatedTerminal(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, 0)
		if err != nil {
			return err
		}
		b, err := c.appendAuthenticatedTerminal(subtreeRecord{terminal: true, symbol: 3, endByte: 1}, 0)
		if err != nil {
			return err
		}
		if a == b || c.freshDFATerminalOrigin(a) != 7 || c.freshDFATerminalOrigin(b) != 7 {
			t.Fatal("actual origin identity was lost")
		}
		left, right := reductionSelectionPair(t, c, a, b)
		if cmp, selected, err := c.compareReconvergedReductionChildren(left, right); err != nil || !selected || cmp != 1 {
			t.Fatalf("same election selection %d %t %v", cmp, selected, err)
		}
		c.subtrees[b-1].extra = true
		if _, selected, err := c.compareReconvergedReductionChildren(left, right); err != nil || selected {
			t.Fatal("origin equality bypassed scalar leaf comparison")
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}
