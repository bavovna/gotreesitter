#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/screen-overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-default.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^Test(FreshDFATerminal.*|PrecedenceMaximum.*|ScannerStatePair.*)$' -count=1 -v -timeout=8m > /evidence/core-386.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(PrototypeDFATerminalSourceRejectsChangedOrigin|PrototypeDFADispatchRestoresNestedPanicWithoutAllocating|OrdinaryShiftCohortPreservesAlreadyShiftedSibling)$' -count=1 -v -timeout=8m > /evidence/root-focused.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
cd /candidate/cgo_harness
go test . -tags gts_parsercorephase0,treesitter_c_parity -run '^(TestGoGenericCallFrontierLockedCProbe|TestGoTokenTurnExpandedLockedCProbe|TestGoVersionTurnEditSessionsLockedC)$' -count=1 -v -timeout=8m > /evidence/go-c-screen.log 2>&1
printf 'complete\n' > /evidence/screen-complete.txt
