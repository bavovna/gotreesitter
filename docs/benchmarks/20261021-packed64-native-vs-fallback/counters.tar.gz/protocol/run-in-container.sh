#!/usr/bin/env bash
set -euo pipefail
export GOWORK=off GOTOOLCHAIN=local GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false -overlay=/protocol/overlay.json'
test "$(go env GOVERSION)/$(go env GOOS)/$(go env GOARCH)" = go1.25.14/linux/arm64
go version > /evidence/go-version.txt
mkdir /evidence/census
for role in baseline candidate; do
 if [[ "$role" = baseline ]]; then cd /reference; else cd /candidate; fi
 go test . -tags gts_parsercorephase0 -run '^TestStreamedPrefix(PublicWorkCensus|AttemptCensus)$' -count=1 -v -timeout=8m > "/evidence/census/$role.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
