package treealloc

import "testing"

func TestNativeProjectionNodeCapacityBoundsOnlyGrowth(t *testing.T) {
	for _, c := range []struct{ next, min, size, want int }{{80000, 64, 104, 10082}, {100, 64, 104, 100}, {20000, 12000, 104, 12000}, {0, 64, 104, 0}, {100, 64, 0, 100}, {80000, 64, 1 << 21, 64}} {
		if got := NativeProjectionNodeCapacity(c.next, c.min, c.size); got != c.want {
			t.Fatalf("%+v got %d", c, got)
		}
	}
}
