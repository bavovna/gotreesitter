// Package treealloc contains construction-only tree storage policies.
package treealloc

// NativeProjectionNodeCapacity bounds the unused tail of newly allocated
// native-publication node slabs. Existing backing, node IDs, work limits and
// normal arena pooling are unchanged. Smaller pages trade a few allocations
// for a bounded one-MiB tail instead of an eight-MiB geometric tail.
func NativeProjectionNodeCapacity(next, minimum, nodeBytes int) int {
	if next <= 0 || nodeBytes <= 0 {
		return next
	}
	ceiling := max((1<<20)/nodeBytes, minimum)
	return min(next, ceiling)
}
