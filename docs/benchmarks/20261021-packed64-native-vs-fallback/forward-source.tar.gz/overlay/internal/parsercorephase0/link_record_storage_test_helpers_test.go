package parsercorephase0

func linkStoreFromSliceForTest(records []linkRecord) compactLinkStore {
	var store compactLinkStore
	if records != nil {
		store.records = make([]compactLinkRecord, 0, cap(records))
	}
	for _, record := range records {
		store.Append(record)
	}
	return store
}
func (s *compactLinkStore) snapshotForTest() []linkRecord {
	if s.records == nil {
		return nil
	}
	records := make([]linkRecord, s.Len(), s.Capacity())
	for i := range records {
		records[i] = s.At(i)
	}
	return records
}
func (s *compactLinkStore) appendSliceForTest(records []linkRecord) {
	for _, r := range records {
		s.Append(r)
	}
}
func (s *compactLinkStore) hotForTest(index int) *compactLinkRecord { return &s.records[index] }
func (s *compactLinkStore) setForTest(index int, record linkRecord) {
	old := s.At(index)
	if old.scoreDelta == record.scoreDelta && old.order == record.order && old.flags == record.flags {
		s.records[index].prev = record.prev
		s.records[index].payload = record.payload
		s.records[index].next = record.next
		return
	}
	records := s.snapshotForTest()
	records[index] = record
	*s = linkStoreFromSliceForTest(records)
}
func (s *compactLinkStore) editForTest(index int, edit func(*linkRecord)) {
	record := s.At(index)
	edit(&record)
	s.setForTest(index, record)
}

func (s *compactLinkStore) copyFromForTest(records []linkRecord) {
	for i := 0; i < min(s.Len(), len(records)); i++ {
		s.setForTest(i, records[i])
	}
}
