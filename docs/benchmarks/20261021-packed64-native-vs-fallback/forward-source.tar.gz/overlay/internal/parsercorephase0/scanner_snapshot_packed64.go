package parsercorephase0

import "unsafe"

type scannerSnapshotPackedSlot64[T any] struct {
	record T
	bytes  [64]byte
}

type scannerSnapshotPackedPage64[T any] struct {
	storage ScannerSnapshotStorage
	slots   [2]scannerSnapshotPackedSlot64[T]
}

// CurrentPacked64Storage charges the newest packed64 page even if no published
// record reaches it yet. Old pages remain owned by their immutable record pointers.
func (p *ScannerSnapshotPages[T]) CurrentPacked64Storage() *ScannerSnapshotStorage {
	if p == nil || p.packed64 == nil {
		return nil
	}
	return &p.packed64.storage
}

// newPacked64 receives only a checked 33-through-64-byte shape. A published
// record's address and field backing never move or recycle, including on Reset.
func (p *ScannerSnapshotPages[T]) newPacked64(payload, start, end []byte) (*T, []byte, []byte, []byte, *ScannerSnapshotStorage) {
	if p.packed64 == nil || p.packed64Next == 2 {
		p.packed64 = new(scannerSnapshotPackedPage64[T])
		p.packed64.storage.bytes = uint64(unsafe.Sizeof(*p.packed64))
		p.packed64Next = 0
	}
	slot := &p.packed64.slots[p.packed64Next]
	p.packed64Next++
	a, b, c := freezeScannerFields(slot.bytes[:], payload, start, end)
	return &slot.record, a, b, c, &p.packed64.storage
}
