//go:build gts_eof_recovery_shadow

package parsercorephase0

import (
	"math"
	"testing"
)

func TestDiagnosticLinkMetadataCloneChargesAndDetachesEveryFamily(t *testing.T) {
	live := &Core{metadataConstructionAuthenticated: true, plans: &diagnosticEOFRecoveryPlanOnlyProvider{identity: 1}}
	for _, r := range []linkRecord{{prev: 1, payload: 1, flags: linkFlagHasOrder}, {prev: 2, payload: 2, scoreDelta: math.MinInt64, order: math.MaxUint64, flags: linkFlagHasOrder}, {prev: 3, flags: linkFlagRecoveryDiscontinuity}} {
		live.links.Append(r)
	}
	plan, err := planDiagnosticEOFRecoveryClone(live, nil, 24)
	if err != nil {
		t.Fatal(err)
	}
	clone := cloneDiagnosticEOFRecoveryCore(live, 0, plan.validationDemand)
	if !equalDiagnosticLinkStore(&live.links, &clone.links) || !disjointDiagnosticLinkStore(&live.links, &clone.links) {
		t.Fatal("link clone lost values or aliases backing")
	}
	without := *live
	without.links = compactLinkStore{}
	emptyPlan, err := planDiagnosticEOFRecoveryClone(&without, nil, 24)
	if err != nil {
		t.Fatal(err)
	}
	if plan.copiedArenaBytes-emptyPlan.copiedArenaBytes != clone.links.FootprintBytes() {
		t.Fatal("clone plan omitted auxiliary backing")
	}
	clone.links.SetNext(0, 99)
	clone.links.metadata[0].scoreDelta++
	clone.links.zeroOrder[0] = 0
	if live.links.At(0).next != 0 || !live.links.At(0).hasOrder() || live.links.At(1).scoreDelta != math.MinInt64 {
		t.Fatal("clone mutated source")
	}
}
