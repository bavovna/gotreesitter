package parsercorephase0

// growRecordArenaTargets reserves only capacity. Retained metadata and every
// proposed table/presence-plane increase participate in an armed ceiling.
func (c *Core) growRecordArenaTargets(nodes, links, subtrees, children int, maxBytes uint64) bool {
	dn := max(nodes-c.nodes.Capacity(), 0)
	dl := max(nodes-cap(c.nodeLineages), 0)
	de := max(links-c.links.Capacity(), 0)
	ds := max(subtrees-c.subtrees.Capacity(), 0)
	dc := max(children-cap(c.children), 0)
	recordAdditional := uint64(dn)*coreNodeRecordBytes + uint64(dl)*coreNodeLineageRecordBytes + uint64(de)*coreCompactLinkRecordBytes + uint64(ds)*coreSubtreeRecordBytes + uint64(dc)*coreChildRecordBytes
	growth := func() uint64 {
		return c.nodes.GrowthFootprintBytes(c.nodes.Capacity()+dn) + uint64(dl)*coreNodeLineageRecordBytes + c.links.GrowthFootprintBytes(c.links.Capacity()+de) + c.subtrees.GrowthFootprintBytes(c.subtrees.Capacity()+ds) + uint64(dc)*coreChildRecordBytes
	}
	additional := growth()
	if additional == 0 {
		return false
	}
	if maxBytes > 0 {
		current := c.nodes.FootprintBytes() + uint64(cap(c.nodeLineages))*coreNodeLineageRecordBytes + c.links.FootprintBytes() + c.subtrees.FootprintBytes() + uint64(cap(c.children))*coreChildRecordBytes
		if current >= maxBytes {
			return false
		}
		allowed := maxBytes - current
		if additional > allowed {
			if additional < recordAdditional || recordAdditional == 0 {
				return false
			}
			metadata := additional - recordAdditional
			if allowed <= metadata {
				return false
			}
			records := allowed - metadata
			dn = scaleReserveCount(dn, records, recordAdditional)
			dl = scaleReserveCount(dl, records, recordAdditional)
			de = scaleReserveCount(de, records, recordAdditional)
			ds = scaleReserveCount(ds, records, recordAdditional)
			dc = scaleReserveCount(dc, records, recordAdditional)
			if dn|dl|de|ds|dc == 0 || growth() > allowed {
				return false
			}
		}
	}
	c.nodes.Grow(c.nodes.Capacity() + dn)
	c.nodeLineages = growArena(c.nodeLineages, cap(c.nodeLineages)+dl)
	c.links.Grow(c.links.Capacity() + de)
	c.subtrees.Grow(c.subtrees.Capacity() + ds)
	c.children = growArena(c.children, cap(c.children)+dc)
	return true
}
