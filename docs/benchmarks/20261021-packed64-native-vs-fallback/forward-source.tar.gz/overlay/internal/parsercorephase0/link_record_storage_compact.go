package parsercorephase0

// compactLinkRecord keeps the traversal fields together. A zero metadata ID
// denotes a zero-score/order link, with ordered-zero presence stored in a bit.
// Non-default values retain
// their full widths in a separate append-only arena.
type compactLinkRecord struct {
	prev     NodeID
	payload  SubtreeID
	next     LinkID
	metadata uint32
}

type compactLinkMetadata struct {
	scoreDelta int64
	order      uint64
	flags      uint32
	owner      LinkID
}

// compactLinkStore owns one metadata record per exceptional link. Metadata
// owners increase with link IDs, so truncation restores both logical lengths.
// Values returned by At are independent of later growth, just like slice
// element values. Ordered zero values use a presence bit, so they do not
// require cold metadata. Only next is mutable after publication.
type compactLinkStore struct {
	records   []compactLinkRecord
	metadata  []compactLinkMetadata
	zeroOrder []uint64
}

func (s *compactLinkStore) Len() int      { return len(s.records) }
func (s *compactLinkStore) Capacity() int { return cap(s.records) }
func (s *compactLinkStore) FootprintBytes() uint64 {
	return compactLinkRetainedBytes(cap(s.records), cap(s.metadata), cap(s.zeroOrder))
}
func compactLinkOrderWords(count int) int {
	words := count / 64
	if count%64 != 0 {
		words++
	}
	return words
}
func (s *compactLinkStore) GrowthFootprintBytes(want int) uint64 {
	records := max(want-cap(s.records), 0)
	words := 0
	if s.zeroOrder != nil {
		words = max(compactLinkOrderWords(want)-cap(s.zeroOrder), 0)
	}
	return compactLinkRetainedBytes(records, 0, words)
}
func (s *compactLinkStore) Grow(want int) {
	s.records = growArena(s.records, want)
	if s.zeroOrder != nil {
		s.zeroOrder = growArena(s.zeroOrder, compactLinkOrderWords(want))
	}
}
func (s *compactLinkStore) setZeroOrder(index int, present bool) {
	word := index / 64
	if word >= len(s.zeroOrder) {
		if !present {
			return
		}
		old := len(s.zeroOrder)
		s.zeroOrder = growArena(s.zeroOrder, compactLinkOrderWords(cap(s.records)))
		s.zeroOrder = s.zeroOrder[:word+1]
		clear(s.zeroOrder[old:])
	}
	mask := uint64(1) << uint(index%64)
	if present {
		s.zeroOrder[word] |= mask
	} else {
		s.zeroOrder[word] &^= mask
	}
}
func (s *compactLinkStore) At(index int) linkRecord {
	record := s.records[index]
	result := linkRecord{prev: record.prev, payload: record.payload, next: record.next}
	if record.metadata != 0 {
		metadata := s.metadata[record.metadata-1]
		result.scoreDelta, result.order, result.flags = metadata.scoreDelta, metadata.order, metadata.flags
	} else if word := index / 64; word < len(s.zeroOrder) {
		result.flags = uint32(s.zeroOrder[word]>>(index%64)) & linkFlagHasOrder
	}
	return result
}
func (s *compactLinkStore) Append(record linkRecord) {
	if uint64(len(s.records)) >= uint64(^uint32(0)) {
		panic("parser-core phase zero: compact link ID overflow")
	}
	hot := compactLinkRecord{prev: record.prev, payload: record.payload, next: record.next}
	if record.scoreDelta != 0 || record.order != 0 || record.flags & ^linkFlagHasOrder != 0 {
		// There is at most one metadata entry per link, including invalid records
		// retained for shape validation. The full uint32 link domain is preserved.
		s.metadata = append(s.metadata, compactLinkMetadata{scoreDelta: record.scoreDelta, order: record.order, flags: record.flags, owner: LinkID(len(s.records) + 1)})
		hot.metadata = uint32(len(s.metadata))
	}
	s.records = append(s.records, hot)
	s.setZeroOrder(len(s.records)-1, hot.metadata == 0 && record.hasOrder())
}
func (s *compactLinkStore) SetNext(index int, next LinkID) { s.records[index].next = next }
func (s *compactLinkStore) Truncate(count int) {
	// Preserve the old slice bounds check even when all metadata is absent.
	s.records = s.records[:count]
	low, high := 0, len(s.metadata)
	for low < high {
		middle := low + (high-low)/2
		if uint64(s.metadata[middle].owner) <= uint64(count) {
			low = middle + 1
		} else {
			high = middle
		}
	}
	s.metadata = s.metadata[:low]
	words := compactLinkOrderWords(count)
	if len(s.zeroOrder) > words {
		s.zeroOrder = s.zeroOrder[:words]
	}
	if count%64 != 0 && len(s.zeroOrder) == words {
		s.zeroOrder[words-1] &= (uint64(1) << uint(count%64)) - 1
	}
	for len(s.zeroOrder) > 0 && s.zeroOrder[len(s.zeroOrder)-1] == 0 {
		s.zeroOrder = s.zeroOrder[:len(s.zeroOrder)-1]
	}
}
func (s *compactLinkStore) Reset() {
	s.records = s.records[:0]
	s.metadata = s.metadata[:0]
	s.zeroOrder = s.zeroOrder[:0]
}
func (s *compactLinkStore) CloneActive(extra int) compactLinkStore {
	if extra < 0 || extra > int(^uint(0)>>1)-len(s.records) {
		panic("parser-core phase zero: compact link clone capacity overflow")
	}
	var result compactLinkStore
	if s.records != nil || extra > 0 {
		result.records = make([]compactLinkRecord, len(s.records), len(s.records)+extra)
		copy(result.records, s.records)
	}
	if s.metadata != nil {
		result.metadata = make([]compactLinkMetadata, len(s.metadata))
		copy(result.metadata, s.metadata)
	}
	if s.zeroOrder != nil {
		result.zeroOrder = make([]uint64, len(s.zeroOrder), compactLinkOrderWords(len(s.records)+extra))
		copy(result.zeroOrder, s.zeroOrder)
	}
	return result
}
func (s *compactLinkStore) CloneFootprintBytes(extra int) uint64 {
	if extra < 0 || extra > int(^uint(0)>>1)-len(s.records) {
		panic("parser-core phase zero: compact link clone capacity overflow")
	}
	words := 0
	if s.zeroOrder != nil {
		words = compactLinkOrderWords(len(s.records) + extra)
	}
	return compactLinkRetainedBytes(len(s.records)+extra, len(s.metadata), words)
}

func compactLinkRetainedBytes(records, metadata, words int) uint64 {
	maximum := ^uint64(0)
	if records < 0 || metadata < 0 || words < 0 || uint64(records) > maximum/16 {
		return maximum
	}
	bytes := uint64(records) * 16
	if uint64(metadata) > (maximum-bytes)/24 {
		return maximum
	}
	bytes += uint64(metadata) * 24
	if uint64(words) > (maximum-bytes)/8 {
		return maximum
	}
	return bytes + uint64(words)*8
}

func (s *compactLinkStore) StorageBytes() uint64 {
	return compactLinkRetainedBytes(len(s.records), len(s.metadata), len(s.zeroOrder))
}
