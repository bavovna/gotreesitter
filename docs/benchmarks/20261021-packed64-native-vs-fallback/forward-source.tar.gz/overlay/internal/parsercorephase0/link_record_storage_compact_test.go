package parsercorephase0

import (
	"math"
	"math/rand"
	"reflect"
	"testing"
	"unsafe"
)

func TestCompactLinkStoreValuesAndTruncation(t *testing.T) {
	if unsafe.Sizeof(compactLinkRecord{}) != 16 || unsafe.Sizeof(compactLinkMetadata{}) != 24 {
		t.Fatal("record layout changed")
	}
	records := []linkRecord{
		{prev: 1, payload: 2, next: 3},
		{prev: 4, payload: 5, next: 6, flags: linkFlagHasOrder},
		{prev: 7, payload: 8, next: 9, scoreDelta: math.MinInt64, order: math.MaxUint64, flags: math.MaxUint32},
		{prev: math.MaxUint32, payload: math.MaxUint32, next: math.MaxUint32, scoreDelta: math.MaxInt64, order: 1 << 63, flags: linkFlagHasOrder},
		{prev: 10, flags: linkFlagRecoveryDiscontinuity},
		{prev: 11, payload: 12},
	}
	var store compactLinkStore
	for _, r := range records {
		store.Append(r)
	}
	if len(store.metadata) != 3 {
		t.Fatalf("metadata count %d", len(store.metadata))
	}
	for i, r := range records {
		if got := store.At(i); got != r {
			t.Fatalf("record %d: %#v != %#v", i, got, r)
		}
	}
	clone := store.CloneActive(1)
	if clone.Capacity() != len(records)+1 || clone.FootprintBytes() != store.CloneFootprintBytes(1) {
		t.Fatal("clone reserve accounting")
	}
	clone.SetNext(2, 123)
	if store.At(2).next != records[2].next {
		t.Fatal("clone aliases source records")
	}
	clone.metadata[0].order = 42
	if store.At(2).order != math.MaxUint64 {
		t.Fatal("clone aliases source metadata")
	}
	store.Truncate(2)
	if len(store.metadata) != 0 {
		t.Fatalf("truncated metadata %d", len(store.metadata))
	}
	fresh := linkRecord{prev: 13, payload: 14, scoreDelta: -17, order: math.MaxUint64, flags: linkFlagHasOrder}
	store.Append(fresh)
	if got := store.At(2); got != fresh || store.metadata[0].owner != 3 {
		t.Fatalf("reused ID %#v", got)
	}
	before := store.FootprintBytes()
	store.Reset()
	if store.Len() != 0 || len(store.metadata) != 0 || len(store.zeroOrder) != 0 || store.FootprintBytes() != before {
		t.Fatal("reset retention")
	}
	store.Append(linkRecord{prev: 1, payload: 2})
	if store.At(0) != (linkRecord{prev: 1, payload: 2}) {
		t.Fatal("stale metadata after reset")
	}
	var zero compactLinkStore
	if zero.CloneActive(0).records != nil || zero.CloneActive(0).metadata != nil {
		t.Fatal("nil clone changed")
	}
}

func TestCompactLinkStoreMatchesSliceOperations(t *testing.T) {
	random := rand.New(rand.NewSource(71412021))
	var store compactLinkStore
	var reference []linkRecord
	check := func() {
		t.Helper()
		if len(store.zeroOrder) > compactLinkOrderWords(len(reference)) {
			t.Fatal("stale presence-plane length")
		}
		if store.Len() != len(reference) {
			t.Fatal("logical length")
		}
		lastOwner := LinkID(0)
		for _, meta := range store.metadata {
			if meta.owner <= lastOwner || uint64(meta.owner) > uint64(store.Len()) {
				t.Fatal("metadata ownership")
			}
			lastOwner = meta.owner
		}
		for i, want := range reference {
			if got := store.At(i); got != want {
				t.Fatalf("record %d: %#v != %#v", i, got, want)
			}
		}
		if store.FootprintBytes() != uint64(cap(store.records))*16+uint64(cap(store.metadata))*24+uint64(cap(store.zeroOrder))*8 {
			t.Fatal("footprint")
		}
	}
	for step := 0; step < 12000; step++ {
		switch random.Intn(9) {
		case 0, 1, 2, 3:
			r := linkRecord{prev: NodeID(random.Uint32()), payload: SubtreeID(random.Uint32()), next: LinkID(random.Uint32())}
			if random.Intn(3) == 0 {
				r.scoreDelta = int64(random.Uint64())
				r.order = random.Uint64()
				r.flags = random.Uint32()
			}
			store.Append(r)
			reference = append(reference, r)
		case 4:
			if len(reference) > 0 {
				i := random.Intn(len(reference))
				next := LinkID(random.Uint32())
				store.SetNext(i, next)
				reference[i].next = next
			}
		case 5:
			if len(reference) > 0 {
				n := random.Intn(len(reference) + 1)
				store.Truncate(n)
				reference = reference[:n]
			}
		case 6:
			store.Reset()
			reference = reference[:0]
		case 7:
			want := len(reference) + random.Intn(100)
			before := store.FootprintBytes()
			delta := store.GrowthFootprintBytes(want)
			store.Grow(want)
			if store.FootprintBytes() != before+delta {
				t.Fatal("growth accounting")
			}
		case 8:
			copy := store.CloneActive(random.Intn(3))
			for i, want := range reference {
				if copy.At(i) != want {
					t.Fatal("clone value")
				}
			}
			if len(reference) > 0 {
				copy.SetNext(0, reference[0].next+1)
				if reflect.DeepEqual(copy.At(0), store.At(0)) {
					t.Fatal("clone independence")
				}
			}
		}
		check()
	}
}

func TestCompactLinkStoreCommonReadAllocatesNothing(t *testing.T) {
	var store compactLinkStore
	store.Grow(1024)
	for i := 0; i < 1024; i++ {
		store.Append(linkRecord{prev: NodeID(i + 1), payload: SubtreeID(i + 2)})
	}
	if len(store.metadata) != 0 {
		t.Fatal("ordinary links allocate metadata")
	}
	var result linkRecord
	if got := testing.AllocsPerRun(100, func() {
		for i := 0; i < 1024; i++ {
			result = store.At(i)
		}
	}); got != 0 {
		t.Fatalf("lookup allocations: %v", got)
	}
	if result.payload != 1025 {
		t.Fatal("read was not evaluated")
	}
}

func TestCompactLinkStoreFootprintOverflow(t *testing.T) {
	maximumInt := int(^uint(0) >> 1)
	want := ^uint64(0)
	if uint64(maximumInt) <= want/16 {
		want = uint64(maximumInt) * 16
	}
	var store compactLinkStore
	if got := store.CloneFootprintBytes(maximumInt); got != want {
		t.Fatalf("clone footprint %d != %d", got, want)
	}
	if got := store.GrowthFootprintBytes(maximumInt); got != want {
		t.Fatalf("growth footprint %d != %d", got, want)
	}
	for _, extra := range []int{-1} {
		func() {
			defer func() {
				if recover() == nil {
					t.Error("negative clone reserve accepted")
				}
			}()
			store.CloneActive(extra)
		}()
	}
}

func TestCompactLinkStoreOrderedZeroPresence(t *testing.T) {
	var store compactLinkStore
	for i := 0; i < 513; i++ {
		store.Append(linkRecord{prev: NodeID(i + 1), payload: SubtreeID(i + 2), flags: linkFlagHasOrder})
	}
	if len(store.metadata) != 0 {
		t.Fatal("ordered zero allocated cold metadata")
	}
	for i := 0; i < 513; i++ {
		if got := store.At(i); !got.hasOrder() || got.order != 0 || got.prev != NodeID(i+1) {
			t.Fatalf("ordered zero at %d: %#v", i, got)
		}
	}
	for _, count := range []int{513, 512, 511, 65, 64, 63, 1, 0} {
		clone := store.CloneActive(1)
		clone.Truncate(count)
		clone.Append(linkRecord{prev: 99, payload: 100})
		if got := clone.At(count); got.flags != 0 {
			t.Fatalf("stale order bit at %d", count)
		}
		if count > 0 && !store.At(count-1).hasOrder() {
			t.Fatal("clone aliased presence bits")
		}
	}
	store.Reset()
	store.Append(linkRecord{prev: 1, payload: 2})
	if store.At(0).hasOrder() {
		t.Fatal("reset kept order bit")
	}
	store.Append(linkRecord{prev: 2, payload: 3, flags: linkFlagHasOrder})
	if !store.At(1).hasOrder() {
		t.Fatal("ordered zero after reset")
	}
	before := store.FootprintBytes()
	delta := store.GrowthFootprintBytes(2048)
	store.Grow(2048)
	if store.FootprintBytes() != before+delta {
		t.Fatal("presence-plane growth accounting")
	}
	clone := store.CloneActive(64)
	if clone.FootprintBytes() != store.CloneFootprintBytes(64) {
		t.Fatal("presence-plane clone accounting")
	}
}
