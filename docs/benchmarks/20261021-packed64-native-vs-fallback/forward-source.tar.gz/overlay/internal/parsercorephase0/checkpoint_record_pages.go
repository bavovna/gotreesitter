package parsercorephase0

import "unsafe"

const checkpointRecordPrefix = 256
const checkpointRecordPage = 1024

// The small prefix keeps the original growth policy. Larger immutable records
// use stable pages instead of repeatedly copying the complete digest history.
// Logical IDs remain consecutive; unused slots and pointer capacity are charged.
type checkpointRecords struct {
	first  []checkpointRecord
	pages  []*[checkpointRecordPage]checkpointRecord
	length int
}

func (p *checkpointRecords) Len() int { return p.length }
func (p *checkpointRecords) Capacity() uint64 {
	return uint64(cap(p.first)) + uint64(len(p.pages))*checkpointRecordPage
}
func (p *checkpointRecords) append(r checkpointRecord) {
	index := p.length
	if index < checkpointRecordPrefix {
		p.first = append(p.first, r)
	} else {
		n := index - checkpointRecordPrefix
		page := n / checkpointRecordPage
		if page == len(p.pages) {
			p.pages = append(p.pages, new([checkpointRecordPage]checkpointRecord))
		}
		p.pages[page][n%checkpointRecordPage] = r
	}
	p.length++
}
func (p *checkpointRecords) at(index int) *checkpointRecord {
	if index < 0 || index >= p.length {
		panic("parser-core phase zero: checkpoint record slot out of range")
	}
	if index < checkpointRecordPrefix {
		return &p.first[index]
	}
	n := index - checkpointRecordPrefix
	return &p.pages[n/checkpointRecordPage][n%checkpointRecordPage]
}
func (p *checkpointRecords) reset() { p.first = p.first[:0]; p.length = 0 }
func (p *checkpointRecords) footprintBytes() uint64 {
	return uint64(p.Capacity())*uint64(unsafe.Sizeof(checkpointRecord{})) + uint64(cap(p.pages))*uint64(unsafe.Sizeof((*[checkpointRecordPage]checkpointRecord)(nil)))
}
func (p *checkpointRecords) cloneFootprintBytes() uint64 {
	prefix := min(p.length, checkpointRecordPrefix)
	pages := p.clonePageCount()
	return (uint64(prefix)+uint64(pages)*checkpointRecordPage)*uint64(unsafe.Sizeof(checkpointRecord{})) + uint64(pages)*uint64(unsafe.Sizeof((*[checkpointRecordPage]checkpointRecord)(nil)))
}
func (p *checkpointRecords) clone() checkpointRecords {
	var q checkpointRecords
	prefix := min(p.length, checkpointRecordPrefix)
	if prefix > 0 {
		q.first = make([]checkpointRecord, prefix)
		copy(q.first, p.first[:prefix])
	}
	n := p.clonePageCount()
	if n > 0 {
		q.pages = make([]*[checkpointRecordPage]checkpointRecord, n)
	}
	for i := range q.pages {
		q.pages[i] = new([checkpointRecordPage]checkpointRecord)
		*q.pages[i] = *p.pages[i]
	}
	q.length = p.length
	return q
}
func (p *checkpointRecords) equal(q *checkpointRecords) bool {
	if p.length != q.length {
		return false
	}
	for i := 0; i < p.length; i++ {
		if *p.at(i) != *q.at(i) {
			return false
		}
	}
	return true
}

func (p *checkpointRecords) clonePageCount() int {
	remaining := p.length - checkpointRecordPrefix
	if remaining <= 0 {
		return 0
	}
	return (remaining-1)/checkpointRecordPage + 1
}
