package parsercorephase0

import (
	"crypto/sha256"
	"encoding/binary"
	"testing"
)

func TestCheckpointRecordPagesPreserveIDsDigestsAndCollisions(t *testing.T) {
	i := newCheckpointInterner(2000, 10000)
	for n := 1; n <= 1400; n++ {
		var state [4]byte
		binary.LittleEndian.PutUint32(state[:], uint32(n))
		id, err := i.internHash(state[:], 7)
		if err != nil || id != CheckpointID(n) {
			t.Fatal(n, id, err)
		}
	}
	for n := 1; n <= 1400; n++ {
		var state [4]byte
		binary.LittleEndian.PutUint32(state[:], uint32(n))
		id, err := i.internHash(state[:], 7)
		if err != nil || id != CheckpointID(n) {
			t.Fatal(n, id, err)
		}
		length, digest, ok := i.receipt(id)
		if !ok || length != 4 || digest != sha256.Sum256(state[:]) || !i.matches(id, state[:]) {
			t.Fatal("paged receipt changed", n)
		}
	}
	if i.stats().Unique != 1400 || i.stats().DigestCollisions != 1399 {
		t.Fatal(i.stats())
	}
}
func TestCheckpointRecordPagesKeepPublishedPageAddressesAndReuseCapacity(t *testing.T) {
	var p checkpointRecords
	for n := 0; n < 1400; n++ {
		p.append(checkpointRecord{offset: uint32(n), length: uint32(n + 1)})
	}
	firstPage := p.at(checkpointRecordPrefix)
	for n := 1400; n < 3500; n++ {
		p.append(checkpointRecord{offset: uint32(n), length: uint32(n + 1)})
	}
	if p.at(checkpointRecordPrefix) != firstPage || firstPage.offset != checkpointRecordPrefix {
		t.Fatal("growth copied a published page")
	}
	footprint := p.footprintBytes()
	if got := testing.AllocsPerRun(10, func() {
		p.reset()
		for n := 0; n < 3500; n++ {
			p.append(checkpointRecord{offset: uint32(n)})
		}
	}); got != 0 {
		t.Fatalf("warm records allocs=%g", got)
	}
	p.reset()
	if p.Len() != 0 || p.footprintBytes() != footprint {
		t.Fatal("reset lost capacity or kept logical IDs")
	}
	p.append(checkpointRecord{offset: 99})
	if p.Len() != 1 || p.at(0).offset != 99 {
		t.Fatal("reset-stale record remained visible")
	}
}
func TestCheckpointRecordPagesCloneChargesUnusedSlotsAndIsolatesRecords(t *testing.T) {
	for _, size := range []int{0, 1, 255, 256, 257, 1279, 1280, 1281, 2500} {
		var p checkpointRecords
		for n := 0; n < size; n++ {
			p.append(checkpointRecord{offset: uint32(n + 1)})
		}
		q := p.clone()
		if !p.equal(&q) || q.footprintBytes() != p.cloneFootprintBytes() {
			t.Fatalf("clone changed records or byte plan at %d", size)
		}
		if size > 0 {
			q.at(size-1).offset++
			if p.equal(&q) || p.at(size-1).offset != uint32(size) {
				t.Fatal("clone aliased a published record")
			}
		}
	}
}
