package parsercorephase0

// GrowRecordArenasFromObservedDensity projects the live record counts at the
// first staged reserve. Unlike a fixed source density, this keeps the observed
// mixture of graph and syntax records. It changes capacity only. The complete
// existing five-arena capacity and every proposed increase fit maxBytes when
// that ceiling is armed; no live records or limits change.
func (c *Core) GrowRecordArenasFromObservedDensity(sourceBytes int, progress uint32, maxBytes uint64) bool {
	if c == nil || sourceBytes <= 1 || uint64(sourceBytes) > uint64(^uint32(0)) || progress == 0 || uint64(progress) >= uint64(sourceBytes) || uint64(progress) < uint64(sourceBytes/16) {
		return false
	}
	project := func(count int, limit uint32) int {
		value := (uint64(min(count, 1<<31-1))*uint64(sourceBytes) + uint64(progress) - 1) / uint64(progress)
		value = (value*17 + 15) / 16
		return int(min(value, uint64(limit), uint64(1<<31-1)))
	}
	nodes := project(c.nodes.Len(), c.limits.MaxNodes)
	links := project(c.links.Len(), c.limits.MaxLinks)
	subtrees := project(c.subtrees.Len(), c.limits.MaxSubtrees)
	children := project(len(c.children), c.limits.MaxChildren)
	return c.growRecordArenaTargets(nodes, links, subtrees, children, maxBytes)
}
