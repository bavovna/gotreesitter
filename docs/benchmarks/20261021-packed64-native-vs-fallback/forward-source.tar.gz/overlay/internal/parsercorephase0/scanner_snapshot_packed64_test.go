package parsercorephase0

import (
	"bytes"
	"testing"
	"unsafe"
)

func TestPacked64SnapshotPagesPreserveShapesAndFieldCapacities(t *testing.T) {
	for _, size := range []int{0, 1, 32, 33, 63, 64, 65} {
		var pages ScannerSnapshotPages[scannerSnapshotTestRecord]
		input := bytes.Repeat([]byte{3}, size)
		record, payload, start, end, storage := pages.NewPacked(input, nil, []byte{})
		record.Payload, record.Start, record.End = payload, start, end
		if !bytes.Equal(payload, input) || start != nil || end == nil || record.Tried != nil {
			t.Fatalf("field shape changed at %d", size)
		}
		if (size >= 1 && size <= 64) != (storage != nil) {
			t.Fatalf("page shape=%d owner=%p", size, storage)
		}
		if size <= 32 && pages.CurrentPacked64Storage() != nil {
			t.Fatal("small payload used the packed64 shape")
		}
		if size > 32 && size <= 64 && pages.CurrentPacked64Storage() != storage {
			t.Fatal("wide payload has no packed64 owner")
		}
		if len(input) != 0 {
			input[0] = 4
			if payload[0] != 3 {
				t.Fatal("publication aliases source bytes")
			}
		}
	}
	var pages ScannerSnapshotPages[scannerSnapshotTestRecord]
	_, payload, start, end, storage := pages.NewPacked(bytes.Repeat([]byte{1}, 33), []byte{2, 2}, []byte{3, 3, 3})
	if cap(payload) != 33 || cap(start) != 2 || cap(end) != 64-35 || storage == nil {
		t.Fatal("reserved capacity escaped a field boundary")
	}
	payload = append(payload, 9)
	if start[0] != 2 || end[0] != 3 || payload[len(payload)-1] != 9 {
		t.Fatal("append crossed a field boundary")
	}
	_, peer, _, _, same := pages.NewPacked(bytes.Repeat([]byte{5}, 33), nil, nil)
	if same != storage {
		t.Fatal("second record split a page")
	}
	for len(end) < cap(end) {
		end = append(end, 7)
	}
	if peer[0] != 5 {
		t.Fatal("reserved tail aliases the peer record")
	}
	var absent *ScannerSnapshotPages[scannerSnapshotTestRecord]
	_, direct, _, _, owner := absent.NewPacked(bytes.Repeat([]byte{6}, 33), nil, nil)
	if owner != nil || !bytes.Equal(direct, bytes.Repeat([]byte{6}, 33)) || absent.CurrentPacked64Storage() != nil {
		t.Fatal("nil owner changed exact-allocation fallback")
	}
}

func TestPacked64SnapshotPagesPreserveOwnersAcrossRolloverAndReset(t *testing.T) {
	var pages ScannerSnapshotPages[scannerSnapshotTestRecord]
	first, a, b, c, owner := pages.NewPacked(bytes.Repeat([]byte{1}, 33), []byte{2}, []byte{3})
	first.Payload, first.Start, first.End = a, b, c
	if owner == nil || owner.FootprintBytes() != uint64(unsafe.Sizeof(scannerSnapshotPackedPage64[scannerSnapshotTestRecord]{})) {
		t.Fatal("packed64 owner omits unused slots or metadata")
	}
	second, d, _, _, same := pages.NewPacked(bytes.Repeat([]byte{4}, 64), nil, nil)
	second.Payload = d
	if second == first || same != owner {
		t.Fatal("packed64 peers do not have distinct stable records")
	}
	third, e, _, _, next := pages.NewPacked(bytes.Repeat([]byte{5}, 33), nil, nil)
	third.Payload = e
	if third == first || next == owner || next != pages.CurrentPacked64Storage() {
		t.Fatal("rollover recycled a published address")
	}
	pages.NewPacked([]byte{9}, nil, nil)
	if pages.CurrentPacked64Storage() != next {
		t.Fatal("packed32 construction replaced the packed64 owner")
	}
	pages.Reset()
	if small, packed := pages.CurrentStorage(); small != nil || packed != nil || pages.CurrentPacked64Storage() != nil {
		t.Fatal("reset retained a current page")
	}
	for i := 0; i < 20; i++ {
		record, payload, _, _, storage := pages.NewPacked(bytes.Repeat([]byte{byte(i + 10)}, 33), nil, nil)
		record.Payload = payload
		if record == first || record == second || record == third || storage == owner || storage == next {
			t.Fatal("reset reused published storage")
		}
	}
	if a[0] != 1 || b[0] != 2 || c[0] != 3 || d[0] != 4 || e[0] != 5 || first.Payload[0] != 1 {
		t.Fatal("rollover/reset changed a published snapshot")
	}
}

func TestPacked64SnapshotPagesAllocationBoundAndOwnerSize(t *testing.T) {
	input := bytes.Repeat([]byte{1}, 33)
	var pages ScannerSnapshotPages[scannerSnapshotTestRecord]
	allocs := testing.AllocsPerRun(100, func() {
		pages.Reset()
		for i := 0; i < 8; i++ {
			record, payload, start, end, owner := pages.NewPacked(input, nil, nil)
			record.Payload, record.Start, record.End = payload, start, end
			if owner == nil {
				panic("missing packed64 page")
			}
			scannerSnapshotRecordSink = record
		}
	})
	if allocs != 4 {
		t.Fatalf("8 immutable packed64 records allocated %v objects, want4", allocs)
	}
	// Reorder the private fields so the added third page shape fits the old
	// owner size on both 32-bit and 64-bit architectures.
	legacy := struct {
		small      *scannerSnapshotPage32[scannerSnapshotTestRecord]
		smallNext  uint8
		packed     *scannerSnapshotPackedPage32[scannerSnapshotTestRecord]
		packedNext uint8
	}{}
	if unsafe.Sizeof(pages) != unsafe.Sizeof(legacy) {
		t.Fatalf("page owner grew from%d to%d bytes", unsafe.Sizeof(legacy), unsafe.Sizeof(pages))
	}
}
