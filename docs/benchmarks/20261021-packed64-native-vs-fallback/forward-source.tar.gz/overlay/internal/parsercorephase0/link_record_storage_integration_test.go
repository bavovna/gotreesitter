package parsercorephase0

import (
	"math"
	"reflect"
	"testing"
)

func TestCompactLinkCoreRollbackRestoresAuxiliaryLengths(t *testing.T) {
	c := projectionFixture(t)
	before := c.links.snapshotForTest()
	storage, work := c.StorageBytes(), c.Work()
	mark := c.mark()
	c.links.Append(linkRecord{prev: 1, payload: 1, flags: linkFlagHasOrder})
	c.links.Append(linkRecord{prev: 1, payload: 1, scoreDelta: math.MinInt64, order: math.MaxUint64, flags: linkFlagHasOrder})
	if c.links.StorageBytes() <= uint64(len(before))*16 {
		t.Fatal("auxiliary bytes missing")
	}
	c.restore(mark)
	if !reflect.DeepEqual(c.links.snapshotForTest(), before) || len(c.links.metadata) != 0 || len(c.links.zeroOrder) != 0 {
		t.Fatal("rollback kept removed link metadata")
	}
	if c.StorageBytes() != storage || c.Work() != work {
		t.Fatal("rollback changed live bytes or work")
	}
}
func TestCompactLinkCoreReserveChargesRetainedMetadata(t *testing.T) {
	for _, allowance := range []uint64{1, 31, 1024, 65536} {
		c := projectionFixture(t)
		for i := 0; i < 256; i++ {
			c.links.Append(linkRecord{prev: 1, payload: 1, scoreDelta: int64(i + 1), order: uint64(i + 1), flags: linkFlagHasOrder})
		}
		c.links.Append(linkRecord{prev: 1, payload: 1, flags: linkFlagHasOrder})
		before := observedArenaCapacity(c)
		storage, work := c.StorageBytes(), c.Work()
		snapshot := c.links.snapshotForTest()
		ceiling := before + allowance
		c.GrowRecordArenasFromObservedDensity(100000, 6250, ceiling)
		if got := observedArenaCapacity(c); got > ceiling {
			t.Fatalf("capacity %d exceeds %d", got, ceiling)
		}
		if c.StorageBytes() != storage || c.Work() != work || !reflect.DeepEqual(c.links.snapshotForTest(), snapshot) {
			t.Fatal("reserve changed logical state")
		}
	}
}
