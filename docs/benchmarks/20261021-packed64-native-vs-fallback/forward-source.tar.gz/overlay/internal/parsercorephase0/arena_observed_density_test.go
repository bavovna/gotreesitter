package parsercorephase0

import (
	"reflect"
	"strconv"
	"testing"
)

func observedArenaCapacity(c *Core) uint64 {
	return c.nodes.FootprintBytes() + uint64(cap(c.nodeLineages))*coreNodeLineageRecordBytes + c.links.FootprintBytes() + c.subtrees.FootprintBytes() + uint64(cap(c.children))*coreChildRecordBytes
}
func TestObservedRecordDensityPreservesRecordsAndWork(t *testing.T) {
	c := projectionFixture(t)
	nodes := c.nodes.snapshotForTest()
	lineages := append([]nodeLineageHot(nil), c.nodeLineages...)
	links := c.links.snapshotForTest()
	subtrees := c.subtrees.snapshotForTest()
	children := append([]SubtreeID(nil), c.children...)
	storage, work := c.StorageBytes(), c.Work()
	if !c.GrowRecordArenasFromObservedDensity(10000, 625, 1<<20) {
		t.Fatal("observed projection did not grow")
	}
	if !reflect.DeepEqual(c.nodes.snapshotForTest(), nodes) || !reflect.DeepEqual(c.nodeLineages, lineages) || !reflect.DeepEqual(c.links.snapshotForTest(), links) || !reflect.DeepEqual(c.subtrees.snapshotForTest(), subtrees) || !reflect.DeepEqual(c.children, children) {
		t.Fatal("projection changed records")
	}
	if c.StorageBytes() != storage || c.Work() != work {
		t.Fatal("projection changed logical storage or work")
	}
	// A hundred observed nodes at 1/16 source progress projects to 1700,
	// whereas the source-based reserve projects to 7500 before its ceiling.
	if c.nodes.Capacity() != 1700 || c.links.Capacity() != 1530 || c.subtrees.Capacity() != 1360 || cap(c.children) != 1275 {
		t.Fatalf("density mixture lost: %d/%d/%d/%d", c.nodes.Capacity(), c.links.Capacity(), c.subtrees.Capacity(), cap(c.children))
	}
	if got := testing.AllocsPerRun(10, func() { c.GrowRecordArenasFromObservedDensity(10000, 625, 1<<20) }); got != 0 {
		t.Fatalf("warm projection allocs=%g", got)
	}
}
func TestObservedRecordDensityCapsTotalCapacityIncludingSkew(t *testing.T) {
	c := projectionFixture(t)
	c.links.Grow(5000)
	before := observedArenaCapacity(c)
	ceiling := before + 1024
	if !c.GrowRecordArenasFromObservedDensity(10000, 625, ceiling) {
		t.Fatal("bounded growth refused")
	}
	if after := observedArenaCapacity(c); after <= before || after > ceiling {
		t.Fatalf("total capacity %d -> %d exceeds %d", before, after, ceiling)
	}
	if c.links.Capacity() != 5000 {
		t.Fatal("projection changed retained larger capacity")
	}
	before = observedArenaCapacity(c)
	if c.GrowRecordArenasFromObservedDensity(10000, 625, before) || observedArenaCapacity(c) != before {
		t.Fatal("spent total ceiling changed capacity")
	}
	if c.GrowRecordArenasFromObservedDensity(10000, 625, before+1) || observedArenaCapacity(c) != before {
		t.Fatal("one byte admitted partial growth")
	}
}
func TestObservedRecordDensityRejectsInvalidProgress(t *testing.T) {
	c := projectionFixture(t)
	before := c.FootprintBytes()
	inputs := []struct {
		source   int
		progress uint32
	}{{-1, 1}, {0, 1}, {1, 1}, {10000, 0}, {10000, 624}, {10000, 10000}, {10000, 10001}}
	if strconv.IntSize == 64 {
		source := uint64(1) << 32
		inputs = append(inputs, struct {
			source   int
			progress uint32
		}{int(source), 1 << 28})
	}
	for _, in := range inputs {
		if c.GrowRecordArenasFromObservedDensity(in.source, in.progress, 0) {
			t.Fatalf("invalid input %+v", in)
		}
	}
	if (*Core)(nil).GrowRecordArenasFromObservedDensity(10000, 625, 0) {
		t.Fatal("nil core projected")
	}
	if c.FootprintBytes() != before {
		t.Fatal("invalid progress allocated")
	}
}
func TestObservedRecordDensityHonorsLimitsOnLargestSource(t *testing.T) {
	c := projectionFixture(t)
	c.limits.MaxNodes, c.limits.MaxLinks, c.limits.MaxSubtrees, c.limits.MaxChildren = 120, 110, 100, 90
	source := int(1<<31 - 1)
	if strconv.IntSize == 64 {
		value := uint64(1<<32 - 1)
		source = int(value)
	}
	if !c.GrowRecordArenasFromObservedDensity(source, uint32(source/16), 0) {
		t.Fatal("bounded projection refused")
	}
	if c.nodes.Capacity() > 120 || cap(c.nodeLineages) > 120 || c.links.Capacity() > 110 || c.subtrees.Capacity() > 100 || cap(c.children) > 90 {
		t.Fatal("record limits exceeded")
	}
}

func TestObservedRecordDensityChargesBlockedMetadataWithinCeiling(t *testing.T) {
	for _, additional := range []uint64{64, 511, 1 << 15, 1 << 19} {
		c := &Core{limits: Limits{MaxNodes: 1 << 20, MaxLinks: 1 << 20, MaxSubtrees: 1 << 20, MaxChildren: 1 << 20}}
		c.nodes.Grow(nodeRecordBlockSize)
		c.nodeLineages = growArena(c.nodeLineages, nodeRecordBlockSize)
		c.subtrees.Grow(subtreeRecordBlockSize)
		for i := 0; i < 10000; i++ {
			if _, ok := c.nodes.Append(nodeRecord{state: 1, byteOffset: uint32(i)}, c.limits.MaxNodes); !ok {
				t.Fatal("node setup")
			}
			if _, ok := c.subtrees.Append(subtreeRecord{symbol: 1, startByte: uint32(i), endByte: uint32(i + 1), terminal: true}, c.limits.MaxSubtrees); !ok {
				t.Fatal("subtree setup")
			}
		}
		before, work := observedArenaCapacity(c), c.Work()
		grew := c.GrowRecordArenasFromObservedDensity(1<<20, 1<<16, before+additional)
		after := observedArenaCapacity(c)
		if after > before+additional || c.Work() != work || c.nodes.Len() != 10000 || c.subtrees.Len() != 10000 {
			t.Fatal("bounded projection changed records, work, or exceeded the complete capacity ceiling")
		}
		if additional >= 1<<15 && (!grew || len(c.nodes.blocks) == 0 || len(c.subtrees.blocks) == 0) {
			t.Fatal("fixture did not exercise charged block-table growth")
		}
		if c.nodes.At(9999).byteOffset != 9999 || c.subtrees.At(9999).endByte != 10000 {
			t.Fatal("growth changed the existing record prefix")
		}
	}
}
