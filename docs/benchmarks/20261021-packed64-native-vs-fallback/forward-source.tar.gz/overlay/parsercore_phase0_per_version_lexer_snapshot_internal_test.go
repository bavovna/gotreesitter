//go:build gts_parsercorephase0

package gotreesitter

import (
	"bytes"
	"os"
	"reflect"
	"strings"
	"testing"
	"unsafe"

	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
)

func diagnosticParserCoreVersionLexerTestDFA() dfaRelexSnapshot {
	return dfaRelexSnapshot{
		lexerPos:                    17,
		lexerRow:                    3,
		lexerCol:                    9,
		lexerRangeIdx:               2,
		failTokenStartPos:           13,
		failTokenStartRow:           2,
		failTokenStartCol:           8,
		failTokenStartRangeIdx:      1,
		externalPayload:             []byte{0x11, 0x22},
		lastExternalTokenStartByte:  12,
		lastExternalTokenEndByte:    17,
		lastExternalTokenValid:      true,
		lastExternalTokenWasExtra:   true,
		externalTokenEndSameAsStart: true,
		lastTokenStartByte:          12,
		lastTokenEndByte:            17,
		lastTokenValid:              true,
		externalTokenStart:          []byte{0x31, 0x32},
		externalTokenEnd:            []byte{0x41, 0x42},
		extZeroPos:                  17,
		extZeroState:                23,
		extZeroTried:                []bool{true, false, true},
		zeroWidthPos:                17,
		zeroWidthCount:              2,
	}
}

func newDiagnosticParserCoreVersionLexerTestCore(t *testing.T) (*core.Core, core.CheckpointID, core.CheckpointID) {
	t.Helper()
	compact, err := core.New(&genericConflictTable{}, core.Limits{})
	if err != nil {
		t.Fatal(err)
	}
	before, err := compact.InternCheckpoint([]byte{
		0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
	})
	if err != nil {
		t.Fatalf("intern before checkpoint: %v", err)
	}
	after, err := compact.InternCheckpoint([]byte{
		0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19,
	})
	if err != nil {
		t.Fatalf("intern after checkpoint: %v", err)
	}
	return compact, before, after
}

func newDiagnosticParserCoreVersionLexerTestSnapshot(t *testing.T) (*core.Core, *diagnosticParserCoreVersionLexerSnapshot) {
	t.Helper()
	compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalScannerPresent = true
	language := &Language{Name: "snapshot-test", ExternalScanner: byteStateExternalScanner{}}
	var snapshot *diagnosticParserCoreVersionLexerSnapshot
	err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		snapshot, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, before, after)
		return err
	})
	if err != nil {
		t.Fatalf("construct owned lexer snapshot: %v", err)
	}
	return compact, snapshot
}

func TestDiagnosticParserCoreVersionLexerSnapshotCopiesAllMutableState(t *testing.T) {
	compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalScannerPresent = true
	language := &Language{Name: "snapshot-test", ExternalScanner: byteStateExternalScanner{}}
	var snapshot *diagnosticParserCoreVersionLexerSnapshot
	err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		snapshot, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, before, after)
		return err
	})
	if err != nil {
		t.Fatalf("construct owned lexer snapshot: %v", err)
	}
	if snapshot == nil {
		t.Fatal("constructor returned a nil snapshot")
	}
	if snapshot.compact != compact || snapshot.coreGeneration != compact.ResetGeneration() || snapshot.coreGeneration == 0 {
		t.Fatalf("snapshot core binding=%p generation=%d, want core=%p generation=%d", snapshot.compact, snapshot.coreGeneration, compact, compact.ResetGeneration())
	}
	if snapshot.beforeCheckpoint != before || snapshot.afterCheckpoint != after {
		t.Fatalf("checkpoint IDs=%d/%d, want %d/%d", snapshot.beforeCheckpoint, snapshot.afterCheckpoint, before, after)
	}
	if snapshot.beforeCheckpointInfo != parserCoreCheckpoint(snapshot.beforeCheckpointBytes) ||
		snapshot.afterCheckpointInfo != parserCoreCheckpoint(snapshot.afterCheckpointBytes) {
		t.Fatalf("checkpoint metadata does not describe owned bytes: before=%+v after=%+v", snapshot.beforeCheckpointInfo, snapshot.afterCheckpointInfo)
	}

	dfa.externalPayload[0] = 0xff
	dfa.externalTokenStart[0] = 0xff
	dfa.externalTokenEnd[0] = 0xff
	dfa.extZeroTried[0] = false
	dfa.lexerPos = 99
	if !bytes.Equal(snapshot.dfa.externalPayload, []byte{0x11, 0x22}) ||
		!bytes.Equal(snapshot.dfa.externalTokenStart, []byte{0x31, 0x32}) ||
		!bytes.Equal(snapshot.dfa.externalTokenEnd, []byte{0x41, 0x42}) ||
		len(snapshot.dfa.extZeroTried) != 3 || !snapshot.dfa.extZeroTried[0] || snapshot.dfa.lexerPos != 17 ||
		snapshot.dfa.lexerRow != 3 || snapshot.dfa.lexerCol != 9 || snapshot.dfa.lexerRangeIdx != 2 ||
		snapshot.dfa.failTokenStartPos != 13 || snapshot.dfa.failTokenStartRow != 2 ||
		snapshot.dfa.failTokenStartCol != 8 || snapshot.dfa.failTokenStartRangeIdx != 1 ||
		snapshot.dfa.lastExternalTokenStartByte != 12 || snapshot.dfa.lastExternalTokenEndByte != 17 ||
		!snapshot.dfa.lastExternalTokenValid || !snapshot.dfa.lastExternalTokenWasExtra ||
		!snapshot.dfa.externalTokenEndSameAsStart || snapshot.dfa.lastTokenStartByte != 12 ||
		snapshot.dfa.lastTokenEndByte != 17 || !snapshot.dfa.lastTokenValid || snapshot.dfa.extZeroPos != 17 ||
		snapshot.dfa.extZeroState != 23 || snapshot.dfa.zeroWidthPos != 17 || snapshot.dfa.zeroWidthCount != 2 {
		t.Fatalf("snapshot aliases or lost source DFA state: %+v", snapshot.dfa)
	}
	if &snapshot.beforeCheckpointBytes[0] == &snapshot.afterCheckpointBytes[0] {
		t.Fatal("checkpoint copies unexpectedly alias each other")
	}
	if !bytes.Equal(snapshot.beforeCheckpointBytes, []byte{
		0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
	}) || !bytes.Equal(snapshot.afterCheckpointBytes, []byte{
		0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19,
	}) {
		t.Fatalf("owned checkpoint bytes changed: before=%v after=%v", snapshot.beforeCheckpointBytes, snapshot.afterCheckpointBytes)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotPublicationCopiesPublishedState(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	var header diagnosticParserCoreHeader
	if err := header.publishVersionLexerSnapshot(compact, snapshot.language, snapshot); err != nil {
		t.Fatalf("publish lexer snapshot: %v", err)
	}
	published := header.versionLexerSnapshot()
	if published == nil || published == snapshot {
		t.Fatal("publication did not create a distinct snapshot")
	}

	// Mutating the constructor result must not mutate the header-owned copy.
	snapshot.dfa.externalPayload[0] = 0xff
	snapshot.dfa.externalTokenStart[0] = 0xff
	snapshot.dfa.extZeroTried[0] = false
	snapshot.dfa.failTokenStartPos = 99
	snapshot.beforeCheckpointBytes[0] = 0xff
	if published.dfa.externalPayload[0] != 0x11 || published.dfa.externalTokenStart[0] != 0x31 ||
		!published.dfa.extZeroTried[0] || published.dfa.failTokenStartPos != 13 ||
		published.beforeCheckpointBytes[0] != 0x01 {
		t.Fatal("published snapshot aliases the constructor result")
	}

	// Mutating the published copy must not mutate the constructor result either.
	published.dfa.externalTokenEnd[0] = 0xee
	published.dfa.failTokenStartRow = 88
	published.afterCheckpointBytes[0] = 0xee
	if snapshot.dfa.externalTokenEnd[0] != 0x41 || snapshot.dfa.failTokenStartRow != 2 ||
		snapshot.afterCheckpointBytes[0] != 0x11 {
		t.Fatal("constructor snapshot aliases the published copy")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotCloneDoesNotAlias(t *testing.T) {
	_, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	clone := snapshot.clone()
	if clone == nil || clone == snapshot {
		t.Fatal("clone did not create a distinct snapshot")
	}
	clone.dfa.externalPayload[0] = 0xff
	clone.dfa.externalTokenStart[0] = 0xff
	clone.dfa.externalTokenEnd[0] = 0xff
	clone.dfa.extZeroTried[0] = false
	clone.beforeCheckpointBytes[0] = 0xff
	clone.afterCheckpointBytes[0] = 0xff
	if snapshot.dfa.externalPayload[0] != 0x11 || snapshot.dfa.externalTokenStart[0] != 0x31 ||
		snapshot.dfa.externalTokenEnd[0] != 0x41 || !snapshot.dfa.extZeroTried[0] ||
		snapshot.beforeCheckpointBytes[0] != 0x01 || snapshot.afterCheckpointBytes[0] != 0x11 {
		t.Fatal("snapshot clone aliases mutable state")
	}
}

func TestDiagnosticParserCoreVersionLexerCloneEqualityPreservesDistinctOwners(t *testing.T) {
	t.Run("borrowed equality preserves values", func(t *testing.T) {
		_, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
		if !diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, snapshot) {
			t.Fatal("immutable snapshot is not reflexive")
		}
		clone := snapshot.clone()
		if clone == snapshot || !diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) {
			t.Fatal("equivalent distinct snapshot rejected")
		}
		clone.dfa.lexerCol++
		if diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) {
			t.Fatal("distinct cursor accepted")
		}
		clone = snapshot.clone()
		clone.coreGeneration++
		if diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) {
			t.Fatal("distinct core generation accepted")
		}
		clone = snapshot.clone()
		clone.beforeCheckpoint++
		if diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) {
			t.Fatal("distinct checkpoint accepted")
		}
		if diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, nil) || !diagnosticParserCoreVersionLexerSnapshotEqual(nil, nil) {
			t.Fatal("nil snapshot comparison changed")
		}
		var absent *dfaRelexSnapshot
		if !absent.equal(nil) || absent.equal(&snapshot.dfa) || snapshot.dfa.equal(nil) {
			t.Fatal("nil DFA comparison changed")
		}
		t.Logf("DFA_EQUALITY borrowed_bytes_per_argument=%d prior_value_bytes_per_argument=%d", unsafe.Sizeof(absent), unsafe.Sizeof(snapshot.dfa))
	})
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	clone := snapshot.clone()
	if !diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) {
		t.Fatal("equivalent lexer snapshots did not compare equal")
	}
	left := diagnosticParserCoreVersionLexerRequest{
		electionIndex: 4, headerCreationSeq: 9, state: 3,
		token:  Token{Symbol: 7, StartByte: 12, EndByte: 17, lexFlags: tokenFlagKeyword},
		before: snapshot, after: snapshot.clone(),
		beforeCheckpoint: snapshot.beforeCheckpointInfo,
		afterCheckpoint:  snapshot.afterCheckpointInfo,
		beforeID:         snapshot.beforeCheckpoint, afterID: snapshot.afterCheckpoint,
		raggedSpan: true, valid: true,
	}
	right := left
	right.electionIndex = 11
	right.headerCreationSeq = 19
	right.token.setLexFlag(tokenFlagKeyword, false)
	right.before = snapshot.clone()
	right.after = snapshot.clone()
	if !diagnosticParserCoreVersionLexerRequestEqual(&left, &right) {
		t.Fatal("semantically equal lexer requests did not compare equal")
	}
	scheduler := &diagnosticParserCoreGenericScheduler{
		compact:              compact,
		versionLexerRequests: []diagnosticParserCoreVersionLexerRequest{left, right},
	}
	leftState := &diagnosticParserCoreVersionState{relexSnapshot: snapshot, lexerRequest: 1}
	rightState := &diagnosticParserCoreVersionState{relexSnapshot: clone, lexerRequest: 2}
	if scheduler.versionLexerStateEqual(leftState, rightState) {
		t.Fatal("distinct lexer snapshot owners compared equal")
	}
	right.token.EndByte++
	if diagnosticParserCoreVersionLexerRequestEqual(&left, &right) {
		t.Fatal("different lexer request span compared equal")
	}
}

// TestDiagnosticParserCoreVersionLexerRequestEqualIgnoresOriginatingState is
// the regression test for the mechanism behind the perl bounded recursive
// insertion corpus failure: two owned headers can each reduce their own way
// to the identical (token, scanner snapshot) pair through different,
// independently-reduced chains of parser states -- an ordinary GLR
// convergence -- while their own cached lexer requests keep whichever
// parser state each header happened to hold when it first issued the
// request (a pending request survives unchanged across a header's own
// later reduce-only dispatches, since a reduction never re-requests the
// still unconsumed token). Comparing that frozen state field used to report
// the two requests as different solely because they were issued at
// different moments in each header's own history, blocking
// versionLexerStateEqual from recognizing the headers as mergeable and
// letting them separately persist onto the identical compact node instead
// -- "compact head has multiple scheduler owners".
func TestDiagnosticParserCoreVersionLexerRequestEqualIgnoresOriginatingState(t *testing.T) {
	_, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	left := diagnosticParserCoreVersionLexerRequest{
		state:  1542,
		token:  Token{Symbol: 5, StartByte: 1200, EndByte: 1201},
		before: snapshot, after: snapshot,
		beforeCheckpoint: snapshot.beforeCheckpointInfo,
		afterCheckpoint:  snapshot.afterCheckpointInfo,
		beforeID:         snapshot.beforeCheckpoint, afterID: snapshot.afterCheckpoint,
		valid: true,
	}
	right := left
	right.state = 1675
	if !diagnosticParserCoreVersionLexerRequestEqual(&left, &right) {
		t.Fatal("requests reached from different originating parser states, but with an identical token and scanner snapshot, did not compare equal")
	}

	// state cannot mask a real difference: any parser state that would have
	// driven the scanner to a genuinely different result already shows up
	// in the token itself.
	right.token.EndByte++
	if diagnosticParserCoreVersionLexerRequestEqual(&left, &right) {
		t.Fatal("requests with a genuinely different token compared equal")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotInterleavedErrorRunRestoration(t *testing.T) {
	states := []LexState{
		{
			Default: -1,
			EOF:     -1,
			Transitions: []LexTransition{
				{Lo: 'a', Hi: 'a', NextState: 2},
			},
		},
		{
			Default: -1,
			EOF:     -1,
			Transitions: []LexTransition{
				{Lo: 'a', Hi: 'a', NextState: 2},
			},
		},
		{AcceptToken: 1, Default: -1, EOF: -1},
	}
	d := &dfaTokenSource{lexer: &Lexer{
		states:                 states,
		source:                 []byte("xax"),
		failTokenStartPos:      77,
		failTokenStartRow:      8,
		failTokenStartCol:      9,
		failTokenStartRangeIdx: 6,
	}, language: &Language{LexStates: states}}
	d.lexer.errorRunLexState = 1
	d.lexer.hasErrorRunLexState = true

	first := d.snapshotRelexState()
	if tok := d.lexer.NextWithErrorRuns(0); tok.Symbol != errorSymbol || tok.StartByte != 0 || tok.EndByte != 1 {
		t.Fatalf("first error run = %+v, want [0,1)", tok)
	}
	second := d.snapshotRelexState()
	if tok := d.lexer.NextWithErrorRuns(0); tok.Symbol != 1 || tok.StartByte != 1 || tok.EndByte != 2 {
		t.Fatalf("delimiter token = %+v, want [1,2)", tok)
	}
	if tok := d.lexer.NextWithErrorRuns(0); tok.Symbol != errorSymbol || tok.StartByte != 2 || tok.EndByte != 3 {
		t.Fatalf("second error run = %+v, want [2,3)", tok)
	}
	if d.lexer.failTokenStartPos != 2 || d.lexer.failTokenStartCol != 2 {
		t.Fatalf("second failure origin = %d/%d, want 2/2", d.lexer.failTokenStartPos, d.lexer.failTokenStartCol)
	}

	first.restore(d)
	if d.lexer.pos != first.lexerPos || d.lexer.row != first.lexerRow || d.lexer.col != first.lexerCol ||
		d.lexer.includedRangeIdx != first.lexerRangeIdx || d.lexer.failTokenStartPos != 77 ||
		d.lexer.failTokenStartRow != 8 || d.lexer.failTokenStartCol != 9 || d.lexer.failTokenStartRangeIdx != 6 {
		t.Fatalf("first interleaved restore lost lexer failure state: %+v", *d.lexer)
	}
	if tok := d.lexer.NextWithErrorRuns(0); tok.Symbol != errorSymbol || tok.StartByte != 0 || tok.EndByte != 1 {
		t.Fatalf("replayed first error run = %+v, want [0,1)", tok)
	}
	second.restore(d)
	if d.lexer.pos != second.lexerPos || d.lexer.row != second.lexerRow || d.lexer.col != second.lexerCol ||
		d.lexer.includedRangeIdx != second.lexerRangeIdx || d.lexer.failTokenStartPos != second.failTokenStartPos ||
		d.lexer.failTokenStartRow != second.failTokenStartRow || d.lexer.failTokenStartCol != second.failTokenStartCol ||
		d.lexer.failTokenStartRangeIdx != second.failTokenStartRangeIdx {
		t.Fatalf("second interleaved restore lost lexer failure state: %+v", *d.lexer)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotAcceptsEmptyCheckpointIDs(t *testing.T) {
	compact, err := core.New(&genericConflictTable{}, core.Limits{})
	if err != nil {
		t.Fatal(err)
	}
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalPayload = nil
	language := &Language{Name: "snapshot-empty-test"}
	var snapshot *diagnosticParserCoreVersionLexerSnapshot
	err = compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		snapshot, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, 0, 0)
		return err
	})
	if err != nil {
		t.Fatalf("construct empty-checkpoint snapshot: %v", err)
	}
	if snapshot.beforeCheckpoint != 0 || snapshot.afterCheckpoint != 0 || snapshot.beforeCheckpointBytes != nil || snapshot.afterCheckpointBytes != nil ||
		snapshot.beforeCheckpointInfo != parserCoreEmptyCheckpoint || snapshot.afterCheckpointInfo != parserCoreEmptyCheckpoint {
		t.Fatalf("empty checkpoint state=%+v, want zero IDs and empty receipts", snapshot)
	}
	if err := snapshot.validate(); err != nil {
		t.Fatalf("validate empty-checkpoint snapshot: %v", err)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotSurvivesPhaseChangesAndRejectsReset(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	lang := snapshot.language
	payload := lang.ExternalScanner.Create()
	ts := &dfaTokenSource{
		lexer:              &Lexer{source: []byte("abc"), pos: 4, row: 5, col: 6},
		language:           lang,
		hasExternalScanner: true,
		externalPayload:    payload,
	}
	before := *ts.lexer
	resetGeneration := compact.ResetGeneration()
	if err := compact.BeginFrontier(); err != nil {
		t.Fatalf("advance core frontier: %v", err)
	}
	if compact.ResetGeneration() != resetGeneration {
		t.Fatalf("frontier advanced reset generation to %d, want %d", compact.ResetGeneration(), resetGeneration)
	}
	if err := compact.SetPhaseCheckpoint(snapshot.afterCheckpoint); err != nil {
		t.Fatalf("advance checkpoint phase: %v", err)
	}
	if compact.ResetGeneration() != resetGeneration {
		t.Fatalf("checkpoint advanced reset generation to %d, want %d", compact.ResetGeneration(), resetGeneration)
	}
	if err := snapshot.restore(compact, ts); err != nil {
		t.Fatalf("restore rejected a snapshot across phase changes: %v", err)
	}
	if ts.lexer.pos != snapshot.dfa.lexerPos || ts.lexer.row != snapshot.dfa.lexerRow || ts.lexer.col != snapshot.dfa.lexerCol ||
		ts.lexer.includedRangeIdx != snapshot.dfa.lexerRangeIdx || ts.lexer.failTokenStartPos != snapshot.dfa.failTokenStartPos ||
		ts.lexer.failTokenStartRow != snapshot.dfa.failTokenStartRow || ts.lexer.failTokenStartCol != snapshot.dfa.failTokenStartCol ||
		ts.lexer.failTokenStartRangeIdx != snapshot.dfa.failTokenStartRangeIdx {
		t.Fatalf("phase-change restore lost lexer state: got=%+v want=%+v", *ts.lexer, snapshot.dfa)
	}
	if err := compact.Reset(); err != nil {
		t.Fatalf("reset compact core: %v", err)
	}
	if compact.ResetGeneration() == resetGeneration {
		t.Fatalf("reset did not advance reset generation: %d", resetGeneration)
	}
	before = *ts.lexer
	if err := snapshot.restore(compact, ts); err == nil {
		t.Fatal("restore accepted a snapshot from an older reset generation")
	}
	if ts.lexer.pos != before.pos || ts.lexer.row != before.row || ts.lexer.col != before.col ||
		ts.lexer.includedRangeIdx != before.includedRangeIdx || ts.lexer.failTokenStartPos != before.failTokenStartPos ||
		ts.lexer.failTokenStartRow != before.failTokenStartRow || ts.lexer.failTokenStartCol != before.failTokenStartCol ||
		ts.lexer.failTokenStartRangeIdx != before.failTokenStartRangeIdx {
		t.Fatalf("reset-mismatch restore mutated lexer: got=%+v want=%+v", *ts.lexer, before)
	}
	var header diagnosticParserCoreHeader
	if err := header.publishVersionLexerSnapshot(compact, lang, snapshot); err == nil {
		t.Fatal("publication accepted a snapshot from an older reset generation")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotPublicationPreservesRecoveryRegion(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	firstRegion := &diagnosticParserCoreS3Region{state: 7, startByte: 2, endByte: 5, children: []core.SubtreeID{11, 12}}
	secondRegion := &diagnosticParserCoreS3Region{state: 9, startByte: 5, endByte: 8, children: []core.SubtreeID{21, 22}}
	var header diagnosticParserCoreHeader
	header.openRecoveryRegion(firstRegion)
	if err := header.publishVersionLexerSnapshot(compact, snapshot.language, snapshot); err != nil {
		t.Fatalf("publish lexer snapshot: %v", err)
	}
	publishedState := header.versionState
	publishedSnapshot := header.versionLexerSnapshot()
	if publishedState == nil || publishedSnapshot == nil || publishedSnapshot == snapshot {
		t.Fatal("snapshot publication did not create an immutable wrapper copy")
	}
	publishedFirstRegion := header.recoveryRegion()
	if publishedFirstRegion == firstRegion || publishedFirstRegion.state != 7 || publishedFirstRegion.startByte != 2 ||
		publishedFirstRegion.endByte != 5 || len(publishedFirstRegion.children) != 2 ||
		publishedFirstRegion.children[0] != 11 || publishedFirstRegion.children[1] != 12 {
		t.Fatalf("published recovery region=%+v, want an owned copy", publishedFirstRegion)
	}
	firstRegion.state = 70
	firstRegion.startByte = 20
	firstRegion.children[0] = 110
	if publishedFirstRegion.state != 7 || publishedFirstRegion.startByte != 2 || publishedFirstRegion.children[0] != 11 {
		t.Fatal("published recovery region aliases the caller's region or children")
	}

	header.setRecoveryRegion(secondRegion)
	publishedSecondRegion := header.recoveryRegion()
	if publishedSecondRegion == secondRegion || publishedSecondRegion.state != 9 || publishedSecondRegion.startByte != 5 ||
		publishedSecondRegion.endByte != 8 || len(publishedSecondRegion.children) != 2 ||
		publishedSecondRegion.children[0] != 21 || publishedSecondRegion.children[1] != 22 ||
		header.versionLexerSnapshot() != publishedSnapshot {
		t.Fatal("region update did not preserve the published lexer snapshot")
	}
	secondRegion.endByte = 80
	secondRegion.children[1] = 220
	if publishedSecondRegion.endByte != 8 || publishedSecondRegion.children[1] != 22 {
		t.Fatal("updated recovery region aliases the caller's region or children")
	}
	copyOfHeader := header
	header.closeRecoveryRegion()
	if header.recoveryRegion() != nil || header.versionLexerSnapshot() != publishedSnapshot {
		t.Fatal("region closure dropped the lexer snapshot")
	}
	if copyOfHeader.recoveryRegion() != publishedSecondRegion || copyOfHeader.versionLexerSnapshot() != publishedSnapshot {
		t.Fatal("header copy changed after region closure")
	}
	header.clearVersionLexerSnapshot()
	if header.versionState != nil {
		t.Fatal("clearing the only version state left a wrapper")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRollbackRestoresImmutablePointer(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	first := &diagnosticParserCoreS3Region{state: 1}
	second := &diagnosticParserCoreS3Region{state: 2}
	headers := []diagnosticParserCoreHeader{{}}
	headers[0].openRecoveryRegion(first)
	if err := headers[0].publishVersionLexerSnapshot(compact, snapshot.language, snapshot); err != nil {
		t.Fatalf("publish lexer snapshot: %v", err)
	}
	originalState := headers[0].versionState
	originalSnapshot := headers[0].versionLexerSnapshot()
	var scratch diagnosticParserCoreHeaderRollbackScratch
	if err := scratch.begin(headers); err != nil {
		t.Fatalf("begin rollback: %v", err)
	}
	ownedFirst := headers[0].recoveryRegion()
	if ownedFirst == nil || ownedFirst == first || ownedFirst.state != first.state {
		t.Fatalf("published recovery region=%+v, want an owned copy of %+v", ownedFirst, first)
	}
	headers[0].setRecoveryRegion(second)
	headers[0].clearVersionLexerSnapshot()
	scratch.finish(&headers, true)
	restoredRegion := headers[0].recoveryRegion()
	if headers[0].versionState != originalState || headers[0].versionLexerSnapshot() != originalSnapshot || restoredRegion != ownedFirst || restoredRegion.state != first.state {
		t.Fatal("rollback did not restore the complete immutable version state")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRestoreRestoresScannerAndGuards(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	lang := snapshot.language
	payload := lang.ExternalScanner.Create()
	ts := &dfaTokenSource{
		lexer:              &Lexer{source: []byte("abc")},
		language:           lang,
		hasExternalScanner: true,
		externalPayload:    payload,
	}
	if err := snapshot.restore(compact, ts); err != nil {
		t.Fatalf("restore snapshot: %v", err)
	}
	if got := *payload.(*byte); got != 0x11 {
		t.Fatalf("scanner payload=%d, want 17", got)
	}
	if ts.lexer.pos != 17 || ts.lexer.row != 3 || ts.lexer.col != 9 || ts.lexer.includedRangeIdx != 2 {
		t.Fatalf("lexer cursor=%d/%d/%d range=%d, want 17/3/9/2", ts.lexer.pos, ts.lexer.row, ts.lexer.col, ts.lexer.includedRangeIdx)
	}
	if !bytes.Equal(ts.externalTokenStart, []byte{0x31, 0x32}) || !bytes.Equal(ts.externalTokenEnd, []byte{0x41, 0x42}) ||
		ts.extZeroPos != 17 || ts.extZeroState != 23 || len(ts.extZeroTried) != 3 || !ts.extZeroTried[0] ||
		ts.zeroWidthPos != 17 || ts.zeroWidthCount != 2 {
		t.Fatalf("scanner bookkeeping was not restored: %+v", ts)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRequiresOwnedCheckpointAccess(t *testing.T) {
	compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalScannerPresent = true
	language := &Language{Name: "snapshot-owner-test", ExternalScanner: byteStateExternalScanner{}}
	if _, err := newDiagnosticParserCoreVersionLexerSnapshot(compact, language, core.SchedulerTransactionToken{}, dfa, before, after); err == nil {
		t.Fatal("snapshot constructor accepted an unauthenticated owner")
	}
	var stale core.SchedulerTransactionToken
	if err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		stale = owner
		return nil
	}); err != nil {
		t.Fatalf("finish owner session: %v", err)
	}
	if _, err := newDiagnosticParserCoreVersionLexerSnapshot(compact, language, stale, dfa, before, after); err == nil {
		t.Fatal("snapshot constructor accepted a stale owner")
	}
	if err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		if _, err := newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, core.CheckpointID(99), after); err == nil {
			t.Fatal("snapshot constructor accepted a missing checkpoint")
		}
		return nil
	}); err != nil {
		t.Fatalf("finish missing-checkpoint owner session: %v", err)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotFootprintDeduplicatesHeaderCopies(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	region := &diagnosticParserCoreS3Region{children: make([]core.SubtreeID, 1, 3)}
	state := &diagnosticParserCoreVersionState{relexSnapshot: snapshot, recovery: core.ReuseVersionRecoveryState(nil, diagnosticParserCoreVersionRecoveryState{Region: region})}
	baseScheduler := diagnosticParserCoreGenericScheduler{compact: compact}
	base := diagnosticParserCoreSchedulerFootprintBytes(&baseScheduler)
	headers := make([]diagnosticParserCoreHeader, 2, 2)
	headers[0].versionState = state
	headers[1] = headers[0]
	scheduler := diagnosticParserCoreGenericScheduler{compact: compact, headers: headers}
	delta := diagnosticParserCoreSchedulerFootprintBytes(&scheduler) - base
	want := uint64(2)*uint64(unsafe.Sizeof(diagnosticParserCoreHeader{})) +
		diagnosticParserCoreVersionStateFootprintBytes(state) +
		uint64(cap(scheduler.footprintRefs))*uint64(unsafe.Sizeof(diagnosticParserCoreFootprintRef{}))
	if delta != want {
		t.Fatalf("shared version-state footprint delta=%d, want %d", delta, want)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotResetClearsRetainedHeaderBuffers(t *testing.T) {
	_, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	state := &diagnosticParserCoreVersionState{relexSnapshot: snapshot}
	active := make([]diagnosticParserCoreHeader, 1, 2)
	active[0].versionState = state
	rollback := make([]diagnosticParserCoreHeader, 1, 2)
	rollback[0].versionState = state
	canonical := make([]diagnosticParserCoreHeader, 1, 2)
	canonical[0].versionState = state
	conflictOutputs := make([]diagnosticParserCoreHeader, 1, 2)
	conflictOutputs[0].versionState = state
	conflictAssembly := make([]diagnosticParserCoreHeader, 1, 2)
	conflictAssembly[0].versionState = state
	reductions := make([]diagnosticParserCoreHeader, 1, 2)
	reductions[0].versionState = state
	scheduler := diagnosticParserCoreGenericScheduler{
		headers: active,
		canonicalScratch: diagnosticParserCoreCanonicalScratch{
			headerBuffers: [2][]diagnosticParserCoreHeader{canonical, canonical},
		},
		conflictScratch: diagnosticParserCoreConflictScratch{
			outputs:        conflictOutputs,
			headerAssembly: conflictAssembly,
		},
		reductionReplacements: reductions,
	}
	scheduler.headerRollbackScratch.headers = rollback
	scheduler.headerRollbackScratch.inline[0].versionState = state
	scheduler.canonicalScratch.inlineHeaders[0][0].versionState = state
	before := diagnosticParserCoreSchedulerFootprintBytes(&scheduler)
	if err := resetDiagnosticParserCoreGenericScheduler(&scheduler); err != nil {
		t.Fatalf("reset scheduler: %v", err)
	}
	for name, headers := range map[string][]diagnosticParserCoreHeader{
		"active": active, "rollback": rollback, "canonical": canonical,
		"conflict outputs": conflictOutputs, "conflict assembly": conflictAssembly,
		"reductions": reductions,
	} {
		for index, header := range headers[:cap(headers)] {
			if header.versionState != nil {
				t.Fatalf("%s header slot %d retained version state", name, index)
			}
		}
	}
	if scheduler.headerRollbackScratch.inline[0].versionState != nil || scheduler.canonicalScratch.inlineHeaders[0][0].versionState != nil {
		t.Fatal("inline header scratch retained version state after reset")
	}
	if after := diagnosticParserCoreSchedulerFootprintBytes(&scheduler); after >= before {
		t.Fatalf("reset footprint=%d, want below pre-reset %d", after, before)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRetirementClearsLoser(t *testing.T) {
	compact, err := core.New(&genericConflictTable{
		actions: []core.Action{{Type: core.ActionShift, State: 2}},
	}, core.Limits{})
	if err != nil {
		t.Fatal(err)
	}
	survivor, err := compact.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	survivor, err = compact.Shift(survivor, 9, 0, core.Token{
		Symbol: 9, StartByte: 0, EndByte: 1,
	}, core.ForkOrder{})
	if err != nil {
		t.Fatalf("shift survivor: %v", err)
	}
	loser, err := compact.Seed(2, 0)
	if err != nil {
		t.Fatal(err)
	}
	_, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	state := &diagnosticParserCoreVersionState{relexSnapshot: snapshot}
	headers := make([]diagnosticParserCoreHeader, 2, 2)
	headers[0] = diagnosticParserCoreHeader{head: survivor, checkpoint: 0, creationSeq: 1, shifted: true, versionState: state}
	headers[1] = diagnosticParserCoreHeader{head: loser, checkpoint: 0, creationSeq: 2, versionState: state}
	headers[0].markRecoveryLineage()
	headers[1].markRecoveryLineage()
	survivorState := headers[0].versionState
	scheduler := diagnosticParserCoreGenericScheduler{
		compact:           compact,
		headers:           headers,
		checkpointID:      0,
		recoveryIsolation: true,
		epochProgress:     true,
		token:             Token{Symbol: 9, StartByte: 0, EndByte: 1},
		options: DiagnosticParserCorePrefixOptions{
			allowCompactRecoveryLineageSelection:          true,
			allowCompactRecoveryTrailingLineageRetirement: true,
		},
	}
	retired, err := scheduler.retireTrailingRecoveryNoActionLineage([]int{1})
	if err != nil || !retired {
		t.Fatalf("retirement=%t err=%v, want true/nil", retired, err)
	}
	if len(scheduler.headers) != 1 || scheduler.headers[0].versionState == survivorState ||
		scheduler.headers[0].versionLexerSnapshot() != snapshot || scheduler.headers[0].isRecoveryLineage() {
		t.Fatalf("survivor state did not clear lineage while retaining lexer ownership: headers=%+v", scheduler.headers)
	}
	if baseline, set := scheduler.headers[0].recoveryNodeBaseline(); set || baseline != 0 {
		t.Fatalf("retired survivor baseline=%d/%t, want cleared 0/false", baseline, set)
	}
	if headers[1].versionState != nil {
		t.Fatal("retired loser retained its immutable version state")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRejectsCrossCoreDestination(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	other, err := core.New(&genericConflictTable{}, core.Limits{})
	if err != nil {
		t.Fatal(err)
	}
	target := &dfaTokenSource{
		lexer:              &Lexer{source: []byte("abc"), pos: 4, row: 5, col: 6},
		language:           snapshot.language,
		hasExternalScanner: true,
		externalPayload:    snapshot.language.ExternalScanner.Create(),
	}
	before := *target.lexer
	if err := snapshot.restore(other, target); err == nil {
		t.Fatal("restore accepted a snapshot for a different Core")
	}
	if !reflect.DeepEqual(*target.lexer, before) {
		t.Fatalf("cross-Core restore mutated the target lexer: got=%+v want=%+v", *target.lexer, before)
	}
	var header diagnosticParserCoreHeader
	if err := header.publishVersionLexerSnapshot(other, snapshot.language, snapshot); err == nil {
		t.Fatal("publication accepted a snapshot for a different Core")
	}
	if header.versionState != nil {
		t.Fatal("failed cross-Core publication installed version state")
	}
	if compact == other {
		t.Fatal("test Cores unexpectedly alias")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRejectsCrossLanguageDestination(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	otherLanguage := &Language{Name: "other-snapshot-test", ExternalScanner: byteStateExternalScanner{}}
	target := &dfaTokenSource{
		lexer:              &Lexer{source: []byte("abc"), pos: 4, row: 5, col: 6},
		language:           otherLanguage,
		hasExternalScanner: true,
		externalPayload:    otherLanguage.ExternalScanner.Create(),
	}
	before := *target.lexer
	if err := snapshot.restore(compact, target); err == nil {
		t.Fatal("restore accepted a snapshot for a different Language")
	}
	if !reflect.DeepEqual(*target.lexer, before) {
		t.Fatalf("cross-Language restore mutated the target lexer: got=%+v want=%+v", *target.lexer, before)
	}
	var header diagnosticParserCoreHeader
	if err := header.publishVersionLexerSnapshot(compact, otherLanguage, snapshot); err == nil {
		t.Fatal("publication accepted a snapshot for a different Language")
	}
	if header.versionState != nil {
		t.Fatal("failed cross-Language publication installed version state")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRejectsScannerReplacement(t *testing.T) {
	compact, snapshot := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	language := snapshot.language
	originalScanner := language.ExternalScanner
	language.ExternalScanner = checkpointByteExternalScanner{}
	defer func() { language.ExternalScanner = originalScanner }()
	target := &dfaTokenSource{
		lexer:              &Lexer{source: []byte("abc"), pos: 4, row: 5, col: 6},
		language:           language,
		hasExternalScanner: true,
		externalPayload:    language.ExternalScanner.Create(),
	}
	before := *target.lexer
	if err := snapshot.restore(compact, target); err == nil {
		t.Fatal("restore accepted a replacement scanner contract")
	}
	if !reflect.DeepEqual(*target.lexer, before) {
		t.Fatalf("scanner-mismatch restore mutated the target lexer: got=%+v want=%+v", *target.lexer, before)
	}
	var header diagnosticParserCoreHeader
	if err := header.publishVersionLexerSnapshot(compact, language, snapshot); err == nil {
		t.Fatal("publication accepted a replacement scanner contract")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRejectsChangedCheckpointCopies(t *testing.T) {
	_, original := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	for _, test := range []struct {
		name   string
		mutate func(*diagnosticParserCoreVersionLexerSnapshot)
	}{
		{"before_bytes", func(s *diagnosticParserCoreVersionLexerSnapshot) { s.beforeCheckpointBytes[0] ^= 1 }},
		{"after_bytes", func(s *diagnosticParserCoreVersionLexerSnapshot) { s.afterCheckpointBytes[0] ^= 1 }},
		{"length", func(s *diagnosticParserCoreVersionLexerSnapshot) { s.beforeCheckpointInfo.Length++ }},
		{"digest", func(s *diagnosticParserCoreVersionLexerSnapshot) { s.afterCheckpointInfo.SHA256[0] ^= 1 }},
		{"forged_copy_and_receipt", func(s *diagnosticParserCoreVersionLexerSnapshot) {
			s.beforeCheckpointBytes[0] ^= 1
			s.beforeCheckpointInfo = parserCoreCheckpoint(s.beforeCheckpointBytes)
		}},
	} {
		t.Run(test.name, func(t *testing.T) {
			snapshot := original.clone()
			test.mutate(snapshot)
			if err := snapshot.validate(); err == nil {
				t.Fatal("changed checkpoint copy was accepted")
			}
		})
	}
	if err := original.validate(); err != nil {
		t.Fatalf("private-copy checks changed the original snapshot: %v", err)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotBindsCheckpointIdentity(t *testing.T) {
	compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	scanner := newC26lCheckpointScanner()
	language := &Language{Name: "checkpoint-identity-snapshot-test", ExternalScanner: scanner}
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalScannerPresent = true
	dfa.externalPayload = []byte{1, 2, 3}
	var snapshot *diagnosticParserCoreVersionLexerSnapshot
	if err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		snapshot, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, before, after)
		return err
	}); err != nil {
		t.Fatalf("construct identity-bound snapshot: %v", err)
	}
	if snapshot == nil {
		t.Fatal("constructed checkpoint identity snapshot is nil")
	}
	if !snapshot.metadata.Value().checkpointIdentityValid || snapshot.metadata.Value().checkpointIdentity == ([32]byte{}) {
		t.Fatalf("snapshot identity=%x/%t, want a non-zero authenticated identity", snapshot.metadata.Value().checkpointIdentity, snapshot.metadata.Value().checkpointIdentityValid)
	}
	if !snapshot.metadata.Value().checkpointIdentityRequired {
		t.Fatal("snapshot did not record that its scanner requires checkpoint identity")
	}
	clone := snapshot.clone()
	if clone == nil || clone.metadata.Value().checkpointIdentity != snapshot.metadata.Value().checkpointIdentity ||
		!clone.metadata.Value().checkpointIdentityRequired || !clone.metadata.Value().checkpointIdentityValid {
		t.Fatal("snapshot clone lost checkpoint identity")
	}

	target := &dfaTokenSource{
		lexer:              &Lexer{source: []byte("abc"), pos: 4, row: 5, col: 6},
		language:           language,
		hasExternalScanner: true,
		externalPayload:    scanner.Create(),
	}
	beforeTarget := target.snapshotRelexState()
	scanner.grammarID = []byte("checkpoint-identity-drift")
	if err := snapshot.restore(compact, target); err == nil {
		t.Fatal("restore accepted a changed checkpoint identity")
	}
	if got := target.snapshotRelexState(); !got.equal(&beforeTarget) {
		t.Fatalf("identity-mismatch restore mutated target state: got=%+v want=%+v", got, beforeTarget)
	}
	var header diagnosticParserCoreHeader
	if err := header.publishVersionLexerSnapshot(compact, language, snapshot); err == nil {
		t.Fatal("publication accepted a changed checkpoint identity")
	}
	if header.versionState != nil {
		t.Fatal("failed identity-drift publication installed version state")
	}

	scanner.grammarID = []byte("grammar-c26l")
	if err := snapshot.restore(compact, target); err != nil {
		t.Fatalf("restore rejected the original checkpoint identity: %v", err)
	}

	scheduler := &diagnosticParserCoreGenericScheduler{
		compact:     compact,
		tokenSource: &dfaTokenSource{language: language},
		headers: []diagnosticParserCoreHeader{{
			versionState: &diagnosticParserCoreVersionState{relexSnapshot: snapshot},
		}},
	}
	if got := scheduler.equivalentVersionLexerSnapshot(snapshot.dfa, before, after); got != snapshot {
		t.Fatalf("equivalent snapshot lookup = %p, want %p", got, snapshot)
	}
	scanner.grammarID = []byte("checkpoint-identity-drift-again")
	if got := scheduler.equivalentVersionLexerSnapshot(snapshot.dfa, before, after); got != nil {
		t.Fatalf("equivalent snapshot lookup reused identity-drifted snapshot %p", got)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRejectsIncompleteCheckpointIdentity(t *testing.T) {
	compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	scanner := newC26lCheckpointScanner()
	scanner.identityOK = false
	language := &Language{Name: "incomplete-checkpoint-identity-snapshot-test", ExternalScanner: scanner}
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalScannerPresent = true
	dfa.externalPayload = []byte{1, 2, 3}
	err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		_, err := newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, before, after)
		return err
	})
	if err == nil || !strings.Contains(err.Error(), "requires a complete checkpoint identity") {
		t.Fatalf("incomplete checkpoint identity error=%v, want the identity rejection", err)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotRejectsUnrepresentableScannerState(t *testing.T) {
	compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalPayload = nil
	dfa.externalScannerPresent = true
	language := &Language{Name: "unrepresentable-snapshot-test", ExternalScanner: byteStateExternalScanner{}}
	err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		_, err := newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, before, after)
		return err
	})
	if err == nil {
		t.Fatal("constructor accepted an unrepresentable external scanner state")
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotAcceptsSameContractIDZero(t *testing.T) {
	compact, err := core.New(&genericConflictTable{}, core.Limits{})
	if err != nil {
		t.Fatal(err)
	}
	language := &Language{Name: "empty-contract-snapshot-test"}
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalPayload = nil
	var snapshot *diagnosticParserCoreVersionLexerSnapshot
	err = compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		snapshot, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, 0, 0)
		return err
	})
	if err != nil {
		t.Fatalf("construct ID-zero snapshot: %v", err)
	}
	target := &dfaTokenSource{lexer: &Lexer{source: []byte("abc")}, language: language}
	if err := snapshot.restore(compact, target); err != nil {
		t.Fatalf("same-contract ID-zero restore failed: %v", err)
	}
	var header diagnosticParserCoreHeader
	if err := header.publishVersionLexerSnapshot(compact, language, snapshot); err != nil {
		t.Fatalf("same-contract ID-zero publication failed: %v", err)
	}
}

func TestDiagnosticParserCoreVersionLexerSnapshotSharedPrivateCheckpointOwnership(t *testing.T) {
	compact, _, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	original, ok := compact.CopyCheckpointBytes(after, nil)
	if !ok {
		t.Fatal("checkpoint bytes unavailable")
	}
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalScannerPresent = true
	dfa.externalPayload = append([]byte(nil), original...)
	language := &Language{Name: "snapshot-test", ExternalScanner: byteStateExternalScanner{}}
	var snapshot *diagnosticParserCoreVersionLexerSnapshot
	if err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		snapshot, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, after, after)
		return err
	}); err != nil {
		t.Fatal(err)
	}
	dfa.externalPayload[0] ^= 1
	if err := snapshot.validate(); err != nil {
		t.Fatalf("source mutation reached snapshot: %v", err)
	}
	clone := snapshot.clone()
	snapshot.afterCheckpointBytes[0] ^= 1
	// Forge the private receipts as well: the independent interner must still
	// reject tampering when all three private views originally represented the
	// same scanner state.
	snapshot.beforeCheckpointInfo = parserCoreCheckpoint(snapshot.beforeCheckpointBytes)
	snapshot.afterCheckpointInfo = parserCoreCheckpoint(snapshot.afterCheckpointBytes)
	if err := snapshot.validate(); err == nil {
		t.Fatal("tampered private state matched authoritative checkpoint")
	}
	if err := clone.validate(); err != nil {
		t.Fatalf("snapshot mutation reached clone: %v", err)
	}
	retained, ok := compact.CopyCheckpointBytes(after, nil)
	if !ok || !bytes.Equal(retained, original) {
		t.Fatal("snapshot mutation reached checkpoint interner")
	}
	clone.dfa.externalPayload[0] ^= 1
	if !bytes.Equal(retained, original) {
		t.Fatal("clone mutation reached copied checkpoint bytes")
	}
}

func TestDiagnosticParserCoreVersionLexerMetadataReusePreservesOldBindings(t *testing.T) {
	compact, first := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	scheduler := diagnosticParserCoreGenericScheduler{compact: compact, tokenSource: &dfaTokenSource{language: first.language}}
	var second, third *diagnosticParserCoreVersionLexerSnapshot
	if err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		second, err = scheduler.newVersionLexerSnapshot(owner, first.dfa, first.beforeCheckpoint, first.afterCheckpoint)
		if err != nil {
			return err
		}
		third, err = scheduler.newVersionLexerSnapshot(owner, first.dfa, first.beforeCheckpoint, first.afterCheckpoint)
		return err
	}); err != nil {
		t.Fatal(err)
	}
	if second == third || second.metadata != third.metadata {
		t.Fatal("snapshots did not share only immutable metadata")
	}
	clone := second.clone()
	if clone.metadata != second.metadata {
		t.Fatal("clone copied immutable metadata")
	}
	clone.coreGeneration++
	if err := clone.validate(); err == nil {
		t.Fatal("changed clone generation remained authenticated")
	}
	if err := second.validate(); err != nil {
		t.Fatalf("clone changed original binding: %v", err)
	}
	retained := second.metadata
	if err := resetDiagnosticParserCoreGenericScheduler(&scheduler); err != nil {
		t.Fatal(err)
	}
	if scheduler.versionLexerMetadata != retained {
		t.Fatal("reset discarded bounded immutable metadata")
	}
	oldFootprint := diagnosticParserCoreSchedulerFootprintBytes(&scheduler)
	scheduler.versionLexerMetadata = nil
	if oldFootprint-diagnosticParserCoreSchedulerFootprintBytes(&scheduler) != uint64(unsafe.Sizeof(*retained)) {
		t.Fatal("retained metadata escaped footprint accounting")
	}
	scheduler.versionLexerMetadata = retained
	scheduler.compact = compact
	scheduler.tokenSource = &dfaTokenSource{language: first.language}
	first.language.ExternalScanner = &byteStateExternalScanner{}
	var changed *diagnosticParserCoreVersionLexerSnapshot
	if err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		changed, err = scheduler.newVersionLexerSnapshot(owner, first.dfa, first.beforeCheckpoint, first.afterCheckpoint)
		return err
	}); err != nil {
		t.Fatal(err)
	}
	if changed.metadata == retained || second.metadata != retained {
		t.Fatal("replacement mutated old immutable metadata")
	}
	if err := second.validate(); err == nil {
		t.Fatal("old snapshot accepted replacement scanner")
	}
	if err := changed.validate(); err != nil {
		t.Fatalf("replacement snapshot invalid: %v", err)
	}
}

func sharedCheckpointRequestFixture(t *testing.T) (*diagnosticParserCoreGenericScheduler, *diagnosticParserCoreVersionLexerRequest) {
	t.Helper()
	c, before := newDiagnosticParserCoreVersionLexerTestSnapshot(t)
	dfa := before.dfa
	dfa.lexerPos++
	var after *diagnosticParserCoreVersionLexerSnapshot
	if err := c.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		after, err = newDiagnosticParserCoreVersionLexerSnapshotWithMetadata(c, before.language, owner, dfa, before.afterCheckpoint, before.afterCheckpoint, before.metadata)
		return err
	}); err != nil {
		t.Fatal(err)
	}
	beforeBytes, afterBytes := after.beforeCheckpointBytes, after.afterCheckpointBytes
	if after.metadata != before.metadata || after.beforeCheckpoint != after.afterCheckpoint || len(beforeBytes) != len(afterBytes) || len(beforeBytes) > 0 && &beforeBytes[0] != &afterBytes[0] {
		t.Fatal("fixture lacks a shared binding and private checkpoint copy")
	}
	return &diagnosticParserCoreGenericScheduler{compact: c, tokenSource: &dfaTokenSource{language: before.language}}, &diagnosticParserCoreVersionLexerRequest{
		before: before, after: after, beforeID: before.afterCheckpoint, afterID: after.afterCheckpoint,
		beforeCheckpoint: before.afterCheckpointInfo, afterCheckpoint: after.afterCheckpointInfo,
	}
}

func TestVersionLexerPairedValidationKeepsEverySecondSnapshotGuard(t *testing.T) {
	tests := []struct {
		name   string
		mutate func(*diagnosticParserCoreVersionLexerRequest)
	}{
		{"generation", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.coreGeneration++ }},
		{"scanner_presence", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.dfa.externalScannerPresent = false }},
		{"scanner_payload", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.dfa.externalPayload = nil }},
		{"before_bytes", func(r *diagnosticParserCoreVersionLexerRequest) {
			r.after.beforeCheckpointBytes = append([]byte(nil), r.after.beforeCheckpointBytes...)
			r.after.beforeCheckpointBytes[0] ^= 1
		}},
		{"after_bytes", func(r *diagnosticParserCoreVersionLexerRequest) {
			r.after.afterCheckpointBytes = append([]byte(nil), r.after.afterCheckpointBytes...)
			r.after.afterCheckpointBytes[0] ^= 1
		}},
		{"forged_shared_bytes", func(r *diagnosticParserCoreVersionLexerRequest) {
			r.after.afterCheckpointBytes[0] ^= 1
			r.after.beforeCheckpointInfo = parserCoreCheckpoint(r.after.beforeCheckpointBytes)
			r.after.afterCheckpointInfo = parserCoreCheckpoint(r.after.afterCheckpointBytes)
		}},
		{"before_id", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.beforeCheckpoint = ^core.CheckpointID(0) }},
		{"after_id", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.afterCheckpoint = ^core.CheckpointID(0) }},
		{"before_length", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.beforeCheckpointInfo.Length++ }},
		{"after_length", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.afterCheckpointInfo.Length++ }},
		{"before_digest", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.beforeCheckpointInfo.SHA256[0] ^= 1 }},
		{"after_digest", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.afterCheckpointInfo.SHA256[0] ^= 1 }},
		{"request_id", func(r *diagnosticParserCoreVersionLexerRequest) { r.afterID++ }},
		{"request_receipt", func(r *diagnosticParserCoreVersionLexerRequest) { r.afterCheckpoint.Length++ }},
		{"different_language", func(r *diagnosticParserCoreVersionLexerRequest) { copy := *r.after.language; r.after.language = &copy }},
		{"different_metadata", func(r *diagnosticParserCoreVersionLexerRequest) {
			value := r.after.metadata.Value()
			value.scanner.fingerprint[0] ^= 1
			r.after.metadata = core.ReuseFrozenValue(nil, value)
		}},
		{"missing_metadata", func(r *diagnosticParserCoreVersionLexerRequest) { r.after.metadata = nil }},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s, r := sharedCheckpointRequestFixture(t)
			if !s.versionLexerRequestSnapshotsValid(r) {
				t.Fatal("valid request rejected")
			}
			tt.mutate(r)
			if s.versionLexerRequestSnapshotsValid(r) {
				t.Fatal("invalid second snapshot accepted")
			}
			if err := r.before.validate(); err != nil {
				t.Fatalf("validation changed first snapshot: %v", err)
			}
		})
	}
}

func TestVersionLexerPairedValidationRechecksDestinationAtEveryCall(t *testing.T) {
	s, r := sharedCheckpointRequestFixture(t)
	if !s.versionLexerRequestSnapshotsValid(r) {
		t.Fatal("valid request rejected")
	}
	original := s.tokenSource.language.ExternalScanner
	s.tokenSource.language.ExternalScanner = nil
	if s.versionLexerRequestSnapshotsValid(r) {
		t.Fatal("replacement scanner retained authentication")
	}
	s.tokenSource.language.ExternalScanner = original
	if !s.versionLexerRequestSnapshotsValid(r) {
		t.Fatal("restored binding rejected")
	}
	if err := s.compact.Reset(); err != nil {
		t.Fatal(err)
	}
	if s.versionLexerRequestSnapshotsValid(r) {
		t.Fatal("reset retained request authentication")
	}
}

type validationBindingSwapScanner struct {
	byteStateExternalScanner
	language *Language
	armed    bool
}

func (s *validationBindingSwapScanner) ExternalScannerIsStateless() bool {
	if s.armed {
		s.armed = false
		s.language.ExternalScanner = byteStateExternalScanner{}
	}
	return false
}

func TestVersionLexerValidationRejectsBindingSwapDuringCapabilityCallback(t *testing.T) {
	c, beforeID, afterID := newDiagnosticParserCoreVersionLexerTestCore(t)
	scanner := &validationBindingSwapScanner{}
	lang := &Language{Name: "callback-binding-test", ExternalScanner: scanner}
	scanner.language = lang
	dfa := diagnosticParserCoreVersionLexerTestDFA()
	dfa.externalScannerPresent = true
	var before, after *diagnosticParserCoreVersionLexerSnapshot
	if err := c.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
		var err error
		before, err = newDiagnosticParserCoreVersionLexerSnapshotWithMetadata(c, lang, owner, dfa, beforeID, afterID, nil)
		if err != nil {
			return err
		}
		dfa.lexerPos++
		after, err = newDiagnosticParserCoreVersionLexerSnapshotWithMetadata(c, lang, owner, dfa, afterID, afterID, before.metadata)
		return err
	}); err != nil {
		t.Fatal(err)
	}
	s := &diagnosticParserCoreGenericScheduler{compact: c, tokenSource: &dfaTokenSource{language: lang}}
	request := &diagnosticParserCoreVersionLexerRequest{before: before, after: after, beforeID: before.afterCheckpoint, afterID: after.afterCheckpoint, beforeCheckpoint: before.afterCheckpointInfo, afterCheckpoint: after.afterCheckpointInfo}
	if !s.versionLexerRequestSnapshotsValid(request) {
		t.Fatal("initial binding was not valid")
	}
	scanner.armed = true
	if s.versionLexerRequestSnapshotsValid(request) {
		t.Fatal("changed scanner binding accepted after capability callback")
	}
	if scanner.armed {
		t.Fatal("capability callback did not run")
	}
}

type validationIdentityBindingSwapScanner struct {
	byteStateExternalScanner
	language *Language
	armed    bool
}

func (*validationIdentityBindingSwapScanner) UsesExternalScannerCheckpoints() bool { return true }
func (s *validationIdentityBindingSwapScanner) CheckpointIdentity() (ExternalScannerCheckpointIdentity, bool) {
	if s.armed {
		s.armed = false
		s.language.ExternalScanner = byteStateExternalScanner{}
	}
	return ExternalScannerCheckpointIdentity{Scanner: []byte("callback-scanner"), Grammar: []byte("callback-grammar")}, true
}

type validationValueBindingSwapScanner struct {
	byteStateExternalScanner
	language   *Language
	armed      *bool
	generation uint8
	tags       []byte
}

func (s validationValueBindingSwapScanner) ExternalScannerIsStateless() bool {
	if *s.armed {
		*s.armed = false
		s.generation++
		s.language.ExternalScanner = s
	}
	return false
}

func TestVersionLexerStandaloneRejectsBindingSwapDuringCapabilityCallback(t *testing.T) {
	for _, capability := range []string{"stateless", "identity", "value"} {
		for _, stage := range []string{"destination", "validate", "publication", "restore"} {
			t.Run(capability+"/"+stage, func(t *testing.T) {
				c, beforeID, afterID := newDiagnosticParserCoreVersionLexerTestCore(t)
				lang := &Language{Name: "callback-binding-test"}
				var arm func()
				var armed func() bool
				if capability == "stateless" {
					scanner := &validationBindingSwapScanner{language: lang}
					lang.ExternalScanner = scanner
					arm = func() { scanner.armed = true }
					armed = func() bool { return scanner.armed }
				} else if capability == "identity" {
					scanner := &validationIdentityBindingSwapScanner{language: lang}
					lang.ExternalScanner = scanner
					arm = func() { scanner.armed = true }
					armed = func() bool { return scanner.armed }
				} else {
					active := false
					scanner := validationValueBindingSwapScanner{language: lang, armed: &active, generation: 1, tags: []byte{7}}
					lang.ExternalScanner = scanner
					arm = func() { active = true }
					armed = func() bool { return active }
				}
				dfa := diagnosticParserCoreVersionLexerTestDFA()
				dfa.externalScannerPresent = true
				var snapshot *diagnosticParserCoreVersionLexerSnapshot
				if err := c.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
					var err error
					snapshot, err = newDiagnosticParserCoreVersionLexerSnapshotWithMetadata(c, lang, owner, dfa, beforeID, afterID, nil)
					return err
				}); err != nil {
					t.Fatal(err)
				}
				if err := snapshot.validate(); err != nil {
					t.Fatalf("initial binding: %v", err)
				}
				target := &dfaTokenSource{lexer: &Lexer{source: []byte("abc"), pos: 4, row: 5, col: 6}, language: lang, hasExternalScanner: true, externalPayload: lang.ExternalScanner.Create()}
				beforeTarget := target.snapshotRelexState()
				var header diagnosticParserCoreHeader
				arm()
				var err error
				switch stage {
				case "destination":
					err = snapshot.validateDestination(c, lang)
				case "validate":
					err = snapshot.validate()
				case "publication":
					err = header.publishOwnedVersionLexerSnapshot(c, lang, snapshot)
				case "restore":
					err = snapshot.restore(c, target)
				}
				if err == nil {
					t.Fatal("changed scanner binding accepted after standalone capability callback")
				}
				if armed() {
					t.Fatal("capability callback did not run")
				}
				if header.versionState != nil {
					t.Fatal("failed validation published version state")
				}
				if got := target.snapshotRelexState(); !got.equal(&beforeTarget) {
					t.Fatal("failed validation changed destination lexer")
				}
			})
		}
	}
}

func TestDiagnosticParserCoreVersionLexerCoallocatedStorageBudgetAndGeneration(t *testing.T) {
	for _, tc := range []struct {
		name string
		size int
	}{{"small", 2}, {"wide", 40}} {
		t.Run(tc.name, func(t *testing.T) {
			payloadSize := tc.size
			compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
			dfa := diagnosticParserCoreVersionLexerTestDFA()
			dfa.externalScannerPresent = true
			dfa.externalPayload = bytes.Repeat([]byte{0x11}, payloadSize)
			dfa.extZeroTried = make([]bool, 113)
			dfa.extZeroTried[0], dfa.extZeroTried[112] = true, true
			wantDFA := cloneDiagnosticParserCoreDFARelexSnapshot(dfa)
			language := &Language{Name: "snapshot-test", ExternalScanner: byteStateExternalScanner{}}
			var snapshot *diagnosticParserCoreVersionLexerSnapshot
			err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
				var err error
				snapshot, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, before, after)
				return err
			})
			if err != nil || snapshot == nil {
				t.Fatalf("construct snapshot: %v", err)
			}
			logicalDFA := snapshot.dfa
			logicalDFA.extZeroTried = snapshot.triedMask.Restore(nil)
			if !reflect.DeepEqual(logicalDFA, wantDFA) {
				t.Fatal("coallocation changed captured DFA values")
			}
			reserved := 32
			if payloadSize > 32 {
				reserved = 64
			}
			if cap(snapshot.dfa.externalPayload)+cap(snapshot.dfa.externalTokenStart)+cap(snapshot.dfa.externalTokenEnd) != reserved || snapshot.triedMask.Len() != 113 || snapshot.dfa.extZeroTried != nil {
				t.Fatal("snapshot did not retain all reserved storage in its field capacities")
			}
			wantFootprint := uint64(unsafe.Sizeof(*snapshot)) + uint64(unsafe.Sizeof(*snapshot.metadata)) + uint64(reserved+cap(snapshot.beforeCheckpointBytes)+cap(snapshot.afterCheckpointBytes))
			if got := diagnosticParserCoreVersionLexerSnapshotFootprintBytes(snapshot); got != wantFootprint {
				t.Fatalf("snapshot footprint %d, want reserved storage %d", got, wantFootprint)
			}
			clone := snapshot.clone()
			if !diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) {
				t.Fatal("independent clone changed snapshot identity")
			}
			dfa.externalPayload[0], dfa.extZeroTried[0] = 0, false
			clone.dfa.externalTokenEnd[0] = 0
			clonedMask := clone.triedMask.Restore(nil)
			clonedMask[112] = false
			clone.triedMask, _ = core.PackScannerTrialMask(clonedMask)
			originalMask := snapshot.triedMask.Restore(nil)
			if snapshot.dfa.externalPayload[0] != 0x11 || snapshot.dfa.externalTokenEnd[0] != 0x41 || !originalMask[0] || !originalMask[112] {
				t.Fatal("coallocated source or clone storage aliases the original snapshot")
			}
			if err := compact.Reset(); err != nil {
				t.Fatal(err)
			}
			for _, stale := range []*diagnosticParserCoreVersionLexerSnapshot{snapshot, clone} {
				if stale.validateGeneration() == nil {
					t.Fatal("coallocated snapshot survived its core generation")
				}
			}
		})
	}
}

func TestFreshSnapshotPagesBudgetCountsPageOnceAndUnusedSlots(t *testing.T) {
	var pages core.ScannerSnapshotPages[diagnosticParserCoreVersionLexerSnapshot]
	var records [2]*diagnosticParserCoreVersionLexerSnapshot
	for i := range records {
		record, p, s, e, z, storage := pages.New([]byte{1}, nil, nil, make([]bool, 113))
		record.storage = storage
		record.dfa.externalPayload, record.dfa.externalTokenStart, record.dfa.externalTokenEnd, record.dfa.extZeroTried = p, s, e, z
		records[i] = record
	}
	model := func(multiple bool) *diagnosticParserCoreGenericScheduler {
		s := &diagnosticParserCoreGenericScheduler{versionLexerSnapshotPages: pages, footprintRefs: make([]diagnosticParserCoreFootprintRef, 0, 32), versionLexerRequests: make([]diagnosticParserCoreVersionLexerRequest, 2)}
		for i := range s.versionLexerRequests {
			record := records[0]
			if multiple {
				record = records[i]
			}
			s.versionLexerRequests[i].before = record
		}
		return s
	}
	one, many := model(false), model(true)
	if a, b := diagnosticParserCoreSchedulerFootprintBytes(one), diagnosticParserCoreSchedulerFootprintBytes(many); a != b {
		t.Fatalf("shared page charged per record: one=%d two=%d", a, b)
	}
	current, wide := pages.CurrentStorage()
	if current == nil || wide != nil {
		t.Fatal("wrong current storage")
	}
	empty := &diagnosticParserCoreGenericScheduler{footprintRefs: make([]diagnosticParserCoreFootprintRef, 0, 32)}
	before := diagnosticParserCoreSchedulerFootprintBytes(empty)
	empty.versionLexerSnapshotPages = pages
	if delta := diagnosticParserCoreSchedulerFootprintBytes(empty) - before; delta != current.FootprintBytes() {
		t.Fatalf("current page charge=%d want=%d", delta, current.FootprintBytes())
	}
	if direct := diagnosticParserCoreVersionLexerSnapshotFootprintBytes(records[0]); direct < current.FootprintBytes() {
		t.Fatal("standalone footprint omitted storage")
	}
}

func TestFreshSnapshotPagesKeepStaleVersionSnapshotImmutable(t *testing.T) {
	source, err := os.ReadFile("internal/benchfixtures/testdata/real/yaml")
	if err != nil {
		t.Fatal(err)
	}
	runner, err := newAdmissionCandidateRunner(NewParser(yamlSelectedProjectionLanguageForTest))
	if err != nil {
		t.Fatal(err)
	}
	tokens := runner.parser.acquireParserDFATokenSourceWithErrorRuns(source, false)
	if tokens == nil {
		t.Fatal("DFA source absent")
	}
	defer tokens.Close()
	dfa := tokens.snapshotRelexState()
	dfa.extZeroTried = make([]bool, len(runner.lang.ExternalSymbols))
	create := func() *diagnosticParserCoreVersionLexerSnapshot {
		checkpoint, err := runner.compact.InternCheckpoint(dfa.externalPayload)
		if err != nil {
			t.Fatal(err)
		}
		if err := runner.compact.SetPhaseCheckpoint(checkpoint); err != nil {
			t.Fatal(err)
		}
		if _, err := runner.compact.Seed(core.StateID(runner.lang.InitialState), 0); err != nil {
			t.Fatal(err)
		}
		runner.scheduler.compact = runner.compact
		runner.scheduler.tokenSource = tokens
		var result *diagnosticParserCoreVersionLexerSnapshot
		err = runner.compact.RunFreshSchedulerSession(func(owner core.SchedulerTransactionToken) error {
			var buildErr error
			result, buildErr = runner.scheduler.newVersionLexerSnapshot(owner, dfa, checkpoint, checkpoint)
			return buildErr
		})
		if err != nil {
			t.Fatal(err)
		}
		return result
	}
	retained := create()
	if retained.storage == nil {
		t.Fatalf("real scanner shape missed pages: payload=%d start=%d end=%d mask=%d", len(dfa.externalPayload), len(dfa.externalTokenStart), len(dfa.externalTokenEnd), len(dfa.extZeroTried))
	}
	data := bytes.Clone(retained.dfa.externalPayload)
	generation, storage := retained.coreGeneration, retained.storage
	if err := resetDiagnosticParserCoreGenericScheduler(&runner.scheduler); err != nil {
		t.Fatal(err)
	}
	if a, b := runner.scheduler.versionLexerSnapshotPages.CurrentStorage(); a != nil || b != nil {
		t.Fatal("scheduler retained a page after reset")
	}
	if err := runner.compact.Reset(); err != nil {
		t.Fatal(err)
	}
	next := create()
	if next == retained || next.storage == storage {
		t.Fatal("reset recycled a published address")
	}
	if retained.coreGeneration != generation || retained.storage != storage || !bytes.Equal(retained.dfa.externalPayload, data) {
		t.Fatal("reset overwrote a published snapshot")
	}
	if err := retained.validateDestination(runner.compact, runner.lang); err == nil {
		t.Fatal("stale snapshot regained authority")
	}
	clone := retained.clone()
	if clone.storage != nil {
		t.Fatal("independent clone still charged to original page")
	}
	if !bytes.Equal(clone.dfa.externalPayload, data) {
		t.Fatal("clone changed bytes")
	}
}

func TestSnapshotPairFootprintMultiplePagesInPointerOrder(t *testing.T) {
	var pages [8]core.ScannerSnapshotPages[diagnosticParserCoreVersionLexerSnapshot]
	var records []*diagnosticParserCoreVersionLexerSnapshot
	var expected uint64
	selected := 0
	var lowest uintptr = ^uintptr(0)
	for i := range pages {
		for j := 0; j < 2; j++ {
			record, p, s, e, z, storage := pages[i].New([]byte{byte(i)}, nil, nil, make([]bool, 113))
			record.storage = storage
			record.dfa.externalPayload, record.dfa.externalTokenStart, record.dfa.externalTokenEnd, record.dfa.extZeroTried = p, s, e, z
			records = append(records, record)
		}
		owner, _ := pages[i].CurrentStorage()
		expected += owner.FootprintBytes()
		if address := uintptr(unsafe.Pointer(owner)); address < lowest {
			lowest = address
			selected = i
		}
	}
	makeModel := func() *diagnosticParserCoreGenericScheduler {
		return &diagnosticParserCoreGenericScheduler{footprintRefs: make([]diagnosticParserCoreFootprintRef, 0, 256), versionLexerRequests: make([]diagnosticParserCoreVersionLexerRequest, len(records))}
	}
	empty, live := makeModel(), makeModel()
	live.versionLexerSnapshotPages = pages[selected]
	for i, record := range records {
		live.versionLexerRequests[len(records)-1-i].before = record
	}
	if delta := diagnosticParserCoreSchedulerFootprintBytes(live) - diagnosticParserCoreSchedulerFootprintBytes(empty); delta != expected {
		t.Fatalf("page accounting=%d want=%d", delta, expected)
	}
}

func TestPackedSnapshotTrialIdentityUsesOnlyActiveCache(t *testing.T) {
	trials := make([]bool, 113)
	trials[0] = true
	mask, _ := core.PackScannerTrialMask(trials)
	left := &diagnosticParserCoreVersionLexerSnapshot{dfa: dfaRelexSnapshot{lexerPos: 5, extZeroPos: 5, extZeroState: 2}, triedMask: mask}
	right := *left
	trials[0], trials[112] = false, true
	right.triedMask, _ = core.PackScannerTrialMask(trials)
	if diagnosticParserCoreVersionLexerSnapshotEqual(left, &right) {
		t.Fatal("active distinct trials compared equal")
	}
	left.dfa.extZeroPos, right.dfa.extZeroPos = 4, 4
	if !diagnosticParserCoreVersionLexerSnapshotEqual(left, &right) {
		t.Fatal("inactive trials changed logical snapshot equality")
	}
}

func TestPacked64SnapshotPagesPreserveFullSnapshotIdentityAndClone(t *testing.T) {
	compact, before, after := newDiagnosticParserCoreVersionLexerTestCore(t)
	language := &Language{Name: "packed64-snapshot-test", ExternalScanner: byteStateExternalScanner{}}
	var pages core.ScannerSnapshotPages[diagnosticParserCoreVersionLexerSnapshot]
	var snapshots [2]*diagnosticParserCoreVersionLexerSnapshot
	for i := range snapshots {
		dfa := diagnosticParserCoreVersionLexerTestDFA()
		dfa.externalScannerPresent = true
		dfa.externalPayload = bytes.Repeat([]byte{0x11}, 33+i*3)
		dfa.extZeroTried = make([]bool, 113)
		dfa.extZeroTried[0], dfa.extZeroTried[64], dfa.extZeroTried[112] = true, true, true
		want := cloneDiagnosticParserCoreDFARelexSnapshot(dfa)
		var independent *diagnosticParserCoreVersionLexerSnapshot
		if err := compact.ApplySchedulerAtomic(func(owner core.SchedulerTransactionToken) error {
			var err error
			snapshots[i], err = newDiagnosticParserCoreVersionLexerSnapshotWithMetadataAndPages(compact, language, owner, dfa, before, after, nil, &pages)
			if err != nil {
				return err
			}
			independent, err = newDiagnosticParserCoreVersionLexerSnapshot(compact, language, owner, dfa, before, after)
			return err
		}); err != nil {
			t.Fatal(err)
		}
		snapshot := snapshots[i]
		if snapshot.storage == nil || snapshot.storage != pages.CurrentPacked64Storage() || snapshot.triedMask.Len() != 113 {
			t.Fatal("real snapshot did not use the packed64 owner")
		}
		logical := snapshot.dfa
		logical.extZeroTried = snapshot.triedMask.Restore(nil)
		if !reflect.DeepEqual(logical, want) || !diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, independent) {
			t.Fatal("packed64 construction changed complete snapshot identity")
		}
		if cap(snapshot.dfa.externalPayload)+cap(snapshot.dfa.externalTokenStart)+cap(snapshot.dfa.externalTokenEnd) != 64 {
			t.Fatal("wide reserved byte storage was not exposed to the byte budget")
		}
		if !initializeFirstVersionPublication(snapshot, diagnosticParserCoreHeader{}, uint32(i+1)) {
			t.Fatal("first publication initialization failed")
		}
		clone := snapshot.clone()
		if !diagnosticParserCoreVersionLexerSnapshotEqual(snapshot, clone) || clone.storage != nil {
			t.Fatal("clone changed logical identity or retained the page owner")
		}
		clone.dfa.externalPayload[0] = 0x99
		dfa.externalPayload[0], dfa.extZeroTried[0] = 0x88, false
		if snapshot.dfa.externalPayload[0] != 0x11 || !snapshot.triedMask.Restore(nil)[0] {
			t.Fatal("snapshot aliases caller or clone storage")
		}
		if err := snapshot.validate(); err != nil {
			t.Fatal(err)
		}
	}
	if snapshots[0].storage != snapshots[1].storage {
		t.Fatal("two real packed64 snapshots did not share their page")
	}
	pages.Reset()
	if pages.CurrentPacked64Storage() != nil {
		t.Fatal("reset retained the page owner")
	}
	for _, snapshot := range snapshots {
		if err := snapshot.validate(); err != nil {
			t.Fatal("owner reset changed live identity:", err)
		}
	}
	if err := compact.Reset(); err != nil {
		t.Fatal(err)
	}
	for _, snapshot := range snapshots {
		if snapshot.validate() == nil {
			t.Fatal("packed64 snapshot survived compact generation reset")
		}
	}
}

func TestPacked64SnapshotPagesChargeAllCurrentAndRetiredStorage(t *testing.T) {
	var pages core.ScannerSnapshotPages[diagnosticParserCoreVersionLexerSnapshot]
	_, _, _, _, _, small := pages.New([]byte{1}, nil, nil, make([]bool, 113))
	_, _, _, _, packed32 := pages.NewPacked([]byte{1}, nil, nil)
	var records [3]*diagnosticParserCoreVersionLexerSnapshot
	var owners [3]*core.ScannerSnapshotStorage
	for i := range records {
		record, payload, start, end, owner := pages.NewPacked(bytes.Repeat([]byte{byte(i + 1)}, 33), nil, nil)
		record.storage = owner
		record.dfa.externalPayload, record.dfa.externalTokenStart, record.dfa.externalTokenEnd = payload, start, end
		records[i], owners[i] = record, owner
	}
	if owners[0] != owners[1] || owners[2] == owners[0] {
		t.Fatal("invalid old/current packed64 witness")
	}
	empty := &diagnosticParserCoreGenericScheduler{footprintRefs: make([]diagnosticParserCoreFootprintRef, 0, 32)}
	current := &diagnosticParserCoreGenericScheduler{versionLexerSnapshotPages: pages, footprintRefs: make([]diagnosticParserCoreFootprintRef, 0, 32)}
	base := diagnosticParserCoreSchedulerFootprintBytes(empty)
	got := diagnosticParserCoreSchedulerFootprintBytes(current) - base
	if want := small.FootprintBytes() + packed32.FootprintBytes() + owners[2].FootprintBytes(); got != want {
		t.Fatalf("unused current-page charge=%d want%d", got, want)
	}
	// Two live records from a retired page retain its complete allocation once.
	for i := 0; i < 2; i++ {
		header := diagnosticParserCoreHeader{}
		if !initializeFirstVersionPublication(records[i], header, uint32(i+1)) {
			t.Fatal("initialization failed")
		}
		header.publishVersionState(nil, records[i], uint32(i+1), 0, 0, 0, false)
		current.headers = append(current.headers, header)
	}
	retired := diagnosticParserCoreSchedulerFootprintBytes(current) - base
	if want := got + owners[0].FootprintBytes() + uint64(cap(current.headers))*uint64(unsafe.Sizeof(diagnosticParserCoreHeader{})); retired != want {
		t.Fatalf("retired shared-page charge=%d want%d", retired, want)
	}
	// Reaching the current page through a request must not charge it twice.
	current.versionLexerRequests = make([]diagnosticParserCoreVersionLexerRequest, 1)
	current.versionLexerRequests[0].before = records[2]
	withRequest := diagnosticParserCoreSchedulerFootprintBytes(current) - base
	if want := retired + uint64(unsafe.Sizeof(diagnosticParserCoreVersionLexerRequest{})); withRequest != want {
		t.Fatalf("current page charged twice: %d want%d", withRequest, want)
	}
	if n := testing.AllocsPerRun(100, func() { diagnosticParserCoreSchedulerFootprintBytes(current) }); n != 0 {
		t.Fatalf("steady footprint allocated%v", n)
	}
}
