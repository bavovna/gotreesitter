package gotreesitter

import "testing"

func TestFullParseNodeCapacityReusesFragmentedStorage(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	target := len(a.nodes) + 17
	for i := 0; i < target; i++ {
		a.allocNode().startByte = uint32(i + 1)
	}
	a.reset()
	primary := &a.nodes[0]
	overflow := &a.nodeSlabs[0].data[0]
	bytes := a.allocatedBytes
	a.ensureFullParseNodeCapacity(target)
	if &a.nodes[0] != primary || len(a.nodeSlabs) != 1 || &a.nodeSlabs[0].data[0] != overflow {
		t.Fatal("reservation replaced retained node storage")
	}
	for i := 0; i < target; i++ {
		if n := a.allocNode(); n.startByte != 0 {
			t.Fatalf("node %d retained data from the previous parse", i)
		}
	}
	if a.allocatedBytes != bytes {
		t.Fatalf("reservation or allocation grew storage: %d -> %d", bytes, a.allocatedBytes)
	}
}

func TestFullParseNodeCapacityGrowsInsufficientStorage(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	a.nodeSlabs = []nodeSlab{{data: make([]Node, 17)}}
	a.recomputeAllocatedBytes()
	target := len(a.nodes) + 18
	a.ensureFullParseNodeCapacity(target)
	if len(a.nodes) != target || len(a.nodeSlabs) != 0 {
		t.Fatalf("insufficient reservation: primary=%d slabs=%d", len(a.nodes), len(a.nodeSlabs))
	}
	bytes := a.allocatedBytes
	for i := 0; i < target; i++ {
		a.allocNode()
	}
	if a.allocatedBytes != bytes {
		t.Fatal("allocation exceeded reserved storage")
	}
}

func TestFullParseNodeCapacityRejectsUsedFragmentedStorage(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	a.nodeSlabs = []nodeSlab{{data: make([]Node, 17)}}
	a.allocNode()
	defer func() {
		if recover() == nil {
			t.Fatal("reservation accepted an arena with live nodes")
		}
	}()
	a.ensureFullParseNodeCapacity(len(a.nodes) + 1)
}

func TestNativeProjectionNodeSlabsBoundTailWithoutMovingNodes(t *testing.T) {
	normal := newNodeArena(arenaClassFull)
	native := newNodeArena(arenaClassFull)
	native.nativeProjectionNodes = true
	target := len(normal.nodes)*6 + 17
	var savedNormal, savedNative []*Node
	for i := 0; i < target; i++ {
		a, b := normal.allocNode(), native.allocNode()
		a.startByte = uint32(i + 1)
		b.startByte = uint32(i + 1)
		if i%10000 == 0 {
			savedNormal = append(savedNormal, a)
			savedNative = append(savedNative, b)
		}
	}
	if normal.used != native.used || normal.used != target {
		t.Fatal("node count changed")
	}
	for i := range savedNormal {
		if savedNormal[i].startByte != savedNative[i].startByte {
			t.Fatal("growth moved a node")
		}
	}
	for _, slab := range native.nodeSlabs {
		if nodeBytesForCap(len(slab.data)) > 1<<20 {
			t.Fatal("native slab exceeded byte ceiling")
		}
	}
	if native.allocatedBytes >= normal.allocatedBytes {
		t.Fatalf("native %d >= normal %d", native.allocatedBytes, normal.allocatedBytes)
	}
}
func TestNativeProjectionNodeSlabsKeepRetainedBacking(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	target := len(a.nodes)*3 + 1
	for i := 0; i < target; i++ {
		a.allocNode()
	}
	a.reset()
	pointers := make([]*Node, len(a.nodeSlabs))
	for i := range a.nodeSlabs {
		pointers[i] = &a.nodeSlabs[i].data[0]
	}
	before := a.allocatedBytes
	a.nativeProjectionNodes = true
	for i := 0; i < target; i++ {
		a.allocNode()
	}
	if a.allocatedBytes != before {
		t.Fatal("retained storage was replaced")
	}
	for i, p := range pointers {
		if p != &a.nodeSlabs[i].data[0] {
			t.Fatal("retained slab moved")
		}
	}
}

func TestNativeProjectionNodeSlabsResetConstructionPolicy(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	a.nativeProjectionNodes = true
	a.reset()
	if a.nativeProjectionNodes {
		t.Fatal("reset retained construction policy")
	}
}
