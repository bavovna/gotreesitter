#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,sys
assert len(sys.argv)==3,'usage: apply-forward.py BASELINE_ROOT NEW_CANDIDATE_ROOT'
here=Path(__file__).resolve().parent;base=Path(sys.argv[1]).resolve();target=Path(sys.argv[2]).resolve();assert not target.exists()
def safe(name):
 p=Path(name);assert not p.is_absolute() and '..' not in p.parts;return p
def verify(root,manifest):
 assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}==set(manifest)
 for name,want in manifest.items():
  p=root/safe(name);assert not p.is_symlink();data=p.read_bytes();assert len(data)==want['bytes'] and hashlib.sha256(data).hexdigest()==want['sha256'],str(p)
before=json.loads((here/'baseline-manifest.json').read_text());after=json.loads((here/'candidate-manifest.json').read_text());delta=json.loads((here/'forward-changes.json').read_text());verify(base,before);target.mkdir()
for name in before:
 destination=target/safe(name);destination.parent.mkdir(parents=True,exist_ok=True);os.link(base/name,destination)
for row in delta['changes']:
 name=row['path'];destination=target/safe(name);destination.parent.mkdir(parents=True,exist_ok=True);data=(here/'overlay'/name).read_bytes();want=row['after'];assert len(data)==want['bytes'] and hashlib.sha256(data).hexdigest()==want['sha256'];temp=destination.with_name(destination.name+'.forward-tmp');assert not temp.exists();temp.write_bytes(data);os.replace(temp,destination)
verify(base,before);verify(target,after);print('D64 and new M both authenticated; shared baseline inodes unchanged')
