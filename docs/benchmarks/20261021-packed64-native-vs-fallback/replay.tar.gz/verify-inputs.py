#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
assert len(sys.argv)==3,'usage: verify-inputs.py BASELINE_ROOT CANDIDATE_ROOT'
for role,root in zip(('baseline','candidate'),map(Path,sys.argv[1:])):
 manifest=json.loads((Path(__file__).resolve().parent/(role+'-manifest.json')).read_text());assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}==set(manifest)
 for name,want in manifest.items():
  p=root/name;assert not p.is_symlink();data=p.read_bytes();assert len(data)==want['bytes'] and hashlib.sha256(data).hexdigest()==want['sha256'],str(p)
print('authenticated approved inputs')
