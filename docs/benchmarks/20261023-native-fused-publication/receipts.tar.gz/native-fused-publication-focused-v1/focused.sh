set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly'
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
cd /candidate
git -c safe.directory=/candidate rev-parse HEAD > /evidence/revision.txt
git -c safe.directory=/candidate diff --binary > /evidence/source.patch
git config --global --add safe.directory /candidate
go version > /evidence/go-version.txt
for tags in gts_parsercorephase0 gts_parsercorephase0,gts_parsercorephase0a,gts_eof_recovery_shadow; do
 for role in baseline candidate; do
  
  cd "/$role"
  go test -tags "$tags" ./internal/parsercorephase0 -count=1 -timeout=6m > "/evidence/$role-core-$tags.log" 2>&1
 done
done
cd /candidate
go test -race -tags gts_parsercorephase0,gts_parsercorephase0a,gts_eof_recovery_shadow ./internal/parsercorephase0 -run '^Test(Materialization|SelectedStore|NativeProjection|SubtreeRecord)' -count=1 -timeout=6m > /evidence/candidate-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -tags gts_parsercorephase0,gts_parsercorephase0a,gts_eof_recovery_shadow ./internal/parsercorephase0 -run '^Test(Materialization|SelectedStore|NativeProjection|SubtreeRecord)' -count=1 -timeout=6m > /evidence/candidate-386.log 2>&1
go test -tags gts_parsercorephase0 . -run '^Test(QuiescentNative|NativeProjection|CompactLegacyRead|CompactReuseDependency)' -count=1 -timeout=6m > /evidence/candidate-root.log 2>&1
printf 'complete\n' > /evidence/complete.txt
