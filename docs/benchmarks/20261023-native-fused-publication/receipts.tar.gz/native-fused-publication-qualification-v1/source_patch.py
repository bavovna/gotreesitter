from pathlib import Path
import difflib,json
m=json.loads(Path('/evidence/source-before.json').read_text())
for n in sorted(m['baseline'].keys() | m['candidate'].keys()):
 if m['baseline'].get(n)==m['candidate'].get(n):continue
 a=(Path('/baseline')/n).read_text() if n in m['baseline'] else ''
 b=(Path('/candidate')/n).read_text() if n in m['candidate'] else ''
 print(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+n if n in m['baseline'] else '/dev/null',tofile='b/'+n if n in m['candidate'] else '/dev/null')),end='')
