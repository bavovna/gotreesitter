set -u
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/workload-started.txt
bash /controls/run.sh
result=$?
python3 /controls/source_hashes.py > /evidence/source-after-final.json
if ! cmp /evidence/source-before.json /evidence/source-after-final.json; then result=125; fi
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/workload-finished.txt
printf '%s\n' "$result" > /evidence/workload-exit-code.txt
exit "$result"
