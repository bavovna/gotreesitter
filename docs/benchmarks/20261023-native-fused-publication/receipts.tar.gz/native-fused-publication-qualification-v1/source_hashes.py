from pathlib import Path
import hashlib,json,subprocess
result={}
for role in ['baseline','candidate']:
 root=Path('/'+role)
 if role=='candidate':
  names=subprocess.check_output(['git','-c','safe.directory=/candidate','ls-files','--cached','--others','--exclude-standard','--','*.go'],cwd=root,text=True).splitlines()
 else:names=[str(f.relative_to(root)) for f in root.rglob('*.go')]
 result[role]={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
print(json.dumps(result,sort_keys=True))
