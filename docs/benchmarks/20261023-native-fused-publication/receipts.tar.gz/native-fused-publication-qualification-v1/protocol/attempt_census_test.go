//go:build gts_parsercorephase0

package gotreesitter

import (
	"bytes"
	"encoding/json"
	"os"
	"testing"

	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
)

func TestStreamedPrefixAttemptCensus(t *testing.T) {
	sample, err := os.ReadFile("internal/benchfixtures/testdata/real/yaml")
	if err != nil {
		t.Fatal(err)
	}
	document := append([]byte("---\n"), sample...)
	document = append(document, '\n')
	for _, owned := range []bool{false, true} {
		for _, fixture := range []struct {
			name   string
			source []byte
		}{{"r4", sample}, {"eof8k", bytes.Repeat(document, 4)}} {
			t.Run(fixture.name+map[bool]string{false: "_ordinary", true: "_owned"}[owned], func(t *testing.T) {
				t.Cleanup(core.SetExternalLexerOwnershipProbeForTest(owned))
				parser := NewParser(yamlSelectedProjectionLanguageForTest)
				parser.SetAdmissionCandidateRoute(true)
				parser.SetCompactCertificationTelemetry(true)
				runner, err := parser.acquireAdmissionCandidateRunner()
				if err != nil {
					t.Fatal(err)
				}
				var attempt compactFreshAttemptWork
				runner.scratch.freshAttemptWork = &attempt
				beforeRoute, beforeFallback := AdmissionCandidateCounters()
				tree, err := parser.Parse(fixture.source)
				runner.scratch.freshAttemptWork = nil
				if err != nil || tree == nil {
					t.Fatalf("parse: %v", err)
				}
				defer tree.Release()
				runtime := tree.ParseRuntime()
				routed, fallback := AdmissionCandidateCounters()
				totalNodes := attempt.allocatedNodes + uint64(runtime.NodesAllocated)
				if tree.compactMaterialized {
					totalNodes -= uint64(runtime.NodesAllocated)
				}
				totalPeak := max(uint64(runtime.MaxStacksSeen), runner.scheduler.work.PeakHeaders)
				row := map[string]any{"fixture": fixture.name, "owned": owned, "compact": routed - beforeRoute, "fallback": fallback - beforeFallback, "returned_nodes": runtime.NodesAllocated, "attempt_nodes": attempt.allocatedNodes, "total_nodes": totalNodes, "returned_tokens": runtime.TokensConsumed, "attempt_final_tokens": runner.scheduler.tokens, "attempt_prior_tokens": attempt.tokens, "returned_peak": runtime.MaxStacksSeen, "attempt_peak": runner.scheduler.work.PeakHeaders, "total_peak": totalPeak, "scheduler_work": runner.scheduler.work}
				encoded, err := json.Marshal(row)
				if err != nil {
					t.Fatal(err)
				}
				t.Logf("ATTEMPT_WORK %s", encoded)
			})
		}
	}
}
