//go:build gts_parsercorephase0

package gotreesitter_test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"testing"

	gts "github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
	"github.com/odvcencio/gotreesitter/internal/benchfixtures"
	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
)

func TestStreamedPrefixPublicWorkCensus(t *testing.T) {
	sample, err := os.ReadFile("internal/benchfixtures/testdata/real/yaml")
	if err != nil {
		t.Fatal(err)
	}
	document := append([]byte("---\n"), sample...)
	document = append(document, '\n')
	for _, mode := range []struct {
		name             string
		candidate, owned bool
	}{
		{"legacy", false, false}, {"ordinary", true, false}, {"owned", true, true},
	} {
		for _, fixture := range []struct {
			name   string
			source []byte
		}{
			{"r4", sample}, {"eof8k", bytes.Repeat(document, 4)},
		} {
			t.Run(fixture.name+"_"+mode.name, func(t *testing.T) {
				t.Cleanup(core.SetExternalLexerOwnershipProbeForTest(mode.owned))
				parser := gts.NewParser(grammars.YamlLanguage())
				parser.SetAdmissionCandidateRoute(mode.candidate)
				parser.SetCompactCertificationTelemetry(true)
				beforeRoute, beforeFallback := gts.AdmissionCandidateCounters()
				tree, err := parser.Parse(fixture.source)
				if err != nil || tree == nil {
					t.Fatalf("full parse: %v", err)
				}
				defer tree.Release()
				runtime := tree.ParseRuntime()
				routed, fallback := gts.AdmissionCandidateCounters()
				full := map[string]any{"nodes": runtime.NodesAllocated, "tokens": runtime.TokensConsumed, "max_versions": runtime.MaxStacksSeen, "compact_peak": runtime.CompactPeakHeaders, "compact": routed - beforeRoute, "fallback": fallback - beforeFallback}
				step := benchfixtures.EditingSession(fixture.source)[0]
				tree.Edit(step.Edit)
				incremental, profile, err := parser.ParseIncrementalProfiled(step.Source, tree)
				if err != nil || incremental == nil {
					t.Fatalf("edit parse: %v", err)
				}
				defer incremental.Release()
				if incremental.RootNode().HasError() || incremental.RootNode().EndByte() != uint32(len(step.Source)) {
					t.Fatal("edit is incomplete or erroneous")
				}
				edit := map[string]any{"nodes": profile.NewNodesAllocated, "tokens": profile.TokensConsumed, "max_versions": profile.MaxStacksSeen, "reused_bytes": profile.ReusedBytes, "splices": profile.BlockSpliceSteps}
				encoded, err := json.Marshal(map[string]any{"fixture": fixture.name, "mode": mode.name, "full": full, "edit": edit})
				if err != nil {
					t.Fatal(err)
				}
				t.Logf("PUBLIC_WORK %s", encoded)
			})
		}
	}
}

func BenchmarkStreamedPrefixYAML(b *testing.B) {
	sample, err := os.ReadFile("internal/benchfixtures/testdata/real/yaml")
	if err != nil {
		b.Fatal(err)
	}
	document := append([]byte("---\n"), sample...)
	document = append(document, '\n')
	for _, mode := range []struct {
		name             string
		candidate, owned bool
	}{{"legacy", false, false}, {"ordinary", true, false}, {"owned", true, true}} {
		for _, fixture := range []struct {
			name   string
			source []byte
		}{{"r4", sample}, {"eof8k", bytes.Repeat(document, 4)}} {
			b.Run(fixture.name+"_"+mode.name, func(b *testing.B) {
				b.Cleanup(core.SetExternalLexerOwnershipProbeForTest(mode.owned))
				benchmarkStreamedPrefixSource(b, grammars.YamlLanguage(), fixture.source, mode.candidate)
			})
		}
	}
}

func BenchmarkStreamedPrefixGo(b *testing.B) {
	for _, fixture := range benchfixtures.GoFullParseFixtures() {
		if fixture.ID != "query_compile" && fixture.ID != "grammargen_lr" {
			continue
		}
		b.Run(fixture.ID, func(b *testing.B) {
			source, err := fixture.Load()
			if err != nil {
				b.Fatal(err)
			}
			benchmarkStreamedPrefixSource(b, grammars.GoLanguage(), source, true)
		})
	}
}

func benchmarkStreamedPrefixSource(b *testing.B, language *gts.Language, source []byte, candidate bool) {
	parser := gts.NewParser(language)
	parser.SetAdmissionCandidateRoute(candidate)
	parse := func() (gts.ParseRuntime, error) {
		tree, err := parser.Parse(source)
		if err != nil || tree == nil {
			return gts.ParseRuntime{}, fmt.Errorf("parse tree=%t: %w", tree != nil, err)
		}
		defer tree.Release()
		if tree.RootNode() == nil || tree.RootNode().HasError() || tree.RootNode().EndByte() != uint32(len(source)) {
			return gts.ParseRuntime{}, fmt.Errorf("incomplete or erroneous parse")
		}
		return tree.ParseRuntime(), nil
	}
	warm, err := parse()
	if err != nil {
		b.Fatal(err)
	}
	beforeRoute, beforeFallback := gts.AdmissionCandidateCounters()
	b.ReportAllocs()
	b.SetBytes(int64(len(source)))
	b.ResetTimer()
	for range b.N {
		runtime, err := parse()
		if err != nil {
			b.Fatal(err)
		}
		if runtime.NodesAllocated != warm.NodesAllocated || runtime.TokensConsumed != warm.TokensConsumed {
			b.Fatal("per-parse work changed")
		}
	}
	b.StopTimer()
	routed, fallback := gts.AdmissionCandidateCounters()
	routed -= beforeRoute
	fallback -= beforeFallback
	if candidate && routed+fallback != uint64(b.N) {
		b.Fatal("inconsistent route totals")
	}
	if !candidate && routed+fallback != 0 {
		b.Fatal("legacy control entered candidate routing")
	}
	b.ReportMetric(float64(routed)/float64(b.N), "compact-routes/op")
	b.ReportMetric(float64(fallback)/float64(b.N), "compact-fallbacks/op")
	b.ReportMetric(float64(warm.NodesAllocated), "public-nodes/op")
	b.ReportMetric(float64(warm.TokensConsumed), "tokens/op")
}
