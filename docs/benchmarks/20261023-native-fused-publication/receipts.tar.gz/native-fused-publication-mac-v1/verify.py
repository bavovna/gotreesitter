from pathlib import Path
import hashlib,json
controls=Path('/controls');expected=json.loads((controls/'remote-current-inputs.json').read_text());pins=json.loads((controls/'expected-effective.json').read_text());overlay=json.loads((controls/'source-overlay.json').read_text())['Replace'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result={}
for role in ['baseline','candidate']:
 root=Path('/'+role);assert not(root/'.git').exists()
 for n,d in expected[role].items():assert sha(root/n)==d['sha256'],(role,n)
 names={str(f.relative_to(root)) for f in root.rglob('*.go')}
 for name,replacement in overlay.items():
  if not name.startswith('/'+role+'/'):continue
  n=name[len(role)+2:]
  if replacement:names.add(n)
  else:names.discard(n)
 result[role]={n:sha(Path(overlay.get(str(root/n),str(root/n)))) for n in sorted(names)}
 assert result[role]==pins[role],role
print(json.dumps(result,sort_keys=True))
