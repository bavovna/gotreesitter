#!/usr/bin/env bash
set -euo pipefail
cd /reference
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1
export GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/pooled/overlay.json'
export GTS_PARITY_C_REF_BUILD_CACHE=/workspace/harness_out/parity_c_ref_cache/linux_amd64
go test ./internal/parsercorephase0 -count=1 -timeout=8m > /evidence/pooled/out/core-all.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(StreamedPrefixWorkspaceLifecycleAndAccounting|StreamedPrefixPublicationMetadata|SinglePrefixRejectsHistoricalOpaqueBindingSwap|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle)$' -count=1 -timeout=8m -v > /evidence/pooled/out/metadata-go-control.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE=yaml go test . -tags gts_parsercorephase0 -run '^TestV1InvariantGateR4EditSession$' -count=1 -timeout=8m -v > /evidence/pooled/out/ordinary-yaml-invariant.log 2>&1
GTS_ADMISSION_CANDIDATE=1 go test . -tags gts_parsercorephase0 -run '^TestProgressArenaOwnedYAMLInvariant$' -count=1 -timeout=8m -v > /evidence/pooled/out/owned-yaml-invariant.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/pooled/out/candidate-counter ./cmd/perfcounterledger > /evidence/pooled/out/candidate-counter-build.log 2>&1
GTS_ADMISSION_CANDIDATE=1 /evidence/pooled/out/candidate-counter --child-route candidate --langs yaml > /evidence/pooled/out/candidate-yaml-counter.json 2> /evidence/pooled/out/candidate-yaml-counter.log
GOFLAGS='-p=1 -buildvcs=false' go build -tags gts_parsercorephase0 -o /evidence/pooled/out/baseline-counter ./cmd/perfcounterledger > /evidence/pooled/out/baseline-counter-build.log 2>&1
GTS_ADMISSION_CANDIDATE=1 /evidence/pooled/out/baseline-counter --child-route candidate --langs yaml > /evidence/pooled/out/baseline-yaml-counter.json 2> /evidence/pooled/out/baseline-yaml-counter.log
GTS_ADMISSION_CANDIDATE=0 /evidence/pooled/out/baseline-counter --child-route default --langs yaml > /evidence/pooled/out/baseline-default-yaml-counter.json 2> /evidence/pooled/out/baseline-default-yaml-counter.log
cd cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/pooled/out/yaml-c.test . > /evidence/pooled/out/build-c.log 2>&1
GTS_YAML_LARGE_PROBE=1 /usr/bin/time -v /evidence/pooled/out/yaml-c.test -test.run '^TestCompact(YAMLDocumentStreamLockedC|YAMLVersionOwnershipCOracle)$' -test.count=1 -test.timeout=8m -test.v > /evidence/pooled/out/yaml-c.log 2>&1
printf 'complete\n' > /evidence/pooled/out/complete.txt
