#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/pooled/perf/complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1
export GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/pooled/timing-overlay.json'
mkdir -p /evidence/pooled/profiles
cd /candidate
go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkStreamedPrefixYAML$/^eof8k_ordinary$' -benchtime=6s -count=1 -cpuprofile=/evidence/pooled/profiles/candidate-yaml.cpu -memprofile=/evidence/pooled/profiles/candidate-yaml.mem -o /evidence/pooled/profiles/candidate-yaml.test > /evidence/pooled/profiles/candidate-yaml.log 2>&1
go tool pprof -top -nodecount=35 /evidence/pooled/profiles/candidate-yaml.test /evidence/pooled/profiles/candidate-yaml.cpu > /evidence/pooled/profiles/candidate-yaml-top.txt 2>&1
go tool pprof -top -alloc_space -nodecount=25 /evidence/pooled/profiles/candidate-yaml.test /evidence/pooled/profiles/candidate-yaml.mem > /evidence/pooled/profiles/candidate-yaml-alloc.txt 2>&1
cd /reference
go test . -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkStreamedPrefixGo$/^query_compile$' -benchtime=6s -count=1 -cpuprofile=/evidence/pooled/profiles/baseline-go.cpu -o /evidence/pooled/profiles/baseline-go.test > /evidence/pooled/profiles/baseline-go.log 2>&1
go tool pprof -top -nodecount=35 /evidence/pooled/profiles/baseline-go.test /evidence/pooled/profiles/baseline-go.cpu > /evidence/pooled/profiles/baseline-go-top.txt 2>&1
printf 'complete\n' > /evidence/pooled/profiles/complete.txt
