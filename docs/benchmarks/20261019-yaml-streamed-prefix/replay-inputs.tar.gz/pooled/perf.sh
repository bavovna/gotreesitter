#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/pooled/census/complete.txt
python3 - <<'PY'
import json
from pathlib import Path
assert json.loads(Path('/evidence/pooled/counter-gate.json').read_text())['passed']
PY
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1
export GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/pooled/timing-overlay.json'
mkdir -p /evidence/pooled/perf
cd /candidate
go version > /evidence/pooled/perf/environment.log
bash scripts/run_randomized_benchmarks.sh \
 --output /evidence/pooled/perf/go-after.txt \
 --baseline-root /reference --baseline-output /evidence/pooled/perf/go-before.txt \
 --bench-regex '^Benchmark(StreamedPrefixGo|GoParseFullDFA|GoParseIncrementalSingleByteEditDFA|GoParseIncrementalNoEditDFA)$' \
 --require-benchmarks BenchmarkStreamedPrefixGo/query_compile,BenchmarkStreamedPrefixGo/grammargen_lr,BenchmarkGoParseFullDFA,BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGoParseIncrementalNoEditDFA \
 --runs 20 --seed-start 35901 --benchtime 750ms > /evidence/pooled/perf/go-runner.log 2>&1
bash scripts/run_randomized_benchmarks.sh \
 --output /evidence/pooled/perf/yaml-after.txt \
 --baseline-root /reference --baseline-output /evidence/pooled/perf/yaml-before.txt \
 --bench-regex '^BenchmarkStreamedPrefixYAML$' \
 --require-benchmarks BenchmarkStreamedPrefixYAML/r4_legacy,BenchmarkStreamedPrefixYAML/eof8k_legacy,BenchmarkStreamedPrefixYAML/r4_ordinary,BenchmarkStreamedPrefixYAML/eof8k_ordinary,BenchmarkStreamedPrefixYAML/r4_owned,BenchmarkStreamedPrefixYAML/eof8k_owned \
 --runs 20 --seed-start 36001 --benchtime 750ms > /evidence/pooled/perf/yaml-runner.log 2>&1
printf 'complete\n' > /evidence/pooled/perf/complete.txt
