//go:build gts_parsercorephase0

package gotreesitter

import (
	"bytes"
	"fmt"
	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
	"os"
	"testing"
)

func TestStreamedPrefixPublicationMetadata(t *testing.T) {
	for _, owned := range []bool{false, true} {
		t.Run(fmt.Sprintf("owned_%t", owned), func(t *testing.T) {
			t.Cleanup(core.SetExternalLexerOwnershipProbeForTest(owned))
			lang := yamlSelectedProjectionLanguageForTest
			if lang == nil {
				t.Fatal("YAML loader absent")
			}
			sample, err := os.ReadFile("internal/benchfixtures/testdata/real/yaml")
			if err != nil {
				t.Fatal(err)
			}
			document := append([]byte("---\n"), sample...)
			document = append(document, '\n')
			for _, fixture := range []struct {
				name   string
				source []byte
			}{{"r4", sample}, {"eof_8k", bytes.Repeat(document, 4)}} {
				t.Run(fixture.name, func(t *testing.T) {
					runner, err := newAdmissionCandidateRunner(NewParser(lang))
					if err != nil {
						t.Fatal(err)
					}
					selected, tokens, err := runner.executeSchedulerOpen(fixture.source, runner.compact, true)
					if tokens != nil {
						defer tokens.Close()
					}
					if err != nil {
						t.Fatal(err)
					}
					work := runner.compact.Work()
					store, err := runner.compact.BuildAuthenticatedSelectedProjectionPlan(selected.acceptedPayloads, fixture.source, func() error { return nil })
					if err != nil {
						t.Fatal(err)
					}
					defer store.Release()
					runner.scratch.nativeProjection = nil
					runner.options.nativeProjectionScratch = nil
					selected.options.nativeProjectionScratch = nil
					native, err := runner.materializeSelection(fixture.source, runner.compact, selected)
					if err != nil {
						t.Fatal(err)
					}
					defer native.Release()
					var workspace nativeProjectionWorkspace
					var attempt compactFreshAttemptWork
					runner.scratch.freshAttemptWork = &attempt
					projected, arena, streamedTree, err := checkedNativeSelectedProjection(store, fixture.source, &workspace, selected, runner)
					runner.scratch.freshAttemptWork = nil
					if err != nil {
						t.Fatal(err)
					}
					if attempt.allocatedNodes != uint64(arena.used) {
						t.Fatalf("attempt charged %d nodes for arena %d", attempt.allocatedNodes, arena.used)
					}
					for _, slots := range [][]*Node{workspace.nodes, workspace.rawNodes, workspace.rootNodes, workspace.proofScratch, runner.scratch.nodes, runner.scratch.linkScratch} {
						for _, node := range slots[:cap(slots)] {
							if node != nil {
								t.Fatal("publication scratch retained a public node")
							}
						}
					}
					defer streamedTree.Release()
					// Fail after emission so rejected work must be charged before arena reset.
					var rejectedWork compactFreshAttemptWork
					runner.scratch.freshAttemptWork = &rejectedWork
					badSource := append(bytes.Clone(fixture.source), byte('@'))
					badRoot, badArena, badTree, badErr := checkedNativeSelectedProjection(nil, badSource, &workspace, selected, runner)
					runner.scratch.freshAttemptWork = nil
					if badErr == nil || badRoot != nil || badArena != nil || badTree != nil || rejectedWork.allocatedNodes == 0 {
						t.Fatalf("rejected publication lost work: nodes=%d root=%p arena=%p err=%v", rejectedWork.allocatedNodes, badRoot, badArena, badErr)
					}
					t.Logf("REJECTED_STREAM_CHARGED nodes=%d err=%v", rejectedWork.allocatedNodes, badErr)

					requireDiagnosticParserCoreSelectedStoreMatchesTree(t, store, projected, lang)
					requireDiagnosticParserCoreSelectedStoreMatchesTree(t, store, native.root, lang)
					type pair struct{ a, b *Node }
					stack := []pair{{projected, native.root}}
					var total, states, proofs, fragile, column, receiptGaps int
					for len(stack) != 0 {
						i := len(stack) - 1
						q := stack[i]
						stack = stack[:i]
						total++
						if q.a.startPoint != q.b.startPoint || q.a.endPoint != q.b.endPoint {
							t.Fatal("YAML source points differ")
						}
						if q.a.parseState != q.b.parseState || q.a.preGotoState != q.b.preGotoState {
							states++
						}
						mask := nodeFlagCompactParseStateProven | nodeFlagCompactPreGotoStateProven
						if q.a.flags&mask != q.b.flags&mask {
							proofs++
						}
						if q.a.isFragileLeft() != q.b.isFragileLeft() || q.a.isFragileRight() != q.b.isFragileRight() {
							fragile++
						}
						if q.a.dependsOnColumn() != q.b.dependsOnColumn() {
							column++
						}
						var projectedWord, nativeWord uint32
						if word := legacyReuseWord(q.a, false); word != nil {
							projectedWord = *word
						}
						if word := legacyReuseWord(q.b, false); word != nil {
							nativeWord = *word
						}
						if projectedWord != nativeWord {
							receiptGaps++
						}
						for c := 0; c < q.a.ChildCount(); c++ {
							stack = append(stack, pair{q.a.Child(c), q.b.Child(c)})
						}
					}
					if runner.compact.Work() != work {
						t.Fatal("projection changed committed work")
					}
					t.Logf("YAML_NATIVE_SELECTED_SHADOW fixture=%s public_nodes=%d native_constructed=%d projected_constructed=%d state_gaps=%d proof_gaps=%d fragility_gaps=%d column_gaps=%d native_checkpoints=%d projected_checkpoints=%d", fixture.name, total, native.arena.used, arena.used, states, proofs, fragile, column, native.arena.externalScannerCheckpointRecords, arena.externalScannerCheckpointRecords)
					if states != 0 || proofs != 0 || fragile != 0 || column != 0 || receiptGaps != 0 {
						t.Fatalf("YAML publication metadata differs: states=%d proofs=%d fragile=%d column=%d receipts=%d", states, proofs, fragile, column, receiptGaps)
					}
				})
			}
		})
	}
}

func TestStreamedPrefixWorkspaceLifecycleAndAccounting(t *testing.T) {
	node := &Node{}
	workspace := &nativeProjectionWorkspace{nodes: make([]*Node, 1, 8), rawNodes: make([]*Node, 1, 8), rootNodes: make([]*Node, 1, 8), proofScratch: make([]*Node, 1, 8)}
	for _, slots := range [][]*Node{workspace.nodes, workspace.rawNodes, workspace.rootNodes, workspace.proofScratch} {
		slots[:cap(slots)][cap(slots)-1] = node
	}
	scheduler := &diagnosticParserCoreGenericScheduler{}
	before := diagnosticParserCoreSchedulerFootprintBytes(scheduler)
	scheduler.options.nativeProjectionScratch = workspace
	if delta := diagnosticParserCoreSchedulerFootprintBytes(scheduler) - before; delta != workspace.retainedBytes() {
		t.Fatalf("scheduler charge=%d workspace=%d", delta, workspace.retainedBytes())
	}
	scratch := parserCoreRunnerScratch{nativeProjection: workspace}
	scratch.resetTreeBuffers()
	for _, slots := range [][]*Node{workspace.nodes, workspace.rawNodes, workspace.rootNodes, workspace.proofScratch} {
		for _, pointer := range slots[:cap(slots)] {
			if pointer != nil {
				t.Fatal("workspace retained a public pointer")
			}
		}
	}
	workspace.lines = make([]uint32, int(parserCoreMaxRetainedComparisonBytes/4)+1)
	workspace.reset()
	if workspace.lines != nil || workspace.nodes != nil || workspace.rawNodes != nil || workspace.metadata != nil {
		t.Fatal("oversized publication workspace was retained")
	}
}
