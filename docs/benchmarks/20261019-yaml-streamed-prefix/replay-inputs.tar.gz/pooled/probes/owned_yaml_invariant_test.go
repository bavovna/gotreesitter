//go:build gts_parsercorephase0

package gotreesitter_test

import (
	"os"
	"testing"

	gts "github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
)

func TestProgressArenaOwnedYAMLInvariant(t *testing.T) {
	if !gts.AdmissionCandidateRouteDefault() {
		t.Fatal("start this process with GTS_ADMISSION_CANDIDATE=1")
	}
	t.Setenv("GOTREESITTER_V1_INVARIANT_LANGUAGE", "yaml")
	t.Cleanup(core.SetExternalLexerOwnershipProbeForTest(true))
	source, err := os.ReadFile("internal/benchfixtures/testdata/real/yaml")
	if err != nil {
		t.Fatal(err)
	}
	parser := gts.NewParser(grammars.YamlLanguage())
	beforeRouted, beforeFallback := gts.AdmissionCandidateCounters()
	tree, err := parser.Parse(source)
	if err != nil || tree == nil {
		t.Fatalf("owned initial parse: %v", err)
	}
	if tree.RootNode().HasError() || tree.RootNode().EndByte() != uint32(len(source)) {
		t.Fatalf("owned initial completion: %s", tree.ParseRuntime().Summary())
	}
	tree.Release()
	routed, fallback := gts.AdmissionCandidateCounters()
	routed -= beforeRouted
	fallback -= beforeFallback
	if routed != 1 || fallback != 0 {
		t.Fatalf("ownership activation did not reach compact: compact=%d fallback=%d", routed, fallback)
	}
	t.Logf("owned initial compact=%d fallback=%d", routed, fallback)
	t.Run("session", TestV1InvariantGateR4EditSession)
}
