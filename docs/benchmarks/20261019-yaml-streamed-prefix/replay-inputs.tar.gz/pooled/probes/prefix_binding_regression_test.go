//go:build gts_parsercorephase0

package gotreesitter

import (
	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
	"testing"
)

type prefixOpaqueScanner struct{ generation func() byte }

//go:noinline
func newPrefixOpaqueScanner(generation byte) ExternalScanner {
	return prefixOpaqueScanner{generation: func() byte { return generation }}
}
func (s prefixOpaqueScanner) Create() any { return []byte{s.generation()} }
func (prefixOpaqueScanner) Destroy(any)   {}
func (prefixOpaqueScanner) Serialize(payload any, buf []byte) int {
	buf[0] = payload.([]byte)[0]
	return 1
}
func (prefixOpaqueScanner) Deserialize(payload any, buf []byte) {
	if len(buf) > 0 {
		payload.([]byte)[0] = buf[0]
	}
}
func (s prefixOpaqueScanner) Scan(payload any, _ *ExternalLexer, _ []bool) bool {
	return payload.([]byte)[0] == s.generation()
}
func (prefixOpaqueScanner) ExternalScannerIsStateless() bool { return false }
func TestSinglePrefixRejectsHistoricalOpaqueBindingSwap(t *testing.T) {
	t.Cleanup(core.SetExternalLexerOwnershipProbeForTest(false))
	original, peer := newPrefixOpaqueScanner(1), newPrefixOpaqueScanner(2)
	if !original.Scan(original.Create(), nil, nil) || peer.Scan(original.Create(), nil, nil) {
		t.Fatal("peer must not own the original payload")
	}

	if core.ScannerBindingUnchanged(original, peer) || core.ScannerFingerprint(original) != core.ScannerFingerprint(peer) {
		t.Fatal("fixture must have distinct bindings with equal contract fingerprints")
	}
	table := &genericConflictTable{cells: map[genericConflictCell][]core.Action{{state: 1, symbol: 1}: {{Type: core.ActionShift, State: 2}, {Type: core.ActionShift, State: 3}}}}
	c, err := core.New(table, core.Limits{})
	if err != nil {
		t.Fatal(err)
	}
	checkpoint, err := c.InternCheckpoint([]byte{1})
	if err != nil {
		t.Fatal(err)
	}
	if err = c.SetPhaseCheckpoint(checkpoint); err != nil {
		t.Fatal(err)
	}
	head, err := c.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	lang := &Language{TokenCount: 2, ExternalSymbols: []Symbol{1}, ExternalScanner: original}
	source := &dfaTokenSource{language: lang, lexer: &Lexer{}, hasExternalScanner: true, externalPayload: original.Create()}
	token := Token{Symbol: 1, ExternalScannerToken: true}
	s := &diagnosticParserCoreGenericScheduler{options: DiagnosticParserCorePrefixOptions{ReceiptMode: DiagnosticParserCoreReceiptSummary}, compact: c, tokenSource: source, headers: []diagnosticParserCoreHeader{{head: head, creationSeq: 1, checkpoint: checkpoint}}, token: token, checkpointBeforeID: checkpoint, checkpointID: checkpoint, electionIndex: -1}
	if err = s.captureSharedElectionSnapshot(); err != nil {
		t.Fatal(err)
	}
	s.electionIndex = 0
	s.currentElection = DiagnosticParserCoreElection{States: []StateID{1}, Token: token}
	s.singleLexerPrefix.Begin(c, head)
	oldContract, err := diagnosticParserCoreVersionLexerScannerContractForLanguage(lang)
	if err != nil {
		t.Fatal(err)
	}
	lang.ExternalScanner = peer
	newContract, err := diagnosticParserCoreVersionLexerScannerContractForLanguage(lang)
	if err != nil || !oldContract.equal(newContract) {
		t.Fatal("fixture changed contract", err)
	}
	if err = c.RunFreshSchedulerSession(func(owner core.SchedulerTransactionToken) error {
		s.freshSessionOwner = &owner
		boundary, err := c.ClassifyBoundary(head, 1)
		if err != nil {
			return err
		}
		activated, err := s.trySinglePrefixLexerOwnership(diagnosticParserCoreGenericCell{headerIndex: 0, boundary: boundary})
		if err != nil || activated || len(s.versionLexerRequests) != 0 || s.versionLexerOwnershipActive || c.VersionLexerOwnershipActive() {
			t.Fatalf("replacement binding entered ownership: activated=%v requests=%d error=%v", activated, len(s.versionLexerRequests), err)
		}
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}
