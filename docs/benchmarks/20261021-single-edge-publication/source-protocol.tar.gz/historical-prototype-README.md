# Fresh single-edge graph publication prototype (N)

N branches directly from qualified D64 `e91e0322f1b094c0995684449f9b90a1a08f4783`; it does not include held native-YAML, L or M changes. It has not been compiled, tested, timed, committed or promoted. All source changes used atomic replacement; the D64 source still matches all3541 original Go pins.

`condenseDirectAppend` keeps its link/node caps, payload and predecessor lookups, exact int64 precedence arithmetic, inherited recovery cost, boundary publication/journaling and phase-zero observation. Its fresh literal edge and node go through a new private single-edge publisher. This retains the original `appendGraphLinkChecked` and the same graph-work increment before node validation. Node cap and checkpoint validation are shared with the general publisher in the original error order.

For a freshly appended nonzero ordinal, a payload-bearing ordinary edge with next=0 has exactly one terminating adjacency. Its shape has already been validated. The specialized check retains the link-count limit and strict predecessor decrease. The other general walker checks follow from the just-created dense ordinal and one appended edge; no record can be changed by a callback between creation and publication. Uncommon flags, recovery discontinuities, nonterminating adjacency and an overflowing link ordinal retain the complete general validator. General copied/multiple-link publication still always runs the original validator.

Both callers share the original node-write body, relocated byte-for-byte: append, lineage flags, full-width path count, inline/wide precedence and checkpoint sidecars. There is no new stored proof token, lifetime cache, record field, allocator, root file, language selector or route change. Checkpoint, journaling and outer transaction ownership remain with their original callers. Invalid node publication still leaves the same temporary link/work mutation for the surrounding transaction to roll back; the optimization does not silently change partial-failure behavior.

## Proposed isolated Docker checks

```
go test ./internal/parsercorephase0 -run '^TestSingleEdge' -count=1
go test ./internal/parsercorephase0 -run '^(TestSingleEdge|TestAppend|TestDAG|TestNodePrecedence|TestNodePathCount|TestPrecedenceMaximum|TestLineageRecovery|TestLinkProvenance)' -count=1
go test ./internal/parsercorephase0 -count=1
go test -race ./internal/parsercorephase0 -run '^(TestSingleEdge|TestDAG|TestNodePrecedence|TestNodePathCount)' -count=1
```

New regressions compare the fresh-edge publisher with the old split publication sequence including the complete general adjacency validator. They cover112 full-width maximum/path-count/order combinations, optional link-reference extension,17 malformed/checkpoint/recovery/work-saturation cases with exact error order and partial mutations, failed-node rollback, nested successful condensation followed by outer rollback, retained boundary journaling, scanner checkpoint identity, inherited recovery cost, logical-ID reuse, both signed precedence-overflow directions and cap/input rejection. Source syntax was formatted only; none of these checks has executed.

The new shared node-write function can affect every grammar through the general path. Parent must run correctness, C parity, D8, phase-zero modes and exact counters before considering timing, then RSS and the standard20 shuffled pairs. Prior Oct20 profiles rank condensation at10.00% of query_compile CPU and5.33% within the grammargen reduction profile; those are old attribution, not N speedup estimates. Compiler/call overhead may outweigh the removed read/validation, so no gain is claimed.

`source-deltas.json`, `source-deltas.patch` and complete baseline/candidate Go pins define this unqualified snapshot.
