from pathlib import Path
import hashlib,json,re,shutil
p=Path('/evidence');lab=Path('/lab')
for role,name,count in [('/candidate','candidate-source-pins.json',3543),('/reference','baseline-source-pins.json',3541)]:
 pins=json.loads((p/name).read_text());assert len(pins)==count,(name,len(pins))
 for rel,want in pins.items():assert hashlib.sha256((Path(role)/rel).read_bytes()).hexdigest()==want,(role,rel)
assert json.loads((p/'baseline-full-counter-gate.json').read_text())['passed']
assert json.loads((p/'baseline-core-mode-audit.json').read_text())['passed']
assert (lab/'focused-complete.txt').read_text().strip()=='complete'
expected={'core-default.log':593,'core-shadow.log':605,'single-edge.log':5,'single-edge-race.log':5,'single-edge-386.log':5}
for name,count in expected.items():
 s=(lab/name).read_text();assert '--- FAIL:' not in s and '--- SKIP:' not in s and 'no tests to run' not in s,name
 assert s.rstrip().splitlines()[-1].startswith('ok'),name
 assert len(re.findall(r'^--- PASS:',s,re.M))==count,(name,count)
 shutil.copy2(lab/name,p/name)
for name in ['layout.log','v1guard.log']:
 assert (lab/name).read_text().strip(),name
 shutil.copy2(lab/name,p/name)
report=dict(passed=True,baseline_commit='e91e0322f1b094c0995684449f9b90a1a08f4783',baseline_Go_pins=3541,candidate_Go_pins=3543,reused_source_pinned_scoped_screen=expected)
(p/'preflight.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
