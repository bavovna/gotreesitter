from pathlib import Path
import hashlib,json
p=Path('/evidence')
for name in ['full-counter-gate.json','final-core-mode-audit.json','c-parity-gate.json']:
 assert json.loads((p/name).read_text())['passed'],name
rss=json.loads((p/'rss/rss-matched/audit.json').read_text())
assert rss['candidate_safety_pass'] and rss['all_initial_probes_retained']
assert len(rss['initial'])==6 and len(rss['matched'])==120
assert {r['seed'] for r in rss['matched']}==set(range(48701,48721))
for role,name,count in [('/candidate','candidate-source-pins.json',3543),('/reference','baseline-source-pins.json',3541)]:
 pins=json.loads((p/name).read_text());assert len(pins)==count
 for rel,want in pins.items():assert hashlib.sha256((Path(role)/rel).read_bytes()).hexdigest()==want,(role,rel)
report=dict(passed=True,baseline_commit='e91e0322f1b094c0995684449f9b90a1a08f4783',candidate_pins_exact=3543,standard_and_owned_ledger_rows_exact=414,canonical_Go_vectors_exact=4,edit_sessions=206,C_fixture_checks=618,strict_rows_exact=204,expanded_Go_statuses_exact=306,expanded_Go_routes_exact=300,RSS_processes=126,RSS_seeds='48701..48720',RSS_candidate_baseline_median_ratios=rss['candidate_baseline_median_ratios'],ordinary_YAML_route='fallback',owned_YAML_route='compact',timings_run=False,runtime_promoted=False)
(p/'qualification-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
