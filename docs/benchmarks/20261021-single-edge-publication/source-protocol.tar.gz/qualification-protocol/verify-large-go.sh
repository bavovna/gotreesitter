#!/usr/bin/env bash
set -euo pipefail
/evidence/out/candidate/cgo.test -test.run '^TestCompactLineageLargeGoLockedC$' -test.count=1 -test.v -test.timeout=8m > /evidence/large-go-c-verified.log 2>&1
python3 - <<'CHECK'
from pathlib import Path
s=Path('/evidence/large-go-c-verified.log').read_text()
assert '=== RUN   TestCompactLineageLargeGoLockedC' in s and '--- PASS: TestCompactLineageLargeGoLockedC' in s
assert '--- SKIP:' not in s and 'no tests to run' not in s and '--- FAIL:' not in s
Path('/evidence/large-go-verified-complete.txt').write_text('complete\n')
CHECK
