#!/usr/bin/env bash
set -euo pipefail
bash /evidence/qualify.sh
bash /evidence/rss.sh
