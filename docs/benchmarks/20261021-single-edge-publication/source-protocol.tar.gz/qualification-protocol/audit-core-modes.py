from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
expected={"core-default.log":593,"core-shadow.log":605,"core-phase0-shadow.log":629,"core-phase0a-shadow.log":727,"core-onepass-shadow.log":605}
for name,count in expected.items():
 s=(p/name).read_text()
 assert s.rstrip().splitlines()[-1].startswith("ok") and "--- FAIL:" not in s and "--- SKIP:" not in s,name
 assert len(re.findall(r"^--- PASS:",s,re.M))==count,(name,count)
 for test in ["TestSingleEdgePublicationMatchesGeneralFullWidthMetadata","TestSingleEdgePublicationMatchesGeneralMalformedAndCheckpointErrors","TestSingleEdgePublicationFailedNodeValidationRollsBackLinkAndWork","TestSingleEdgeDirectCondensePreservesFullWidthLineageAndOuterRollback","TestSingleEdgeDirectCondenseKeepsCapsAndPrecedenceOverflowAtomic","TestNodeRecordBlocksMaximumLimitStartsSuffix","TestNodeRecordBlocksRetirementRejectsMaximumInt32Tail","TestNodeRecordBlocksCachedGeometryFollowsEveryMutation","TestNodeRecordBlocksSnapshotPreservesNilness","TestSubtreeRecordBlocksSnapshotPreservesNilness","TestSubtreeRecordBlocksRecordsAcrossGrowthAndMaximumLimit","TestSubtreeRecordBlocksGeometryRollbackCloneAndReset","TestSubtreeRecordBlocksCloneAppendReserveChargesBoundaryMetadata"]:
  assert "--- PASS: "+test+" " in s,(name,test)
for name in ["out/candidate/node-blocks-386.log","out/candidate/core-race.log"]:
 s=(p/name).read_text()
 for test in ["TestNodeRecordBlocksMaximumLimitStartsSuffix","TestNodeRecordBlocksRetirementRejectsMaximumInt32Tail"]:
  assert "--- PASS: "+test+" " in s,(name,test)
 assert "--- FAIL:" not in s and "no tests to run" not in s,name
for name in ["out/candidate/core-race.log","out/candidate/single-edge-386.log"]:
 s=(p/name).read_text()
 for test in ["TestSingleEdgePublicationMatchesGeneralFullWidthMetadata","TestSingleEdgePublicationMatchesGeneralMalformedAndCheckpointErrors","TestSingleEdgePublicationFailedNodeValidationRollsBackLinkAndWork","TestSingleEdgeDirectCondensePreservesFullWidthLineageAndOuterRollback","TestSingleEdgeDirectCondenseKeepsCapsAndPrecedenceOverflowAtomic"]:
  assert "--- PASS: "+test+" " in s,(name,test)
 assert "--- FAIL:" not in s and "--- SKIP:" not in s and "no tests to run" not in s,name
assert "756/756 root Go files" in (p/"layout.log").read_text() and "12 API tag sets" in (p/"layout.log").read_text()
assert "454 language-name uses and 101 environment reads" in (p/"v1guard.log").read_text()
calls=[]
for f in Path("/candidate/internal/parsercorephase0").glob("*.go"):
 if not f.name.endswith("_test.go") and ".RetireBlock(" in f.read_text():calls.append(f.name)
assert not calls,calls
pins=json.loads((p/"candidate-source-pins.json").read_text());assert len(pins)==3543
for rel,want in pins.items():assert hashlib.sha256((Path("/candidate")/rel).read_bytes()).hexdigest()==want,rel
report=dict(passed=True,full_Core_suite_passes=expected,boundary_regressions_pass_native_386_race=True,cached_geometry_and_nilness_tests_run=True,collection_calls_in_engine=0,source_hashes_exact=3543)
(p/"final-core-mode-audit.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
