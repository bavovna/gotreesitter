from pathlib import Path
import json,re
p=Path('/evidence');out=p/'out/candidate'
languages=(p/'languages.txt').read_text().splitlines();assert len(languages)==206 and len(set(languages))==206
files=list(out.glob('c-*.log'));assert len(files)==206
checks=0
for grammar in languages:
 s=(out/f'c-{grammar}.log').read_text()
 assert 'no tests to run' not in s and '--- SKIP:' not in s and '--- FAIL:' not in s,grammar
 for test in ['TestParityFreshParse','TestParityIncrementalParse','TestParityHasNoErrors']:
  assert '=== RUN   '+test+'/'+grammar+'\n' in s,(grammar,test)
  assert re.search(r'^    --- PASS: '+re.escape(test+'/'+grammar)+r' \(',s,re.M),(grammar,test)
  checks+=1
assert checks==618
assert json.loads((out/'strict-differences.json').read_text())==[]
strict=json.loads((out/'strict-census.json').read_text());assert len(strict)==204
assert strict==json.loads((p/'production-strict-census.json').read_text())
go=json.loads((p/'out/expanded-go-c-audit.json').read_text())
assert go['all_306_statuses_equal'] and go['new_failures']==0 and go['expanded_routes_exact']==300
for name in ['yaml-large-c.log']:
 s=(out/name).read_text();assert '=== RUN' in s and 'PASS' in s and '--- FAIL:' not in s and '--- SKIP:' not in s and 'no tests to run' not in s,name
assert (p/'large-go-verified-complete.txt').read_text().strip()=='complete'
report=dict(passed=True,C_fixture_checks=618,strict_rows_exact=204,expanded_statuses_exact=306,expanded_routes_exact=300,known_expanded_failures_unchanged=39)
(p/'c-parity-gate.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
