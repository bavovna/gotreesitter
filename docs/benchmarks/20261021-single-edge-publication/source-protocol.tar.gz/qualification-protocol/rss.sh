#!/usr/bin/env bash
set -euo pipefail
source /evidence/common.sh
python3 /evidence/verify-protocol-inputs.py
python3 - <<'GATE'
from pathlib import Path
import json
p=Path('/evidence')
for n in ['full-counter-gate.json','final-core-mode-audit.json','c-parity-gate.json']:
 assert json.loads((p/n).read_text())['passed'],n
assert (p/'qualification-complete.txt').read_text().strip()=='complete'
GATE
export GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/rss-overlay.json'
mkdir /evidence/rss/probes
for role in baseline candidate; do
 if [[ "$role" = baseline ]]; then cd /reference; else cd /candidate; fi
 go test -c -tags gts_parsercorephase0 -o "/evidence/rss/probes/$role-rss-root.test" . > "/evidence/rss/probes/$role-build.log" 2>&1
 for name in go yaml_ordinary yaml_owned; do
  /usr/bin/time -v -o "/evidence/rss/probes/$role-standalone-$name.rss" "/evidence/rss/probes/$role-rss-root.test" -test.run "^TestCompactLineageRSS$/^${name}$" -test.count=1 -test.v -test.timeout=8m > "/evidence/rss/probes/$role-standalone-$name.log" 2>&1
 done
done
python3 /evidence/repeat_rss.py > /evidence/rss/rss-run.log 2>&1
printf 'complete\n' > /evidence/rss/complete.txt
python3 /evidence/audit-finish.py > /evidence/final-qualification-audit.log
