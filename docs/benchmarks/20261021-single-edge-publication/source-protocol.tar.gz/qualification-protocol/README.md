# N Linux qualification protocol (prepared, not executed)

The reference is qualified D64 `e91e0322f1b094c0995684449f9b90a1a08f4783`. The candidate is N's frozen source. This protocol contains no native-YAML/L/M overlay or source. It runs no timings and changes no source, allowlist, ratchet or known failure.

The control ledgers and four canonical work/tree vectors come from D64's actual qualified candidate output. The204-row strict census and complete306-status/300-route expanded Go C log also come from that exact qualified D64 output. Existing39 expanded Go failures and45 strict failures remain visible and must match exactly. Root and C overlays are copied from the real D64 qualification helpers. Their source and input hashes are pinned in this directory.

Order:

1. Verify complete D64/N source pins and reuse N's completed five regression, default593, shadow605, race and386 results. Require the existing source-pinned layout/API and R6 results; source changes invalidate reuse.
2. Run618 locked-C checks, one grammar/process; strict204; expanded306 statuses/300 routes; actual large Go and YAML C witnesses. Stop before later stages if any controlled C result differs.
3. Compare all414 standard/owned ledger rows and four Go canonical work/tree vectors exactly. Run206 separate72-step D8 sessions with no-edit allocation checks, plus the unchanged diagnostic-owned YAML session and memory/pool checks.
4. Run scoped root/Core race and386 safety checks. Run the remaining three full Core modes, for five mode totals593/605/629/727/605. Recheck pinned source contents and publish the correctness/counter audits.
5. Only then run126 RSS processes: six initial probes retained plus20 alternating pairs for each of Go, ordinary YAML and owned YAML, with shuffled case order and seeds48701..48720. Every process uses ordinary budgets and pools. Candidate ceiling400B/source and candidate/reference median ratios<=1.10 must pass; retain all initial and matched logs on failure.

Ordinary YAML is required to stay compact=0/fallback=1; diagnostic-owned YAML stays compact=1/fallback=0. Go's1MiB witness retains its exact source hash,425742 tokens and903086 allocated nodes. C checks retain deep oracle comparison separately from memory probes.

## Minimal host runner arguments

The parent owns scheduling and both locks. Use the existing pinned Linux/amd64 Go1.25.14 image and offline runner, main checkout only as the runner/cache root. The following commands are templates and have not been run:

```
bash /home/draco/.local/state/gotreesitter-evidence/20261018-go-legacy-candidates/offline-runner/cgo_harness/docker/run_parity_in_docker.sh \
 --repo-root /home/draco/work/gotreesitter --no-build \
 --image sha256:187907888b4bdc6f326c87b045718339e5f665baceb27db6b74633ca41e996df \
 --label single-edge-qualification --memory 6g --cpus 1 --cpuset-cpus 6 --gomemlimit 5GiB \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261020-public-subtree-blocks-64k/candidate-source:/reference:ro \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261021-single-edge-publication/candidate-source:/candidate:ro \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261021-single-edge-publication:/lab \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261021-single-edge-publication/qualification-protocol:/evidence \
 --mount /home/draco/.local/state/nightwatch/gts-docker.lock:/gts-locks/nightwatch.lock \
 --mount /tmp/gts-docker.lock:/gts-locks/common.lock \
 -- flock /gts-locks/nightwatch.lock flock /gts-locks/common.lock bash /evidence/qualify.sh
```

After successful completion, repeat the same arguments with a distinct RSS label and final command `bash /evidence/rss.sh`. Alternatively `bash /evidence/run-all.sh` sequences both stages in one held-lock container. Neither entrypoint can begin RSS before the audits pass, and neither invokes a benchmark. Log the runner output outside this protocol directory if desired; all detailed stage logs are retained here.

Stage scripts remain available for an explicitly reviewed resume after an interruption; there is no automatic retry or deletion of prior observations. A failed RSS attempt must retain its files and cannot be overwritten by this script. A successful run writes `qualification-receipt.json` with timings_run=false and runtime_promoted=false. Go/YAML randomized throughput protocols remain separate future work.
