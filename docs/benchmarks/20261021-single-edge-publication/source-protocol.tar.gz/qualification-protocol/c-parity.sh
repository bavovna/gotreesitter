#!/usr/bin/env bash
set -euo pipefail
source /evidence/common.sh
test -f /evidence/preflight.json
mkdir -p /evidence/out/candidate
cd /candidate/cgo_harness
go test -c -tags gts_parsercorephase0,treesitter_c_parity -o /evidence/out/candidate/cgo.test . > /evidence/out/candidate/cgo-build.log 2>&1
while IFS= read -r grammar; do
 GTS_ADMISSION_CANDIDATE=1 GTS_PARITY_MODE=exhaustive /evidence/out/candidate/cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${grammar}$" -test.count=1 -test.v -test.timeout=4m > "/evidence/out/candidate/c-$grammar.log" 2>&1
done < /evidence/languages.txt
python3 /evidence/strict.py candidate > /evidence/out/candidate/strict.log 2>&1
GTS_YAML_LARGE_PROBE=1 /evidence/out/candidate/cgo.test -test.run '^TestCompactYAMLDocumentStreamLockedC$' -test.count=1 -test.v -test.timeout=8m > /evidence/out/candidate/yaml-large-c.log 2>&1
bash /evidence/go-c-control.sh
bash /evidence/verify-large-go.sh
python3 /evidence/audit-c-stage.py > /evidence/c-parity-audit.log
printf 'complete\n' > /evidence/c-parity-complete.txt
