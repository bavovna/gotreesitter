#!/usr/bin/env bash
set -euo pipefail
python3 /evidence/verify-protocol-inputs.py
python3 /evidence/preflight.py > /evidence/preflight.log
bash /evidence/c-parity.sh
bash /evidence/counter-and-invariants.sh
bash /evidence/safety.sh
bash /evidence/extra-core-modes.sh
python3 /evidence/audit-completed.py > /evidence/final-full-audit.log
python3 /evidence/audit-core-modes.py > /evidence/final-mode-audit.log
printf 'complete\n' > /evidence/qualification-complete.txt
