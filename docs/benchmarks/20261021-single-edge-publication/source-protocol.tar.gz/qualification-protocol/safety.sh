#!/usr/bin/env bash
set -euo pipefail
source /evidence/common.sh
test -f /evidence/counter-invariants-complete.txt
cd /candidate
go test . -race -tags gts_parsercorephase0 -run '^Test(ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|CompactAcceptanceCachedPublicationStopControl|G18RefSetSchedulerMemoryBudgetAccounting)$' -count=1 -v -timeout=8m > /evidence/out/candidate/root-race.log 2>&1
go test ./internal/parsercorephase0 -race -run '^Test(SingleEdge|ActionRowDescriptor|AlternativeSetTaggedWord|NodeLineage|NodeRecordBlocks|SubtreeRecordBlocks|NodePathCount|Sole|NodePrecedence|PrecedenceMaximum)' -count=1 -v -timeout=8m > /evidence/out/candidate/core-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test . -tags gts_parsercorephase0 -run '^Test(DiagnosticParserCoreElectionSummaryMatchesFullReceipt|DiagnosticParserCoreVersionLexerElectionReusesCheckpointSerialization)$' -count=1 -v -timeout=8m > /evidence/out/candidate/root-386.log 2>&1
go test ./internal/parsercorephase0 -race -tags gts_eof_recovery_shadow -run '^TestDiagnostic(EOFRecoveryPathCount|NodeBlocks|SubtreeBlocks)' -count=1 -v -timeout=8m > /evidence/out/candidate/path-count-shadow-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -run '^TestDiagnostic(EOFRecoveryPathCount|NodeBlocks|SubtreeBlocks)' -count=1 -v -timeout=8m > /evidence/out/candidate/path-count-shadow-386.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -run '^Test(NodeRecordBlocks|SubtreeRecordBlocks|DiagnosticNodeBlocks|DiagnosticSubtreeBlocks)' -count=1 -v -timeout=8m > /evidence/out/candidate/node-blocks-386.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^TestSingleEdge' -count=1 -v -timeout=8m > /evidence/out/candidate/single-edge-386.log 2>&1
printf 'complete\n' > /evidence/qualify-complete.txt
