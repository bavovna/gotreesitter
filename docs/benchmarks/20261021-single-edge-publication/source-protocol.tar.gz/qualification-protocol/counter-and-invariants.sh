#!/usr/bin/env bash
set -euo pipefail
source /evidence/common.sh
test -f /evidence/c-parity-complete.txt
mkdir -p /evidence/out/candidate
cd /candidate
cp /evidence/core-shadow.log /evidence/out/candidate/core-shadow.log
go test . -run '^TestCompact(ArenaReserve.*|Staged.*|IncrementalDoesNotReserveFullSource)$' -count=1 -v -timeout=8m > /evidence/out/candidate/root-default.log 2>&1
go test . -tags gts_parsercorephase0 -run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|ParserCoreFreshFullRunnerRepeatedCanonicalLifecycle|CompactLegacyReadScratchPooledLargeThenSmall|ParserCoreFreshFullRunnerReusesSchedulerStorage|FreshSnapshotPages.*|SnapshotPairFootprint.*)$' -count=1 -v -timeout=8m > /evidence/out/candidate/memory-pooling.log 2>&1
go test . -tags gts_parsercorephase0 -run '^TestCanonicalMaskCensus$' -count=1 -v -timeout=8m > /evidence/out/candidate/canonical-work.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/out/candidate/root.test . > /evidence/out/candidate/root-build.log 2>&1
go build -tags gts_parsercorephase0 -o /evidence/out/candidate/counter ./cmd/perfcounterledger > /evidence/out/candidate/counter-build.log 2>&1
/evidence/out/candidate/counter --write --output /evidence/out/candidate/ledger.json > /evidence/out/candidate/ledger.log 2>&1
GTS_LAYOUT_OWNED_PROBE=1 /evidence/out/candidate/counter --langs yaml > /evidence/out/candidate/owned-yaml-ledger.json 2> /evidence/out/candidate/owned-yaml-ledger.log
python3 - <<'COUNTERS'
import json
from pathlib import Path
p=Path('/evidence')
for a,b in [('reference-ledger.json','out/candidate/ledger.json'),('reference-owned-yaml-ledger.json','out/candidate/owned-yaml-ledger.json')]:assert json.loads((p/a).read_text())==json.loads((p/b).read_text()),(a,b)
rows={}
for line in (p/'out/candidate/canonical-work.log').read_text().splitlines():
 if 'CANONICAL_WORK_CENSUS ' in line:
  r=json.loads(line.split('CANONICAL_WORK_CENSUS ',1)[1]);rows[r['Fixture']]=r
assert rows==json.loads((p/'reference-canonical-work.json').read_text())['candidate']
(p/'early-counter-gate.json').write_text(json.dumps(dict(passed=True,ledger_rows_exact=414,canonical_Go_vectors_exact=4))+'\n')
COUNTERS
while IFS= read -r grammar; do
 GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE="$grammar" /evidence/out/candidate/root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=4m > "/evidence/out/candidate/invariant-$grammar.log" 2>&1
done < /evidence/languages.txt
GTS_ADMISSION_CANDIDATE=1 /evidence/out/candidate/root.test -test.run '^TestProgressArenaOwnedYAMLInvariant$' -test.count=1 -test.v -test.timeout=4m > /evidence/out/candidate/owned-yaml-invariant.log 2>&1
printf 'complete\n' > /evidence/counter-invariants-complete.txt
