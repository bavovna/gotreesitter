#!/usr/bin/env bash
set -euo pipefail
test -f /evidence/qualify-complete.txt
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-phase0-shadow.log 2>&1
go test ./internal/parsercorephase0 -tags gts_parsercorephase0,gts_parsercorephase0a,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-phase0a-shadow.log 2>&1
go test ./internal/parsercorephase0 -tags gts_parsercorephase0_selectedstore_onepass,gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-onepass-shadow.log 2>&1
# Source-pinned layout/API and R6 results were already checked in preflight.
test -s /evidence/layout.log
test -s /evidence/v1guard.log
printf 'complete\n' > /evidence/final-core-modes-complete.txt
