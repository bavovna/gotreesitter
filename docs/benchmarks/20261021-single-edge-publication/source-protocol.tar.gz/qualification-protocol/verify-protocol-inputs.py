from pathlib import Path
import hashlib,json
p=Path('/evidence')
pins=json.loads((p/'protocol-input-pins.json').read_text())
for rel,want in pins.items():assert hashlib.sha256((p/rel).read_bytes()).hexdigest()==want,rel
