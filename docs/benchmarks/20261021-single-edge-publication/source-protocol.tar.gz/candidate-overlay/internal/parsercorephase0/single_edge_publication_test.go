package parsercorephase0

import (
	"errors"
	"math"
	"reflect"
	"strings"
	"testing"
)

// This is the old split publication sequence. It keeps the full adjacency
// walker as the differential oracle for both successful and failed appends.
func appendSingleEdgeGeneralForTest(c *Core, r nodeInput, checkpoint CheckpointID, maximum int64, link linkRecord) (NodeID, LinkID, error) {
	linkID, err := c.appendGraphLinkChecked(link)
	if err != nil {
		return 0, 0, err
	}
	c.addWork(&c.work.GraphLinkAdditionsProxy, 1)
	r.firstLink, r.linkCount = uint32(linkID), 1
	id, err := c.appendNodeAtWithMaximum(r, checkpoint, maximum)
	return id, linkID, err
}

func singleEdgeFixtureForTest(t *testing.T) (*Core, Head, SubtreeID, CheckpointID) {
	t.Helper()
	c := newTinyCoreWithLimits(t, Limits{})
	head, err := c.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	payload := appendShallowPayload(t, c, shallowPayloadSpec{symbol: 20, endByte: 1, childSymbols: []Symbol{30}})
	checkpoint := mustInternCheckpoint(t, c, []byte{1, 2, 3})
	return c, head, payload, checkpoint
}

func cloneSingleEdgeSliceForTest[T any](items []T) []T { return append([]T(nil), items...) }

func singleEdgeStateForTest(c *Core) map[string]interface{} {
	nodes := make([]nodeRecord, c.nodes.Len())
	for i := range nodes {
		nodes[i] = *c.nodes.At(i)
	}
	return map[string]interface{}{
		"nodes": nodes, "links": cloneSingleEdgeSliceForTest(c.links), "hot_lineage": cloneSingleEdgeSliceForTest(c.nodeLineages),
		"recovery_lineage": cloneSingleEdgeSliceForTest(c.nodeLineageRecovery), "wide_paths": cloneSingleEdgeSliceForTest(c.nodePathCountsWide),
		"wide_precedence": cloneSingleEdgeSliceForTest(c.nodePrecedenceWide), "wide_precedence_base": c.nodePrecedenceWideBase,
		"node_checkpoints": cloneSingleEdgeSliceForTest(c.nodeCheckpoints), "link_ref_indexes": cloneSingleEdgeSliceForTest(c.dropCohortLinkRefIndexes),
		"boundaries": cloneBoundaryMap(c.boundaries), "boundary_journal": cloneSingleEdgeSliceForTest(c.boundaryJournal),
		"lineage_journal": cloneSingleEdgeSliceForTest(c.nodeLineageJournal), "work": c.Work(), "storage_bytes": c.StorageBytes(),
	}
}

func singleEdgeErrorForTest(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}

func TestSingleEdgePublicationMatchesGeneralFullWidthMetadata(t *testing.T) {
	for _, maximum := range []int64{0, -32767, 32767, -32768, 32768, math.MinInt64, math.MaxInt64} {
		for _, paths := range []uint64{0, 1, 61, 62, 63, 1 << 40, math.MaxUint64 - 1, math.MaxUint64} {
			for _, ordered := range []bool{false, true} {
				a, ha, pa, ca := singleEdgeFixtureForTest(t)
				b, hb, pb, cb := singleEdgeFixtureForTest(t)
				// Exercise the optional link-reference sidecar as well as the
				// exact full-width values in the immutable graph records.
				a.dropCohortLinkRefIndexes = make([]uint32, 0)
				b.dropCohortLinkRefIndexes = make([]uint32, 0)
				flags := uint32(0)
				if ordered {
					flags = linkFlagHasOrder
				}
				r := nodeInput{state: 2, byteOffset: 1, pathCount: paths}
				id, linkID, err := a.appendSingleEdgeNodeRecord(r, ca, maximum, linkRecord{prev: ha.Node, payload: pa, scoreDelta: maximum, order: math.MaxUint64, flags: flags})
				wantID, wantLink, wantErr := appendSingleEdgeGeneralForTest(b, r, cb, maximum, linkRecord{prev: hb.Node, payload: pb, scoreDelta: maximum, order: math.MaxUint64, flags: flags})
				if err != nil || wantErr != nil || id != wantID || linkID != wantLink || !reflect.DeepEqual(singleEdgeStateForTest(a), singleEdgeStateForTest(b)) {
					t.Fatalf("maximum=%d paths=%d ordered=%t differed: %v/%v", maximum, paths, ordered, err, wantErr)
				}
				if got, e := a.nodePathCount(id); e != nil || got != paths {
					t.Fatalf("full path count=%d/%v want%d", got, e, paths)
				}
				if got, e := a.storedNodePrecedence(id); e != nil || got != maximum {
					t.Fatalf("full maximum=%d/%v want%d", got, e, maximum)
				}
				if got := a.links[linkID-1]; got.order != math.MaxUint64 || got.scoreDelta != maximum || got.hasOrder() != ordered {
					t.Fatal("link score/order narrowed")
				}
			}
		}
	}
}

func TestSingleEdgePublicationMatchesGeneralMalformedAndCheckpointErrors(t *testing.T) {
	type edit func(*Core, *nodeInput, *CheckpointID, *linkRecord)
	cases := []struct {
		name string
		edit edit
		want string
	}{
		{"zero predecessor", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { l.prev = 0 }, "must be lower"},
		{"future predecessor", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { l.prev = NodeID(c.nodes.Len() + 1) }, "must be lower"},
		{"zero payload", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { l.payload = 0 }, "ordinary link has no payload"},
		{"unknown flags before checkpoint", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { l.flags = 1 << 31; *cp = 999 }, "unknown flags"},
		{"checkpoint before predecessor", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { *cp = 999; l.prev = 0 }, "scanner checkpoint is unavailable"},
		{"node cap before checkpoint", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) {
			c.limits.MaxNodes = uint32(c.nodes.Len())
			*cp = 999
		}, "node arena cap"},
		{"link count cap", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { c.limits.MaxLinks = 0 }, "recorded link count"},
		{"boundary count cap", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { c.limits.MaxLinksPerBoundary = 0 }, "recorded link count"},
		{"unterminated adjacency", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { l.next = 1 }, "adjacency exceeds"},
		{"unknown tail", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { l.next = 999 }, "adjacency exceeds"},
		{"recovery marker with payload", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) { l.flags = linkFlagRecoveryDiscontinuity }, "discontinuity has a payload"},
		{"recovery marker wrong state", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) {
			l.payload = 0
			l.flags = linkFlagRecoveryDiscontinuity
		}, "must target ERROR_STATE"},
		{"recovery marker wrong byte", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) {
			l.payload = 0
			l.flags = linkFlagRecoveryDiscontinuity
			r.state = 0
		}, "must be zero-width"},
		{"recovery marker wrong checkpoint", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) {
			l.payload = 0
			l.flags = linkFlagRecoveryDiscontinuity
			r.state = 0
			r.byteOffset = 0
		}, "checkpoint is not exact"},
		{"valid recovery marker", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) {
			l.payload = 0
			l.flags = linkFlagRecoveryDiscontinuity
			r.state = 0
			r.byteOffset = 0
			*cp = 0
		}, ""},
		{"quiescent checkpoint", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) {
			c.CertifyExternalPayloadsQuiescent()
			*cp = 999
		}, ""},
		{"work saturation", func(c *Core, r *nodeInput, cp *CheckpointID, l *linkRecord) {
			c.work.GraphLinkAdditionsProxy = math.MaxUint64
		}, ""},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			a, ha, pa, ca := singleEdgeFixtureForTest(t)
			b, hb, pb, cb := singleEdgeFixtureForTest(t)
			ra, rb := nodeInput{state: 2, byteOffset: 1, pathCount: 1}, nodeInput{state: 2, byteOffset: 1, pathCount: 1}
			la, lb := linkRecord{prev: ha.Node, payload: pa}, linkRecord{prev: hb.Node, payload: pb}
			test.edit(a, &ra, &ca, &la)
			test.edit(b, &rb, &cb, &lb)
			id, linkID, err := a.appendSingleEdgeNodeRecord(ra, ca, 0, la)
			wantID, wantLink, wantErr := appendSingleEdgeGeneralForTest(b, rb, cb, 0, lb)
			if id != wantID || linkID != wantLink || singleEdgeErrorForTest(err) != singleEdgeErrorForTest(wantErr) || !reflect.DeepEqual(singleEdgeStateForTest(a), singleEdgeStateForTest(b)) {
				t.Fatalf("general-path difference: %d/%d %v vs%d/%d %v", id, linkID, err, wantID, wantLink, wantErr)
			}
			if (test.want == "") != (err == nil) || err != nil && !strings.Contains(err.Error(), test.want) {
				t.Fatalf("error=%v want%q", err, test.want)
			}
		})
	}
}

func TestSingleEdgePublicationFailedNodeValidationRollsBackLinkAndWork(t *testing.T) {
	c, head, payload, checkpoint := singleEdgeFixtureForTest(t)
	before := singleEdgeStateForTest(c)
	err := c.ApplyAtomic(func() error {
		_, _, err := c.appendSingleEdgeNodeRecord(nodeInput{state: 2, byteOffset: 1, pathCount: math.MaxUint64 - 1}, checkpoint+1, math.MaxInt64, linkRecord{prev: head.Node, payload: payload})
		return err
	})
	if err == nil || !strings.Contains(err.Error(), "scanner checkpoint") || !reflect.DeepEqual(before, singleEdgeStateForTest(c)) {
		t.Fatal("failed publication escaped its original rollback contract", err)
	}
}

func TestSingleEdgeDirectCondensePreservesFullWidthLineageAndOuterRollback(t *testing.T) {
	c, seed, payload, checkpoint := singleEdgeFixtureForTest(t)
	if err := c.SetPhaseCheckpoint(checkpoint); err != nil {
		t.Fatal(err)
	}
	setNodePathCountForTest(c, seed.Node, 1<<40)
	c.dropCohortLinkRefIndexes = make([]uint32, 0)
	before := singleEdgeStateForTest(c)
	abort := errors.New("abort direct publication")
	key := c.boundaryKey(2, 1)
	input := linkInput{prev: seed.Node, payload: payload, scoreDelta: math.MaxInt64, order: ForkOrder{Value: math.MaxUint64, Present: true}, storedErrorCost: 37, hasStoredErrorCost: true}
	var abandoned Head
	err := c.ApplyAtomic(func() error {
		var err error
		abandoned, err = c.condense(key, input)
		if err != nil {
			return err
		}
		if len(c.boundaryJournal) == 0 {
			t.Fatal("nested commit discarded the outer boundary journal")
		}
		if got, err := c.RecoveryStoredErrorCost(abandoned); err != nil || got != 37 {
			t.Fatal("stored recovery cost changed", got, err)
		}
		if got, err := c.nodePathCount(abandoned.Node); err != nil || got != 1<<40 {
			t.Fatal("wide path count changed", got, err)
		}
		if got, err := c.storedNodePrecedence(abandoned.Node); err != nil || got != math.MaxInt64 {
			t.Fatal("wide precedence changed", got, err)
		}
		if got, ok := c.nodeScannerCheckpoint(abandoned.Node); !ok || got != checkpoint {
			t.Fatal("node checkpoint changed", got, ok)
		}
		return abort
	})
	if !errors.Is(err, abort) || !reflect.DeepEqual(before, singleEdgeStateForTest(c)) {
		t.Fatal("outer rollback did not restore graph, metadata, counters and boundary", err)
	}
	retry, err := c.condense(key, input)
	if err != nil || retry != abandoned {
		t.Fatalf("retry did not reuse the rolled-back logical ordinal: %v/%v %v", retry, abandoned, err)
	}
}

func TestSingleEdgeDirectCondenseKeepsCapsAndPrecedenceOverflowAtomic(t *testing.T) {
	for _, maximum := range []int64{math.MinInt64, math.MaxInt64} {
		c, seed, payload, _ := singleEdgeFixtureForTest(t)
		first, err := c.condense(c.boundaryKey(2, 1), linkInput{prev: seed.Node, payload: payload, scoreDelta: maximum})
		if err != nil {
			t.Fatal(err)
		}
		before := singleEdgeStateForTest(c)
		delta := int64(1)
		if maximum < 0 {
			delta = -1
		}
		if _, err := c.condense(c.boundaryKey(3, 2), linkInput{prev: first.Node, payload: payload, scoreDelta: delta}); err == nil || !strings.Contains(err.Error(), "precedence maximum overflow") {
			t.Fatal("overflow was accepted", err)
		}
		if !reflect.DeepEqual(before, singleEdgeStateForTest(c)) {
			t.Fatal("overflow changed graph/work/metadata")
		}
	}
	for _, capKind := range []string{"links", "nodes", "payload"} {
		t.Run(capKind, func(t *testing.T) {
			c, seed, payload, _ := singleEdgeFixtureForTest(t)
			want := ""
			switch capKind {
			case "links":
				c.limits.MaxLinks = 0
				want = "link arena cap"
			case "nodes":
				c.limits.MaxNodes = uint32(c.nodes.Len())
				want = "node arena cap"
			case "payload":
				payload = math.MaxUint32
				want = "subtree"
			}
			before := singleEdgeStateForTest(c)
			_, err := c.condense(c.boundaryKey(2, 1), linkInput{prev: seed.Node, payload: payload})
			if err == nil || !strings.Contains(err.Error(), want) || !reflect.DeepEqual(before, singleEdgeStateForTest(c)) {
				t.Fatalf("%s failure changed state or priority: %v", capKind, err)
			}
		})
	}
}
