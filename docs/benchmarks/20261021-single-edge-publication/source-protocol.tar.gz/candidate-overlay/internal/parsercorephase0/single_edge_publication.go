package parsercorephase0

import (
	"errors"
	"fmt"
	"math"
)

// nodePublicationOrdinal preserves the shared publication preflight and error
// order. Neither caller invokes a callback or mutates nodes before appending.
func (c *Core) nodePublicationOrdinal(checkpoint CheckpointID) (NodeID, error) {
	if uint64(c.nodes.Len())+1 > uint64(c.limits.MaxNodes) || uint64(c.nodes.Len()) >= math.MaxUint32 {
		return 0, errors.New("parser-core phase zero: node arena cap")
	}
	if !c.externalPayloadsQuiescent && checkpoint != 0 {
		if _, ok := c.checkpoints.record(checkpoint); !ok {
			return 0, errors.New("parser-core phase zero: node scanner checkpoint is unavailable")
		}
	}
	next := NodeID(uint64(c.nodes.Len()) + 1)
	return next, nil
}

// appendValidatedNodeRecord is the common publication write. Callers must first
// authenticate the ordinal, checkpoint and entire adjacency. It retains every
// original lineage, wide-value and scanner-sidecar write.
func (c *Core) appendValidatedNodeRecord(r nodeInput, checkpoint CheckpointID, maximum int64, next NodeID) (NodeID, error) {
	inline := inlineNodePrecedence(maximum)
	if id, ok := c.nodes.Append(r.record(), c.limits.MaxNodes); !ok || id != next {
		return 0, errors.New("parser-core phase zero: node arena publication failed")
	}
	c.nodeLineages = append(c.nodeLineages, nodeLineageHot{precedenceInline: inline, flags: c.appendNodePathCount(next, r.pathCount)})
	if inline == wideNodePrecedence {
		c.storeWideNodePrecedence(next, maximum)
	}
	if !c.externalPayloadsQuiescent {
		c.nodeCheckpoints = append(c.nodeCheckpoints, checkpoint)
	}
	return next, nil
}

// appendSingleEdgeNodeRecord publishes a freshly appended ordinary edge without
// reading it back through the general adjacency walker. The literal edge has
// already passed validateShape, contains one terminating link and gets its exact
// new dense ordinal here. The remaining DAG condition is predecessor decrease.
// Uncommon or malformed adjacency retains the complete original validator.
// This operation keeps the original link/work mutation before node validation;
// callers still own the same surrounding transaction and rollback contract.
func (c *Core) appendSingleEdgeNodeRecord(r nodeInput, checkpoint CheckpointID, maximum int64, link linkRecord) (NodeID, LinkID, error) {
	linkID, err := c.appendGraphLinkChecked(link)
	if err != nil {
		return 0, 0, err
	}
	c.addWork(&c.work.GraphLinkAdditionsProxy, 1)
	r.firstLink, r.linkCount = uint32(linkID), 1
	if linkID == 0 || link.next != 0 || link.payload == 0 || link.flags & ^linkFlagHasOrder != 0 {
		id, err := c.appendNodeRecord(r, checkpoint, maximum)
		return id, linkID, err
	}
	next, err := c.nodePublicationOrdinal(checkpoint)
	if err != nil {
		return 0, linkID, err
	}
	if c.limits.MaxLinks == 0 || c.limits.MaxLinksPerBoundary == 0 {
		return 0, linkID, errors.New("parser-core phase zero: recorded link count exceeds configured limit")
	}
	if link.prev == 0 || link.prev >= next {
		return 0, linkID, fmt.Errorf("parser-core phase zero: graph predecessor %d must be lower than new node %d", link.prev, next)
	}
	id, err := c.appendValidatedNodeRecord(r, checkpoint, maximum, next)
	return id, linkID, err
}
