# N versus D64 randomized throughput

480 rows from 80 processes; 20 paired seeds per language. Custom metrics and workload order match exactly. Ordinary YAML stays on fallback. Every no-edit sample allocates zero bytes and objects.

10% median ratchets: PASS. All directional changes follow; these are medians without a significance claim.

| Language | Workload | Metric | D64 median | N median | Change |
|---|---|---|---:|---:|---:|
| go | fresh_one_mib | ns/op | 9.41969e+08 | 9.55294e+08 | +1.41% |
| go | fresh_one_mib | B/op | 3.86179e+08 | 3.86177e+08 | -0.00% |
| go | fresh_one_mib | allocs/op | 290 | 290 | +0.00% |
| go | full_dfa | ns/op | 1.02231e+07 | 1.04529e+07 | +2.25% |
| go | full_dfa | B/op | 429372 | 429372 | -0.00% |
| go | full_dfa | allocs/op | 37 | 37 | +0.00% |
| go | grammargen_lr | ns/op | 1.22884e+08 | 1.29035e+08 | +5.01% |
| go | grammargen_lr | B/op | 1.10539e+06 | 1.10539e+06 | +0.00% |
| go | grammargen_lr | allocs/op | 1706 | 1706 | +0.00% |
| go | no_edit_dfa | ns/op | 3.629 | 3.58 | -1.35% |
| go | no_edit_dfa | B/op | 0 | 0 | +0.00% |
| go | no_edit_dfa | allocs/op | 0 | 0 | +0.00% |
| go | query_compile | ns/op | 1.15451e+07 | 1.15781e+07 | +0.29% |
| go | query_compile | B/op | 4496 | 4496 | +0.00% |
| go | query_compile | allocs/op | 121 | 121 | +0.00% |
| go | single_byte_edit_dfa | ns/op | 115054 | 123981 | +7.76% |
| go | single_byte_edit_dfa | B/op | 401 | 401 | +0.00% |
| go | single_byte_edit_dfa | allocs/op | 5 | 5 | +0.00% |
| yaml | eof8k_legacy | ns/op | 547858 | 536506 | -2.07% |
| yaml | eof8k_legacy | B/op | 1264 | 1264 | +0.00% |
| yaml | eof8k_legacy | allocs/op | 13 | 13 | +0.00% |
| yaml | eof8k_ordinary | ns/op | 642168 | 641956 | -0.03% |
| yaml | eof8k_ordinary | B/op | 45737 | 45737 | +0.00% |
| yaml | eof8k_ordinary | allocs/op | 34 | 34 | +0.00% |
| yaml | eof8k_owned | ns/op | 1.45739e+06 | 1.50003e+06 | +2.93% |
| yaml | eof8k_owned | B/op | 41048 | 41048 | +0.00% |
| yaml | eof8k_owned | allocs/op | 191 | 191 | +0.00% |
| yaml | r4_legacy | ns/op | 151398 | 147871 | -2.33% |
| yaml | r4_legacy | B/op | 1440 | 1440 | +0.00% |
| yaml | r4_legacy | allocs/op | 16 | 16 | +0.00% |
| yaml | r4_ordinary | ns/op | 200742 | 201149 | +0.20% |
| yaml | r4_ordinary | B/op | 14040 | 14040 | +0.00% |
| yaml | r4_ordinary | allocs/op | 37 | 37 | +0.00% |
| yaml | r4_owned | ns/op | 382972 | 398420 | +4.03% |
| yaml | r4_owned | B/op | 11848 | 11848 | +0.00% |
| yaml | r4_owned | allocs/op | 72 | 72 | +0.00% |

Raw paired samples and source/input manifests remain beside this report. Benchstat must supply any later significance claim. A passing median screen does not change routing or graduate a language.
