#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false'
cd /candidate
go test ./internal/parsercorephase0 -run '^TestSingleEdge' -count=1 -v -timeout=8m > /evidence/single-edge.log 2>&1
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-default.log 2>&1
go test ./internal/parsercorephase0 -tags gts_eof_recovery_shadow -count=1 -v -timeout=8m > /evidence/core-shadow.log 2>&1
go test ./internal/parsercorephase0 -race -run '^TestSingleEdge' -count=1 -v -timeout=8m > /evidence/single-edge-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^TestSingleEdge' -count=1 -v -timeout=8m > /evidence/single-edge-386.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
go run ./cmd/v1guard -root /candidate > /evidence/v1guard.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
