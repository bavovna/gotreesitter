# N randomized throughput protocol — prepared only

Compare qualified D64 `e91e0322f1b094c0995684449f9b90a1a08f4783` (3541 Go pins, byte-identical to current PR1504/d306) with frozen N (3543 Go pins). Candidate commit identity is deliberately unspecified until Buckley records it; full frozen source pins authenticate the experiment. This protocol changes no parser source or benchmark runner and has not been executed.

`run.sh` first requires N's completed C/counter/invariant/Core/race/386/layout qualification, the final qualification receipt and all126 passing RSS observations. It verifies complete source sets and hashes, shared fixture/module/runner inputs, all raw RSS files and unchanged qualification receipts. RSS must preserve all six initial probes plus120 matched observations, candidate ceilings and10% median ratios. Missing or failed qualification stops before any benchmark. The source and gate checks repeat after timing.

The unchanged repository runner alternates baseline/candidate process order. Run20 Go pairs on49301–49320 and20 YAML pairs on49201–49220, Linux/amd64 Go1.25.14, CPU6, GOMAXPROCS=1, count=1,750ms and benchmem. All80 processes and480 rows are required. The analyzer checks the exact six workloads per process, seeds, completion, pair positions and identical shuffled workload order. All custom metrics must equal D64's pinned controls with no exceptions: ordinary YAML stays compact=0/fallback=1 and owned YAML stays compact=1/fallback=0. Every Go no-edit sample must allocate0B/0objects.

`perf-summary.json` reports all36 median directional changes and fails on any ns/op, B/op or allocs/op median increase above10%. `directional-report.md` lists every result, including smaller regressions. This screen makes no significance claim. Use benchstat on the unchanged raw before/after files for statistical comparisons after completion. Preserve every failed or interrupted observation; the entrypoint refuses an existing perf directory. No automatic retry, profiler, promotion or routing change is included.

## Host launch template

The parent owns Docker scheduling and both locks. No host tests are needed. Sources and completed qualification are read-only; only this protocol directory receives outputs. The main checkout supplies the runner/cache root.

```bash
bash /home/draco/.local/state/gotreesitter-evidence/20261018-go-legacy-candidates/offline-runner/cgo_harness/docker/run_parity_in_docker.sh \
 --repo-root /home/draco/work/gotreesitter --no-build \
 --image sha256:187907888b4bdc6f326c87b045718339e5f665baceb27db6b74633ca41e996df \
 --label single-edge-randomized-perf --memory 6g --cpus 1 --cpuset-cpus 6 --gomemlimit 5GiB \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261020-public-subtree-blocks-64k/candidate-source:/reference:ro \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261021-single-edge-publication/candidate-source:/candidate:ro \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261021-single-edge-publication/qualification-protocol:/qualification:ro \
 --mount /home/draco/.local/state/gotreesitter-evidence/20261021-single-edge-publication/perf-protocol:/evidence \
 --mount /home/draco/.local/state/nightwatch/gts-docker.lock:/gts-locks/nightwatch.lock \
 --mount /tmp/gts-docker.lock:/gts-locks/common.lock \
 -- flock /gts-locks/nightwatch.lock flock /gts-locks/common.lock bash /evidence/run.sh
```

After a passing run, use the parent's existing benchstat installation against `perf/go-before.txt perf/go-after.txt` and `perf/yaml-before.txt perf/yaml-after.txt`; keep those reports beside the raw data. Profile only if those new measurements justify it.

`protocol-input-pins.json` authenticates every static asset here. `reference-provenance.json` records the exact D64 helper and control-output hashes used to prepare this protocol; `expected-metrics.json` contains its20-sample stable deterministic metric controls. The raw qualification outputs are consumed from the read-only mount, without copying or rewriting the evidence. Inputs are rechecked before and after timing. Protocol preparation includes static Python AST and shell syntax checks only, with no tests, Docker, workload, Git, or remote execution.
