#!/usr/bin/env python3
# Adapted from the qualified D64 analyzer: parse unchanged runner output,
# authenticate complete pairs, compare deterministic metrics, then report timing.
from pathlib import Path
from statistics import median
import hashlib,json,math,re
p=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_text())
assert (p/'perf/complete.txt').read_text().strip()=='complete'
pre=read(p/'pre-timing-audit.json');post=read(p/'post-timing-audit.json')
assert pre['passed'] is True and post['passed'] is True
for key in ['sources','qualification_sha256','environment','cpu_affinity','go_version']:
 assert pre[key]==post[key],('campaign input changed',key)
assert pre['RSS_raw_processes_checked']==post['RSS_raw_processes_checked']==126
expected=read(p/'expected-metrics.json');starts={'go':49301,'yaml':49201}
standard={'ns/op','B/op','allocs/op','MB/s'}
roles={'baseline':('before','baseline','/reference'),'candidate':('after','head','/candidate')}
results={};ratchet_failures=[];directions=[];orders_report={};raw_pins={};rows=processes=0
for language,controls in expected.items():
 names=set(controls);assert len(names)==6
 seed_range=list(range(starts[language],starts[language]+20))
 samples={};orders={}
 for role,(suffix,raw_role,root) in roles.items():
  path=p/f'perf/{language}-{suffix}.txt';raw=path.read_bytes();text=raw.decode();lines=text.splitlines()
  raw_pins[str(path.relative_to(p))]=hashlib.sha256(raw).hexdigest()
  assert lines[0]=='# status: incomplete' and lines[-1]=='# status: complete'
  assert not re.search(r'(^|\s)(FAIL|SKIP)(\s|:|$)',text,re.M),(language,role,'failed or skipped process')
  headers={}
  for line in lines:
   if line.startswith('# seed: '):break
   if line.startswith('# ') and ': ' in line:
    key,value=line[2:].split(': ',1);assert key not in headers,('duplicate header',key);headers[key]=value
  wanted={'status':'incomplete','protocol':'paired-alternating-seeds','role':raw_role,'working directory':root,'package':'.','bench regex':'^BenchmarkCompactThroughput'+('Go' if language=='go' else 'YAML')+'$','build tags':'gts_parsercorephase0','seeds':f'{starts[language]}..{starts[language]+19}','benchtime':'750ms','GOMAXPROCS':'1','count per process':'1','suite seed environment':'GTS_BENCHMARK_SEED','paired workload order':'must match'}
  for key,value in wanted.items():assert headers.get(key)==value,('runner header',language,role,key,headers.get(key),value)
  assert len(headers['required benchmarks'].split(','))==6 and set(headers['required benchmarks'].split(','))==names
  assert sum(line=='# completed runs: 20' for line in lines)==1
  records={};order_by_seed={};record=None;sequence=[]
  for line in lines:
   match=re.fullmatch(r'# seed: (\d+); position: ([12])',line)
   if match:
    assert record is None,('unclosed process',language,role)
    seed,position=map(int,match.groups());assert seed not in records and seed in seed_range
    expected_position=(1 if seed%2 else 2) if role=='baseline' else (2 if seed%2 else 1)
    assert position==expected_position,('pair ordering',language,role,seed,position)
    record={'seed':seed,'position':position,'rows':{},'order':[],'shuffle':0,'pass':0,'ok':0,'order_declared':False};sequence.append(seed)
   elif line.startswith('-test.shuffle '):
    assert record is not None and line==f"-test.shuffle {record['seed']}"
    record['shuffle']+=1
   elif line.startswith('Benchmark'):
    assert record is not None and not record['order_declared']
    fields=line.split();name=re.sub(r'-[0-9]+$','',fields[0]);assert name in names and name not in record['rows']
    assert fields[1].isdigit() and int(fields[1])>0 and len(fields)>=8 and len(fields)%2==0
    units=fields[3::2];assert len(units)==len(set(units))
    metrics={fields[i+1]:float(fields[i]) for i in range(2,len(fields),2)}
    assert all(math.isfinite(value) and value>=0 for value in metrics.values())
    assert sorted(metrics)==controls[name]['metric_units'],('metric units',language,role,name,sorted(metrics))
    custom={key:value for key,value in metrics.items() if key not in standard}
    assert custom==controls[name]['custom_metrics'],('deterministic metrics changed',language,role,name,custom,controls[name]['custom_metrics'])
    if name.endswith('/no_edit_dfa'):assert metrics['B/op']==metrics['allocs/op']==0
    record['rows'][name]=metrics;record['order'].append(name);rows+=1
   elif line=='PASS':
    assert record is not None;record['pass']+=1
   elif re.match(r'^ok\s+github\.com/odvcencio/gotreesitter\s',line):
    assert record is not None;record['ok']+=1
   elif line.startswith('# workload order: '):
    assert record is not None and not record['order_declared']
    declared=line.split(': ',1)[1].split(',')
    assert declared==record['order'] and len(declared)==6 and set(declared)==names
    record['order_declared']=True
   elif line.startswith('# completed seed: '):
    match=re.fullmatch(r'# completed seed: (\d+); at: \S+',line)
    assert match and record is not None and int(match[1])==record['seed']
    assert record['shuffle']==record['pass']==record['ok']==1 and record['order_declared']
    assert set(record['rows'])==names
    records[record['seed']]=record['rows'];order_by_seed[record['seed']]=record['order'];record=None;processes+=1
   elif line.startswith(('goos: ','goarch: ')):
    assert record is not None and line==('goos: linux' if line.startswith('goos: ') else 'goarch: amd64')
  assert record is None and sequence==seed_range and set(records)==set(seed_range)
  samples[role]=records;orders[role]=order_by_seed
 assert orders['baseline']==orders['candidate'],('paired workload orders differ',language)
 distinct=len({tuple(order) for order in orders['baseline'].values()});assert distinct>1
 orders_report[language]={'matched_pairs':20,'processes':40,'distinct_workload_orders':distinct,'seeds':seed_range,'per_seed_workload_order':orders['baseline'],'pair_order':'odd baseline first; even candidate first'}
 results[language]={}
 for name in sorted(names):
  left=[samples['baseline'][seed][name] for seed in seed_range];right=[samples['candidate'][seed][name] for seed in seed_range]
  metrics={}
  for unit in ['ns/op','B/op','allocs/op']:
   before=median(row[unit] for row in left);after=median(row[unit] for row in right)
   change=100*(after/before-1) if before else (0 if after==0 else None)
   direction='increase' if after>before else 'decrease' if after<before else 'unchanged'
   metrics[unit]={'before':before,'after':after,'change_percent':change,'direction':direction}
   row={'language':language,'benchmark':name,'metric':unit,**metrics[unit]}
   directions.append(row)
   if after>1.10*before:ratchet_failures.append(row)
  results[language][name]={'samples_per_revision':20,'metrics':metrics,'custom_metrics_exact':controls[name]['custom_metrics']}
assert rows==480 and processes==80
report={'passed':not ratchet_failures,'baseline_commit':'e91e0322f1b094c0995684449f9b90a1a08f4783','candidate_identity':'3543 complete frozen Go pins; commit authentication not claimed','sources':pre['sources'],'benchmark_rows':rows,'benchmark_processes':processes,'paired_protocol':'unchanged scripts/run_randomized_benchmarks.sh; count=1; GOMAXPROCS=1; 750ms','matched_workload_order':orders_report,'custom_metrics_exact':True,'ordinary_YAML_fallback_in_both_revisions':True,'owned_YAML_compact_in_both_revisions':True,'no_edit_zero_allocations_all_samples':True,'median_10_percent_failures':ratchet_failures,'all_directional_changes':directions,'results':results,'raw_sha256':raw_pins,'statistical_significance_claimed':False,'runtime_promoted':False}
(p/'perf-summary.json').write_text(json.dumps(report,indent=2)+'\n')
md=['# N versus D64 randomized throughput','',f'480 rows from 80 processes; 20 paired seeds per language. Custom metrics and workload order match exactly. Ordinary YAML stays on fallback. Every no-edit sample allocates zero bytes and objects.','',f"10% median ratchets: {'PASS' if not ratchet_failures else 'HELD ('+str(len(ratchet_failures))+' failures)'}. All directional changes follow; these are medians without a significance claim.",'','| Language | Workload | Metric | D64 median | N median | Change |','|---|---|---|---:|---:|---:|']
for row in directions:
 percent=row['change_percent'];change=(f'{percent:+.2f}%' if percent is not None else 'increase from zero')
 md.append(f"| {row['language']} | {row['benchmark'].split('/',1)[1]} | {row['metric']} | {row['before']:g} | {row['after']:g} | {change} |")
md+=['','Raw paired samples and source/input manifests remain beside this report. Benchstat must supply any later significance claim. A passing median screen does not change routing or graduate a language.','']
(p/'directional-report.md').write_text('\n'.join(md))
print(json.dumps({'rows':rows,'processes':processes,'ratchet_failures':ratchet_failures,'directional_changes':len(directions)},indent=2))
if ratchet_failures:raise SystemExit('performance ratchet failed; preserve all observations and keep N held')
