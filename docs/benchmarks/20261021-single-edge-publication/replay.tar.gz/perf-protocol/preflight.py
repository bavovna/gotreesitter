#!/usr/bin/env python3
from pathlib import Path
from statistics import median
import argparse,hashlib,json,os,platform,re,subprocess
parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['before','after'],required=True);args=parser.parse_args()
p=Path('/evidence');q=Path('/qualification')
read=lambda path:json.loads(path.read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert platform.system()=='Linux' and platform.machine()=='x86_64'
assert subprocess.check_output(['go','version'],text=True).strip()=='go version go1.25.14 linux/amd64'
assert subprocess.check_output(['go','env','GOOS','GOARCH'],text=True).splitlines()==['linux','amd64']
assert re.search(r'^Cpus_allowed_list:\s*6$',Path('/proc/self/status').read_text(),re.M),'CPU affinity must be exactly 6'
expected_env={'GOMAXPROCS':'1','GOMEMLIMIT':'5GiB','GOWORK':'off','GOFLAGS':'-p=1 -buildvcs=false','GTS_ADMISSION_CANDIDATE':'1'}
for key,want in expected_env.items():assert os.environ.get(key)==want,(key,os.environ.get(key),want)
for key in ['GOGC','GODEBUG','GTS_ADMISSION_REAL_CORPUS_LANGS','GTS_BENCHMARK_SEED']:
 assert key not in os.environ,('unexpected campaign environment',key)
assert not [key for key in os.environ if key.startswith('GOT_')],'ordinary parser budgets required'
source_reports={}
for root,name,count in [(Path('/reference'),'baseline-source-pins.json',3541),(Path('/candidate'),'candidate-source-pins.json',3543)]:
 pins=read(p/name);assert len(pins)==count
 assert read(q/name)==pins,('qualification source pins differ',name)
 actual={str(f.relative_to(root)) for f in root.rglob('*.go') if '.git' not in f.parts}
 assert actual==set(pins),('Go source set changed',str(root),len(actual))
 for rel,want in pins.items():assert sha(root/rel)==want,('source changed',str(root),rel)
 for rel,want in read(p/'shared-benchmark-input-pins.json').items():assert sha(root/rel)==want,('benchmark input changed',str(root),rel)
 source_reports[str(root)]={'complete_Go_pins':count,'manifest_sha256':sha(p/name)}
markers=['c-parity-complete.txt','counter-invariants-complete.txt','qualify-complete.txt','large-go-verified-complete.txt','qualification-complete.txt','rss/complete.txt','rss/rss-matched/complete.txt']
for name in markers:assert (q/name).read_text().strip()=='complete',name
required={
 'c-parity-gate.json':{'passed':True,'C_fixture_checks':618,'strict_rows_exact':204,'expanded_statuses_exact':306,'expanded_routes_exact':300,'known_expanded_failures_unchanged':39},
 'full-counter-gate.json':{'passed':True,'ledger_complete_rows_exact':414,'canonical_Go_vectors_and_trees_exact':4,'invariant_languages':206,'steps_per_session':72,'C_fixture_checks':618,'strict_rows_exact':204,'expanded_Go_C_statuses_exact':306,'expanded_Go_routes_exact':300,'expanded_Go_known_failures_unchanged':39,'source_pin_count':3543,'held_Go_repair_included':False,'runtime_promoted':False},
 'final-core-mode-audit.json':{'passed':True,'full_Core_suite_passes':{'core-default.log':593,'core-shadow.log':605,'core-phase0-shadow.log':629,'core-phase0a-shadow.log':727,'core-onepass-shadow.log':605},'boundary_regressions_pass_native_386_race':True,'cached_geometry_and_nilness_tests_run':True,'collection_calls_in_engine':0,'source_hashes_exact':3543},
 'qualification-receipt.json':{'passed':True,'baseline_commit':'e91e0322f1b094c0995684449f9b90a1a08f4783','candidate_pins_exact':3543,'standard_and_owned_ledger_rows_exact':414,'canonical_Go_vectors_exact':4,'edit_sessions':206,'C_fixture_checks':618,'strict_rows_exact':204,'expanded_Go_statuses_exact':306,'expanded_Go_routes_exact':300,'RSS_processes':126,'RSS_seeds':'48701..48720','ordinary_YAML_route':'fallback','owned_YAML_route':'compact','timings_run':False,'runtime_promoted':False}}
for name,values in required.items():
 got=read(q/name)
 for key,want in values.items():assert got.get(key)==want,('qualification prerequisite',name,key,got.get(key),want)
rss=read(q/'rss/rss-matched/audit.json')
assert rss['candidate_safety_pass'] is True and rss['all_initial_probes_retained'] is True
assert rss['candidate_ceiling_failures']==[] and rss['seeds']=='48701..48720'
assert len(rss['initial'])==6 and len(rss['matched'])==120
assert rss['environment']['GOMAXPROCS']=='1' and rss['environment']['GOMEMLIMIT']=='5GiB'
assert rss['environment']['GOGC'] is None and rss['environment']['GODEBUG'] is None
assert rss['environment']['GOT_PARSE_NODE_LIMIT_SCALE'] is None and rss['environment']['GOT_GLR_MAX_STACKS'] is None
roles=['baseline','candidate'];cases=['go','yaml_ordinary','yaml_owned'];seen=set();ratios={}
for row in rss['initial']+rss['matched']:
 role,case,stage=row['role'],row['case'],row['stage'];assert role in roles and case in cases and stage in ['initial','matched']
 if stage=='initial':
  assert row['seed'] is None and row['position'] is None
  stem=f'{role}-standalone-{case}';directory=q/'rss/probes'
 else:
  seed=row['seed'];assert seed in range(48701,48721)
  expected_order=roles if seed%2 else list(reversed(roles));assert row['position']==expected_order.index(role)+1
  stem=f'{seed}-{case}-{role}';directory=q/'rss/rss-matched'
 identity=(stage,row['seed'],case,role);assert identity not in seen;seen.add(identity)
 text=(directory/(stem+'.log')).read_text();resource=(directory/(stem+'.rss')).read_text()
 assert re.search(r'^\s*Exit status: 0$',resource,re.M),('RSS process exit',stem)
 assert '--- PASS:' in text and '--- SKIP:' not in text and '--- FAIL:' not in text and 'no tests to run' not in text
 assert 'stopReason=accepted' in text
 assert ('compact=0 fallback=1' if case=='yaml_ordinary' else 'compact=1 fallback=0') in text
 size=int(re.search(r'bytes=(\d+)',text)[1]);assert size==(1048591 if case=='go' else 1049572)
 if case=='go':assert 'nodes=903086/' in text and 'tokens=425742 ' in text
 peak=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',resource)[1])*1024
 assert row['input_bytes']==size and row['peak_rss_bytes']==peak and row['rss_bytes_per_source_byte']==peak/size
 if role=='candidate':assert peak/size<=400,('RSS ceiling',stem)
for role in roles:assert sha(q/f'rss/probes/{role}-rss-root.test')==rss['binary_sha256'][role]
assert seen=={('initial',None,case,role) for case in cases for role in roles}|{('matched',seed,case,role) for seed in range(48701,48721) for case in cases for role in roles}
for case in cases:
 values={role:[r['rss_bytes_per_source_byte'] for r in rss['matched'] if r['role']==role and r['case']==case] for role in roles}
 assert all(len(v)==20 for v in values.values())
 ratio=median(values['candidate'])/median(values['baseline']);assert ratio<=1.10
 assert ratio==rss['candidate_baseline_median_ratios'][case]
 assert ratio==read(q/'qualification-receipt.json')['RSS_candidate_baseline_median_ratios'][case]
 ratios[case]=ratio
artifacts=markers+list(required)+['rss/rss-matched/audit.json','baseline-source-pins.json','candidate-source-pins.json']
qualification_sha={name:sha(q/name) for name in artifacts}
report={'passed':True,'phase':args.phase,'sources':source_reports,'qualification_sha256':qualification_sha,'RSS_raw_processes_checked':126,'RSS_candidate_baseline_median_ratios':ratios,'ordinary_YAML_route':'fallback','owned_YAML_route':'compact','environment':expected_env,'cpu_affinity':'6','go_version':'go1.25.14 linux/amd64'}
if args.phase=='after':
 before=read(p/'pre-timing-audit.json');assert before['passed']
 for key in ['sources','qualification_sha256','environment','cpu_affinity','go_version']:
  assert before[key]==report[key],('campaign input changed during timings',key)
output=p/('pre-timing-audit.json' if args.phase=='before' else 'post-timing-audit.json')
assert not output.exists(),('refusing audit overwrite',str(output))
output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
