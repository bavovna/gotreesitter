#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1
export GTS_ADMISSION_CANDIDATE=1 GOFLAGS='-p=1 -buildvcs=false'
# The parent supplies the pinned image, CPU 6, 5GiB Go limit and both host locks.
# Defaults are asserted by preflight, never silently rewritten after qualification.
test ! -e /evidence/perf
python3 /evidence/verify-inputs.py
python3 /evidence/preflight.py --phase before > /evidence/pre-timing-audit.log 2>&1
mkdir /evidence/perf
cd /candidate
bash scripts/run_randomized_benchmarks.sh \
 --output /evidence/perf/go-after.txt --baseline-root /reference --baseline-output /evidence/perf/go-before.txt \
 --bench-regex '^BenchmarkCompactThroughputGo$' \
 --require-benchmarks BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr,BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib \
 --runs 20 --seed-start 49301 --benchtime 750ms > /evidence/perf/go-runner.log 2>&1
bash scripts/run_randomized_benchmarks.sh \
 --output /evidence/perf/yaml-after.txt --baseline-root /reference --baseline-output /evidence/perf/yaml-before.txt \
 --bench-regex '^BenchmarkCompactThroughputYAML$' \
 --require-benchmarks BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned \
 --runs 20 --seed-start 49201 --benchtime 750ms > /evidence/perf/yaml-runner.log 2>&1
printf 'complete\n' > /evidence/perf/complete.txt
python3 /evidence/verify-inputs.py
python3 /evidence/preflight.py --phase after > /evidence/post-timing-audit.log 2>&1
python3 /evidence/analyze-perf.py > /evidence/perf-audit.log 2>&1
printf 'complete\n' > /evidence/complete.txt
