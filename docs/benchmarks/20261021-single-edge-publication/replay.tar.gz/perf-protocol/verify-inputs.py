#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
pins=json.loads((p/'protocol-input-pins.json').read_text())
for name,want in pins.items():
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==want,('protocol input changed',name)
print(json.dumps({'protocol_inputs_exact':len(pins)}))
